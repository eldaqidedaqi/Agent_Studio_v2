# ⬡ Agent Studio v2.0 — Referencia de API

## Base URL

```
http://localhost:5000
```

---

## Endpoints

### `GET /`
Sirve el frontend `index.html`.

---

### `GET /api/health`

Health check del servidor.

**Respuesta:**
```json
{
  "status": "ok",
  "version": "2.0.0",
  "timestamp": "2026-02-28T12:00:00Z",
  "api_key": "configured",
  "models": 3,
  "ollama": "offline"
}
```

---

### `GET /api/config`

Configuración actual del servidor (sin API keys).

**Respuesta:**
```json
{
  "model": "claude-sonnet-4-20250514",
  "max_tokens": 8192,
  "ollama_host": "http://localhost:11434",
  "debug": false,
  "api_key_set": true,
  "version": "2.0.0"
}
```

---

### `GET /api/models`

Lista todos los modelos disponibles (Claude + Ollama local).

**Respuesta:**
```json
{
  "models": [
    {
      "id": "claude-sonnet-4-20250514",
      "name": "Claude Sonnet 4",
      "provider": "anthropic",
      "ctx": 200000
    },
    {
      "id": "llama3.2",
      "name": "llama3.2",
      "provider": "ollama",
      "ctx": 8192
    }
  ]
}
```

---

### `POST /api/chat`

Chat estándar — devuelve la respuesta completa.

**Body:**
```json
{
  "messages": [
    {"role": "user", "content": "Hola, ¿qué puedes hacer?"}
  ],
  "model": "claude-sonnet-4-20250514",
  "max_tokens": 4096,
  "temperature": 0.7,
  "system": "Eres un asistente experto en código.",
  "api_key": "sk-ant-..."
}
```

> `api_key` es opcional si está configurado en `.env`

**Respuesta exitosa:**
```json
{
  "content": "Puedo ayudarte con...",
  "model": "claude-sonnet-4-20250514",
  "stop_reason": "end_turn",
  "usage": {
    "input_tokens": 42,
    "output_tokens": 128
  }
}
```

**Error (sin API key):**
```json
{
  "error": "API key no configurada. Añade ANTHROPIC_API_KEY al .env"
}
```

---

### `POST /api/stream`

Chat con **SSE streaming** — devuelve tokens en tiempo real.

**Body:** igual que `/api/chat`

**Respuesta** — `text/event-stream`:
```
data: {"token": "Hola"}

data: {"token": ","}

data: {"token": " puedo"}

data: {"usage": {"input_tokens": 10, "output_tokens": 3}}

data: [DONE]
```

**Consumir desde JavaScript:**
```javascript
const resp = await fetch('/api/stream', {
  method: 'POST',
  headers: {'Content-Type': 'application/json'},
  body: JSON.stringify({ messages, model })
});

const reader = resp.body.getReader();
const decoder = new TextDecoder();

while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  const lines = decoder.decode(value).split('\n');
  for (const line of lines) {
    if (line.startsWith('data: ')) {
      const data = line.slice(6);
      if (data === '[DONE]') return;
      const { token } = JSON.parse(data);
      if (token) process.stdout.write(token);
    }
  }
}
```

---

### `POST /api/enhance`

Mejora automática de un prompt via IA.

**Body:**
```json
{
  "prompt": "explica docker",
  "model": "claude-haiku-4-5-20251001",
  "api_key": "sk-ant-..."
}
```

**Respuesta:**
```json
{
  "original": "explica docker",
  "enhanced": "Explica Docker de forma práctica: qué es un contenedor, cómo difiere de una VM, y muestra un ejemplo con Dockerfile + docker-compose para una app Node.js.",
  "usage": { "input_tokens": 60, "output_tokens": 85 }
}
```

---

### `POST /api/review`

Auto-review de código o texto con 5 métricas de calidad.

**Body:**
```json
{
  "content": "function fetchUser(id) { return fetch('/users/' + id).then(r => r.json()) }",
  "model": "claude-sonnet-4-20250514",
  "api_key": "sk-ant-..."
}
```

**Respuesta:**
```json
{
  "review": {
    "scores": {
      "completeness": 60,
      "security": 45,
      "performance": 70,
      "errorHandling": 20,
      "codeQuality": 65
    },
    "issues": [
      {"severity": "critical", "message": "Sin manejo de errores HTTP (status != 200)"},
      {"severity": "warning",  "message": "Sin validación del parámetro id"},
      {"severity": "info",     "message": "Considera usar async/await para mayor legibilidad"}
    ],
    "summary": "Función funcional pero frágil — falta manejo de errores.",
    "autofix": "Añadir .catch() y verificar response.ok antes de .json()"
  },
  "usage": { "input_tokens": 75, "output_tokens": 120 }
}
```

---

## Códigos de error

| Código | Significado |
|--------|-------------|
| `400` | Body inválido o campo requerido faltante |
| `401` | API key no configurada o inválida |
| `500` | Error interno del servidor |
| `502` | Error conectando con Ollama |
| `504` | Timeout (respuesta tardó más de 120s) |

---

## Ejemplo completo con curl

```bash
# Health check
curl http://localhost:5000/api/health

# Chat
curl -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Hola"}]}'

# Streaming
curl -X POST http://localhost:5000/api/stream \
  -H "Content-Type: application/json" \
  -H "Accept: text/event-stream" \
  -d '{"messages":[{"role":"user","content":"Escribe un haiku"}]}' \
  --no-buffer

# Mejorar prompt
curl -X POST http://localhost:5000/api/enhance \
  -H "Content-Type: application/json" \
  -d '{"prompt":"explica recursion"}'
```

---

## Ejemplo con Python (requests)

```python
import requests

BASE = "http://localhost:5000"

# Chat estándar
r = requests.post(f"{BASE}/api/chat", json={
    "messages": [{"role": "user", "content": "¿Qué es Python?"}],
    "model": "claude-sonnet-4-20250514",
})
print(r.json()["content"])

# Streaming
with requests.post(f"{BASE}/api/stream", json={
    "messages": [{"role": "user", "content": "Cuenta del 1 al 5 despacio"}],
}, stream=True) as r:
    for line in r.iter_lines():
        if line and line.startswith(b"data: "):
            data = line[6:]
            if data == b"[DONE]":
                break
            import json
            token = json.loads(data).get("token", "")
            print(token, end="", flush=True)
```
