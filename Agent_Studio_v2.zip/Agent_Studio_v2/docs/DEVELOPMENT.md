# ⬡ Agent Studio v2.0 — Guía de Desarrollo

## Arquitectura

```
Browser (React CDN)
    │
    ├── index.html          → Single-page app completa (JSX transpilado en runtime)
    │   ├── Multi-Agent Pipeline (Planner/Detector/Executor/Debugger)
    │   ├── RAG Vector Memory (cosine similarity local)
    │   ├── 20 MCP Tools (5 tiers)
    │   ├── API Key Vault (XOR cipher)
    │   ├── Terminal Emulator (15 comandos)
    │   ├── Voice Input (Web Speech API)
    │   ├── SSE Streaming client
    │   ├── Analytics Dashboard (SVG charts)
    │   ├── Conversation Branching
    │   └── Smart Diff Engine (Myers LCS)
    │
    └── Agente-web.py (Flask)
        │
        ├── POST /api/chat     → Anthropic API proxy
        ├── POST /api/stream   → SSE streaming proxy
        ├── POST /api/enhance  → Prompt enhancer
        ├── POST /api/review   → AI self-review
        ├── GET  /api/models   → Claude + Ollama models
        └── GET  /api/health   → Server status
```

## Flujo de una petición de chat

```
1. Usuario escribe mensaje en index.html
2. Frontend detecta agentes activos → construye pipeline
3. Cada agente añade su system prompt al contexto
4. RAG busca memorias relevantes → las inyecta
5. Frontend hace POST /api/chat o /api/stream
6. Agente-web.py proxea a Anthropic API con las headers correctas
7. Para /api/stream: lee SSE line-by-line, reenvía tokens al browser
8. Browser actualiza el mensaje en tiempo real
9. AI Self-Review analiza el output (opcional)
10. Snippet Bank extrae bloques de código automáticamente
```

## Añadir un nuevo endpoint

```python
# En Agente-web.py, añade tras los endpoints existentes:

@app.route("/api/mi-endpoint", methods=["POST"])
def mi_endpoint():
    data    = request.get_json(force=True)
    api_key = extract_key(data)

    if not validate_key(api_key):
        return jsonify({"error": "API key no configurada"}), 401

    # Tu lógica aquí
    resultado = {"mensaje": "Hola desde mi endpoint"}
    return jsonify(resultado)
```

## Añadir un nuevo agente al frontend

En `index.html`, busca la sección `AGENTS_CONFIG` y añade:

```javascript
{
  id:          "mi-agente",
  name:        "Mi Agente",
  icon:        "🎯",
  color:       "#06b6d4",
  description: "Descripción del agente",
  systemPrompt: `Eres un experto en X. Tu rol es Y.
Responde siempre con Z.`,
  model:       "claude-sonnet-4-20250514",
  temperature:  0.7,
}
```

## Estructura de mensajes MCP

Los tools MCP se invocan en el system prompt del agente:

```javascript
const mcpContext = activeMCPTools
  .filter(t => t.enabled)
  .map(t => `- ${t.name}: ${t.description} (${t.endpoint})`)
  .join('\n');

const systemWithMCP = `${agentSystem}\n\nHerramientas disponibles:\n${mcpContext}`;
```

## Testing manual

```bash
# 1. Lanzar servidor en background
python Agente-web.py &

# 2. Health check
curl -s http://localhost:5000/api/health | python3 -m json.tool

# 3. Test chat
curl -s -X POST http://localhost:5000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Di hola en JSON"}]}' | \
  python3 -m json.tool

# 4. Test streaming (necesita API key real)
curl -X POST http://localhost:5000/api/stream \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Cuenta del 1 al 3"}]}' \
  --no-buffer -s

# 5. Parar servidor
kill %1
```

## Variables de sesión del frontend

El frontend usa `window.storage` de Claude.ai para persistir:

| Key | Tipo | Contenido |
|-----|------|-----------|
| `as_memories` | JSON | Memorias vectoriales del RAG |
| `as_snippets` | JSON | Snippet bank |
| `as_agents` | JSON | Agentes personalizados |
| `as_templates` | JSON | Templates de proyecto usados |
| `as_analytics` | JSON | Métricas de uso |

## Logs

```
logs/agent_studio.log  ← Rotación automática por Flask
```

Formato:
```
2026-02-28 12:00:01 [INFO] [chat] model=claude-sonnet-4-20250514 msgs=3 ~tokens=450
2026-02-28 12:00:03 [INFO] [stream] model=claude-sonnet-4-20250514 msgs=3 ~tokens=450
```

## Despliegue en producción

```bash
# Instalar gunicorn
pip install gunicorn

# Lanzar con gunicorn (4 workers)
gunicorn Agente-web:app \
  --workers 4 \
  --bind 0.0.0.0:5000 \
  --timeout 300 \
  --log-level info

# Con nginx (recomendado para SSE)
# /etc/nginx/sites-available/agent-studio
server {
    listen 80;
    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_buffering off;           # CRÍTICO para SSE
        proxy_cache off;               # CRÍTICO para SSE
        proxy_set_header Connection '';
        proxy_http_version 1.1;
        chunked_transfer_encoding on;
    }
}
```
