import { useState, useEffect, useRef, useCallback, useMemo } from "react";

/* ═══════════════════════════════════════════════════════════════════
   AGENT STUDIO v2.0 — Full Stack AI Agent Platform
   Features: Multi-Agent | RAG/Vector Memory | 20+ MCP Tools |
             Context7 | Sequential Thinking | GitHub | Brave Search |
             Firecrawl | E2B Sandbox | Qdrant | Ollama Bridge |
             LangSmith Observability | ECharts | n8n Workflows
═══════════════════════════════════════════════════════════════════ */

// ─── CONFIG ──────────────────────────────────────────────────────────────────
const ANTHROPIC_BASE = "https://api.anthropic.com/v1/messages";
const OLLAMA_BASE    = "http://localhost:11434";
const MODEL_CLAUDE   = "claude-sonnet-4-20250514";

// ─── MCP TOOLS REGISTRY ──────────────────────────────────────────────────────
const MCP_REGISTRY = [
  // Tier 1 — Essential
  { id:"context7",    name:"Context7",          icon:"📚", tier:1, color:"#00f5a0", desc:"Live library docs · eliminates hallucinations", cmd:"npx @upstash/context7-mcp", enabled:true,  category:"docs" },
  { id:"seqthink",    name:"Sequential Think",  icon:"🧭", tier:1, color:"#00f5a0", desc:"Step-by-step reasoning before acting",          cmd:"npx @modelcontextprotocol/server-sequential-thinking", enabled:true,  category:"reasoning" },
  { id:"github",      name:"GitHub MCP",        icon:"🐙", tier:1, color:"#00f5a0", desc:"Repos · PRs · Issues · Code review",            cmd:"npx @github/mcp",           enabled:true,  category:"dev" },
  // Tier 2 — Productivity
  { id:"playwright",  name:"Playwright",        icon:"🎭", tier:2, color:"#7c3aed", desc:"Real browser automation + scraping",            cmd:"npx @playwright/mcp",       enabled:true,  category:"browser" },
  { id:"ollama_br",   name:"Ollama Bridge",     icon:"🌉", tier:2, color:"#7c3aed", desc:"Connect local models to MCP tools",             cmd:"npx ollama-mcp-bridge",      enabled:true,  category:"models" },
  { id:"brave",       name:"Brave Search",      icon:"🦁", tier:2, color:"#7c3aed", desc:"Privacy-first real-time web search",            cmd:"npx @brave/search-mcp",      enabled:true,  category:"search" },
  { id:"firecrawl",   name:"Firecrawl",         icon:"🔥", tier:2, color:"#7c3aed", desc:"Deep web scraping & structured extraction",     cmd:"npx firecrawl-mcp",          enabled:false, category:"search" },
  // Tier 3 — Storage
  { id:"qdrant",      name:"Qdrant Vector DB",  icon:"🧠", tier:3, color:"#f59e0b", desc:"Semantic vector search & RAG",                  cmd:"npx qdrant-mcp",             enabled:true,  category:"memory" },
  { id:"sqlite",      name:"SQLite MCP",        icon:"🗄️", tier:3, color:"#f59e0b", desc:"Structured persistent storage",                 cmd:"npx @modelcontextprotocol/server-sqlite", enabled:true,  category:"memory" },
  { id:"filesystem",  name:"FileSystem",        icon:"📁", tier:3, color:"#f59e0b", desc:"Read/write local files & directories",          cmd:"npx @modelcontextprotocol/server-filesystem", enabled:true,  category:"storage" },
  // Tier 4 — Execution
  { id:"e2b",         name:"E2B Sandbox",       icon:"⚗️", tier:4, color:"#ef4444", desc:"Safe code execution · sub-90ms cold start",     cmd:"npx e2b-mcp",               enabled:true,  category:"exec" },
  { id:"terminal",    name:"Terminal",          icon:"⌨️", tier:4, color:"#ef4444", desc:"Shell commands & scripts",                      cmd:"npx @modelcontextprotocol/server-bash", enabled:false, category:"exec" },
  { id:"docker",      name:"Docker",            icon:"🐳", tier:4, color:"#ef4444", desc:"Container management",                          cmd:"npx docker-mcp",            enabled:false, category:"exec" },
  // Tier 5 — Integrations
  { id:"echarts",     name:"ECharts MCP",       icon:"📊", tier:5, color:"#06b6d4", desc:"Dynamic charts & visualizations",               cmd:"npx echarts-mcp",           enabled:true,  category:"viz" },
  { id:"n8n",         name:"n8n Workflows",     icon:"⚙️", tier:5, color:"#06b6d4", desc:"Automate complex multi-step workflows",         cmd:"npx n8n-mcp",               enabled:false, category:"auto" },
  { id:"git",         name:"Git",               icon:"🔀", tier:5, color:"#06b6d4", desc:"Version control operations",                    cmd:"npx @modelcontextprotocol/server-git", enabled:true,  category:"dev" },
  { id:"api",         name:"REST API Client",   icon:"🔌", tier:5, color:"#06b6d4", desc:"HTTP client for any API",                       cmd:"built-in",                  enabled:true,  category:"net" },
  { id:"graphite",    name:"Graphite GT",       icon:"📝", tier:5, color:"#06b6d4", desc:"Stack-based PR review & code quality",          cmd:"npx graphite-mcp",          enabled:false, category:"dev" },
  { id:"langsmith",   name:"LangSmith",         icon:"🔭", tier:5, color:"#06b6d4", desc:"Observability · traces · evals",                cmd:"npx langsmith-mcp",         enabled:true,  category:"obs" },
  { id:"vexa",        name:"Vexa",              icon:"🎙️", tier:5, color:"#06b6d4", desc:"Real-time meeting transcription",               cmd:"npx vexa-mcp",              enabled:false, category:"audio" },
];

// ─── AGENT PIPELINE ──────────────────────────────────────────────────────────
const AGENTS = [
  { id:"planner",  name:"Planner",   icon:"🧭", color:"#06b6d4", role:"Sequential thinking · breaks tasks into atomic steps" },
  { id:"detector", name:"Detector",  icon:"🔍", color:"#7c3aed", role:"Context7 + search · gathers docs and context" },
  { id:"executor", name:"Executor",  icon:"⚡", color:"#00f5a0", role:"Main model · generates code and solutions" },
  { id:"debugger", name:"Debugger",  icon:"🔬", color:"#ef4444", role:"Recursive error fixer · permanent mode available" },
];

// ─── OUTPUT MODES ─────────────────────────────────────────────────────────────
const OUTPUT_MODES = [
  { id:"webapp",  label:"Web App",  icon:"🌐", color:"#00f5a0", desc:"Full HTML/CSS/JS self-contained app" },
  { id:"code",    label:"Código",   icon:"💻", color:"#7c3aed", desc:"Clean documented production code" },
  { id:"project", label:"Proyecto", icon:"📦", color:"#f59e0b", desc:"Multi-file project with structure" },
  { id:"debug",   label:"Depurar",  icon:"🔬", color:"#ef4444", desc:"Recursive error detection & fix" },
];

// ─── OPEN SOURCE MODELS ───────────────────────────────────────────────────────
const OSS_MODELS = [
  { id:"llama3.3:70b",    name:"Llama 3.3 70B",    provider:"Meta",      tags:["agent","code"],          stars:"★★★★★" },
  { id:"deepseek-r1:70b", name:"DeepSeek R1 70B",  provider:"DeepSeek",  tags:["reasoning","code"],     stars:"★★★★★" },
  { id:"qwen2.5:72b",     name:"Qwen 2.5 72B",     provider:"Alibaba",   tags:["multilingual","agent"], stars:"★★★★☆" },
  { id:"qwen2.5-coder:32b",name:"Qwen Coder 32B",  provider:"Alibaba",   tags:["code","debug"],         stars:"★★★★☆" },
  { id:"mistral:7b",      name:"Mistral 7B",        provider:"Mistral",   tags:["fast","code"],          stars:"★★★☆☆" },
  { id:"phi4:14b",        name:"Phi-4 14B",         provider:"Microsoft", tags:["reasoning"],            stars:"★★★★☆" },
  { id:"gemma3:27b",      name:"Gemma 3 27B",       provider:"Google",    tags:["agent"],                stars:"★★★☆☆" },
  { id:"codellama:70b",   name:"CodeLlama 70B",     provider:"Meta",      tags:["code","debug"],         stars:"★★★★☆" },
  { id:"mixtral:8x7b",    name:"Mixtral 8x7B",      provider:"Mistral",   tags:["agent","fast"],         stars:"★★★★☆" },
  { id:"nous-hermes2:34b",name:"Nous Hermes 2 34B", provider:"NousResearch",tags:["agent"],              stars:"★★★☆☆" },
];

// ─── PROJECT TEMPLATES ────────────────────────────────────────────────────────
const PROJECT_TEMPLATES = [
  { id:"nextjs-app",    icon:"▲", name:"Next.js 14 App",       color:"#ffffff", stack:"Next.js · TypeScript · Tailwind · shadcn/ui",   tags:["react","typescript","fullstack"],     desc:"App Router, Server Components, API routes, auth-ready",       structure:"app/layout.tsx, app/page.tsx, app/api/route.ts, components/ui/, lib/utils.ts",    requirements:"Next.js 14 con App Router, TypeScript strict, Tailwind CSS v3, componentes shadcn/ui, dark mode, SEO optimizado" },
  { id:"react-vite",   icon:"⚡", name:"React + Vite",          color:"#61dafb", stack:"React 18 · Vite · TypeScript · Zustand",         tags:["react","spa","typescript"],           desc:"SPA moderna con state management y routing",                  structure:"src/App.tsx, src/store/, src/components/, src/pages/, vite.config.ts",           requirements:"React 18, Vite 5, TypeScript, Zustand para estado global, React Router v6, axios para API calls" },
  { id:"fastapi",      icon:"🐍", name:"FastAPI Backend",        color:"#009688", stack:"Python · FastAPI · SQLAlchemy · Pydantic",      tags:["python","api","backend"],             desc:"API REST completa con auth JWT, BD y docs automáticas",       structure:"main.py, routers/, models/, schemas/, auth/, database.py, requirements.txt",     requirements:"FastAPI, SQLAlchemy async, Pydantic v2, JWT auth, PostgreSQL, Alembic migrations, pytest" },
  { id:"express-api",  icon:"🟢", name:"Express API",            color:"#68a063", stack:"Node.js · Express · Prisma · JWT",             tags:["node","api","backend"],               desc:"REST API con autenticación, ORM y validación",                structure:"src/index.ts, src/routes/, src/middleware/, src/models/, prisma/schema.prisma",  requirements:"Express 5, Prisma, TypeScript, Zod validación, JWT auth, cors, helmet, rate limiting" },
  { id:"landing",      icon:"🌐", name:"Landing Page",           color:"#00f5a0", stack:"HTML · CSS · JS · Animaciones",                tags:["html","css","frontend"],              desc:"Landing page moderna con animaciones y diseño excepcional",   structure:"index.html, styles.css, script.js, assets/",                                   requirements:"HTML5 semántico, CSS Grid/Flexbox, animaciones CSS, intersection observer, scroll effects, diseño premium" },
  { id:"react-native", icon:"📱", name:"React Native App",       color:"#61dafb", stack:"React Native · Expo · TypeScript",             tags:["mobile","react","expo"],              desc:"App móvil cross-platform iOS/Android",                        structure:"App.tsx, screens/, components/, navigation/, hooks/, store/",                   requirements:"Expo SDK 52, React Native, TypeScript, React Navigation v6, Expo Router, NativeWind" },
  { id:"t3-stack",     icon:"🔷", name:"T3 Stack",               color:"#7c3aed", stack:"Next.js · tRPC · Prisma · NextAuth",           tags:["fullstack","typescript","trpc"],      desc:"Full-stack type-safe app con el stack T3 completo",           structure:"src/server/api/, src/components/, src/pages/, prisma/",                        requirements:"T3 Stack: Next.js, tRPC, Prisma, NextAuth.js, Tailwind, Zod. Type-safety end-to-end" },
  { id:"django-app",   icon:"🦄", name:"Django App",             color:"#092e20", stack:"Python · Django · DRF · Celery",               tags:["python","django","fullstack"],        desc:"App Django completa con API REST y tareas asíncronas",        structure:"config/, apps/users/, apps/api/, celery.py, requirements.txt",                  requirements:"Django 5, DRF, Celery+Redis, JWT auth, PostgreSQL, WhiteNoise, custom admin" },
  { id:"svelte-kit",   icon:"🧡", name:"SvelteKit App",          color:"#ff3e00", stack:"SvelteKit · TypeScript · Drizzle",             tags:["svelte","fullstack","typescript"],    desc:"App full-stack con SvelteKit y edge-ready",                   structure:"src/routes/, src/lib/, src/components/, drizzle/",                             requirements:"SvelteKit, TypeScript, Drizzle ORM, Auth.js, Tailwind CSS, Vite" },
  { id:"electron",     icon:"⚛",  name:"Electron Desktop App",   color:"#9feaf9", stack:"Electron · React · TypeScript",               tags:["desktop","electron","react"],         desc:"App de escritorio cross-platform",                            structure:"electron/main.ts, electron/preload.ts, src/renderer/",                         requirements:"Electron 33, React 18, TypeScript, IPC communication, auto-updater, electron-builder" },
  { id:"chrome-ext",   icon:"🧩", name:"Chrome Extension",       color:"#4285f4", stack:"Chrome MV3 · TypeScript · React",             tags:["browser","extension","react"],        desc:"Extensión de Chrome con Manifest v3",                         structure:"manifest.json, popup/, background/, content/, options/",                       requirements:"Chrome Extension MV3, TypeScript, React para popup, service worker, content scripts, storage API" },
  { id:"ai-agent",     icon:"🤖", name:"AI Agent Service",       color:"#f59e0b", stack:"LangChain · FastAPI · Redis · Qdrant",        tags:["ai","agent","python","rag"],          desc:"Servicio de agente IA con RAG y herramientas",                structure:"agent/, tools/, memory/, api/, qdrant_client.py, main.py",                     requirements:"LangChain, OpenAI/Anthropic, FastAPI, Qdrant vector DB, Redis para memoria, herramientas personalizadas" },
];

// ─── BUILT-IN PROMPT LIBRARY ─────────────────────────────────────────────────
const BUILTIN_PROMPTS = [
  { id:"p1", icon:"🔍", title:"Revisar y refactorizar código",       content:"Revisa este código, identifica problemas de rendimiento, bugs potenciales y malas prácticas. Refactoriza siguiendo mejores prácticas y añade comentarios JSDoc:" },
  { id:"p2", icon:"🧪", title:"Generar tests unitarios",             content:"Genera tests unitarios completos con Jest/Vitest para el siguiente código. Incluye casos edge, mocks y coverage al 100%:" },
  { id:"p3", icon:"📊", title:"Dashboard con gráficas",              content:"Genera un dashboard moderno con React y Recharts que incluya: gráfica de líneas, barras, pie chart, KPIs y filtros por fecha. Datos de ejemplo incluidos." },
  { id:"p4", icon:"🔐", title:"Sistema de autenticación completo",   content:"Implementa un sistema de autenticación completo con: registro, login, JWT refresh tokens, password reset, OAuth Google, middleware de protección de rutas." },
  { id:"p5", icon:"🗄️", title:"Schema de BD + migrations",          content:"Diseña el schema de base de datos PostgreSQL con Prisma para:" },
  { id:"p6", icon:"⚡", title:"Optimizar rendimiento",               content:"Analiza y optimiza el rendimiento de este código. Identifica bottlenecks, aplica memoización, lazy loading, y cualquier optimización relevante:" },
  { id:"p7", icon:"🌐", title:"API REST completa con docs",          content:"Genera una API REST completa con: CRUD, autenticación, validación Zod, manejo de errores, logging, rate limiting y documentación Swagger automática para:" },
  { id:"p8", icon:"🎨", title:"Componente UI premium",               content:"Diseña un componente React visualmente excepcional con animaciones, dark/light mode, accesibilidad WCAG, y variantes múltiples para:" },
  { id:"p9", icon:"🔧", title:"Dockerizar aplicación",              content:"Crea el Dockerfile multi-stage optimizado, docker-compose.yml con todos los servicios, .dockerignore y scripts de deployment para esta aplicación:" },
  { id:"p10",icon:"📱", title:"Diseño responsive completo",          content:"Convierte este diseño a mobile-first completamente responsive con breakpoints sm/md/lg/xl, gestos táctiles, y optimizaciones de rendimiento móvil:" },
];

// ─── API PROVIDERS CATALOG ────────────────────────────────────────────────────
// Each provider has: id, name, icon, color, envVar, keywords[], docsUrl
const API_PROVIDERS = [
  // AI / LLMs
  { id:"anthropic",    name:"Anthropic",        icon:"⬡",  color:"#d97706", cat:"AI",       envVar:"ANTHROPIC_API_KEY",        keywords:["anthropic","claude","claude-sonnet","claude-opus","claude-haiku"] },
  { id:"openai",       name:"OpenAI",           icon:"✦",  color:"#10a37f", cat:"AI",       envVar:"OPENAI_API_KEY",            keywords:["openai","gpt","gpt-4","gpt-3","chatgpt","dall-e","whisper","embeddings"] },
  { id:"gemini",       name:"Google Gemini",    icon:"◆",  color:"#4285f4", cat:"AI",       envVar:"GEMINI_API_KEY",            keywords:["gemini","google ai","bard","palm","vertex ai"] },
  { id:"groq",         name:"Groq",             icon:"⚡",  color:"#f97316", cat:"AI",       envVar:"GROQ_API_KEY",              keywords:["groq","groq cloud","llama groq"] },
  { id:"mistral",      name:"Mistral AI",       icon:"🌊",  color:"#6366f1", cat:"AI",       envVar:"MISTRAL_API_KEY",           keywords:["mistral","mixtral","mistral ai"] },
  { id:"cohere",       name:"Cohere",           icon:"○",  color:"#39d0d8", cat:"AI",       envVar:"COHERE_API_KEY",            keywords:["cohere","command","embed"] },
  { id:"together",     name:"Together AI",      icon:"∞",  color:"#8b5cf6", cat:"AI",       envVar:"TOGETHER_API_KEY",          keywords:["together","together ai","together cloud"] },
  { id:"replicate",    name:"Replicate",        icon:"⟳",  color:"#0ea5e9", cat:"AI",       envVar:"REPLICATE_API_TOKEN",       keywords:["replicate","stable diffusion","sdxl"] },
  { id:"huggingface",  name:"HuggingFace",      icon:"🤗",  color:"#ff9d00", cat:"AI",       envVar:"HUGGINGFACE_TOKEN",         keywords:["huggingface","hugging face","hf","transformers","hub"] },
  { id:"perplexity",   name:"Perplexity",       icon:"◉",  color:"#20b2aa", cat:"AI",       envVar:"PERPLEXITY_API_KEY",        keywords:["perplexity","pplx","sonar"] },
  // Search
  { id:"brave_search", name:"Brave Search",     icon:"🦁",  color:"#fb5e00", cat:"Search",   envVar:"BRAVE_SEARCH_API_KEY",      keywords:["brave search","brave api"] },
  { id:"serp",         name:"SerpAPI",          icon:"🔍",  color:"#4ade80", cat:"Search",   envVar:"SERPAPI_KEY",               keywords:["serpapi","serp api","google search api"] },
  { id:"exa",          name:"Exa AI",           icon:"⬛",  color:"#a78bfa", cat:"Search",   envVar:"EXA_API_KEY",               keywords:["exa","exa ai","exa search"] },
  { id:"tavily",       name:"Tavily",           icon:"🗺",  color:"#06b6d4", cat:"Search",   envVar:"TAVILY_API_KEY",            keywords:["tavily","tavily search"] },
  { id:"firecrawl_k",  name:"Firecrawl",        icon:"🔥",  color:"#ef4444", cat:"Search",   envVar:"FIRECRAWL_API_KEY",         keywords:["firecrawl","firecrawl api"] },
  // Infrastructure
  { id:"github_tok",   name:"GitHub",           icon:"🐙",  color:"#e8eaf6", cat:"Dev",      envVar:"GITHUB_TOKEN",              keywords:["github","github token","gh token","octokit"] },
  { id:"vercel",       name:"Vercel",           icon:"▲",  color:"#ffffff", cat:"Dev",      envVar:"VERCEL_TOKEN",              keywords:["vercel","next.js deploy","vercel deploy"] },
  { id:"railway",      name:"Railway",          icon:"🚂",  color:"#7c3aed", cat:"Dev",      envVar:"RAILWAY_TOKEN",             keywords:["railway","railway deploy"] },
  { id:"fly",          name:"Fly.io",           icon:"✈",  color:"#7e22ce", cat:"Dev",      envVar:"FLY_API_TOKEN",             keywords:["fly.io","flyio","fly deploy"] },
  // Databases
  { id:"supabase",     name:"Supabase",         icon:"⚡",  color:"#3ecf8e", cat:"DB",       envVar:"SUPABASE_SERVICE_KEY",      keywords:["supabase","supabase key","supabase url"] },
  { id:"planetscale",  name:"PlanetScale",      icon:"◈",  color:"#f0abfc", cat:"DB",       envVar:"PLANETSCALE_TOKEN",         keywords:["planetscale","planet scale"] },
  { id:"neon",         name:"Neon DB",          icon:"◑",  color:"#00e5bf", cat:"DB",       envVar:"NEON_DATABASE_URL",         keywords:["neon","neon db","neon database"] },
  { id:"upstash",      name:"Upstash Redis",    icon:"🔺",  color:"#00e9a3", cat:"DB",       envVar:"UPSTASH_REDIS_REST_TOKEN",  keywords:["upstash","redis","upstash redis","context7"] },
  { id:"qdrant_k",     name:"Qdrant Cloud",     icon:"🧠",  color:"#dc2626", cat:"DB",       envVar:"QDRANT_API_KEY",            keywords:["qdrant","vector db","qdrant cloud"] },
  { id:"pinecone",     name:"Pinecone",         icon:"🌲",  color:"#00b388", cat:"DB",       envVar:"PINECONE_API_KEY",          keywords:["pinecone","pinecone index"] },
  // Payment / Communication
  { id:"stripe",       name:"Stripe",           icon:"💳",  color:"#635bff", cat:"Payment",  envVar:"STRIPE_SECRET_KEY",         keywords:["stripe","payment","stripe api","checkout","stripe webhook"] },
  { id:"twilio",       name:"Twilio",           icon:"📱",  color:"#f22f46", cat:"Comms",    envVar:"TWILIO_AUTH_TOKEN",         keywords:["twilio","sms","whatsapp twilio"] },
  { id:"sendgrid",     name:"SendGrid",         icon:"📧",  color:"#1a82e2", cat:"Comms",    envVar:"SENDGRID_API_KEY",          keywords:["sendgrid","send grid","email sendgrid"] },
  { id:"resend",       name:"Resend",           icon:"✉",  color:"#000000", cat:"Comms",    envVar:"RESEND_API_KEY",            keywords:["resend","resend email","resend api"] },
  // Maps / Other
  { id:"google_maps",  name:"Google Maps",      icon:"🗺",  color:"#4285f4", cat:"Maps",     envVar:"GOOGLE_MAPS_API_KEY",       keywords:["google maps","maps api","geocoding","places api","google geocode"] },
  { id:"mapbox",       name:"Mapbox",           icon:"📍",  color:"#4264fb", cat:"Maps",     envVar:"MAPBOX_ACCESS_TOKEN",       keywords:["mapbox","mapbox token","map tiles"] },
  { id:"cloudinary",   name:"Cloudinary",       icon:"☁",  color:"#3448c5", cat:"Media",    envVar:"CLOUDINARY_API_KEY",        keywords:["cloudinary","image upload","cloud storage"] },
  { id:"aws",          name:"AWS",              icon:"☁",  color:"#ff9900", cat:"Cloud",    envVar:"AWS_ACCESS_KEY_ID",         keywords:["aws","amazon","s3","lambda","ec2","dynamodb"] },
  { id:"langsmith_k",  name:"LangSmith",        icon:"🔭",  color:"#f97316", cat:"AI",       envVar:"LANGSMITH_API_KEY",         keywords:["langsmith","langchain","langfuse"] },
  { id:"e2b_k",        name:"E2B",              icon:"⚗",  color:"#a855f7", cat:"Exec",     envVar:"E2B_API_KEY",               keywords:["e2b","e2b sandbox","code sandbox"] },
];

// ─── KEY OBFUSCATION (simple XOR — keys never leave the browser) ──────────────
const XOR_KEY = 0x5A;
const obfuscate = (str) => btoa(str.split("").map(c => String.fromCharCode(c.charCodeAt(0) ^ XOR_KEY)).join(""));
const deobfuscate = (enc) => { try { return atob(enc).split("").map(c => String.fromCharCode(c.charCodeAt(0) ^ XOR_KEY)).join(""); } catch { return ""; } };
const maskKey = (key) => { if (!key || key.length < 8) return "••••••••"; return key.slice(0,6) + "••••••••" + key.slice(-4); };

// ─── UTILS ────────────────────────────────────────────────────────────────────
const uuid  = () => Math.random().toString(36).slice(2,11);
const ts    = () => new Date().toLocaleTimeString("es",{hour:"2-digit",minute:"2-digit",second:"2-digit"});
const now   = () => Date.now();
const fmtMs = (ms) => ms < 1000 ? `${ms}ms` : `${(ms/1000).toFixed(1)}s`;

// Simulated vector similarity (keyword overlap scoring for RAG)
const vectorSimilarity = (query, text) => {
  const qWords = new Set(query.toLowerCase().split(/\W+/).filter(w => w.length > 3));
  const tWords = text.toLowerCase().split(/\W+/).filter(w => w.length > 3);
  let score = 0;
  tWords.forEach(w => { if (qWords.has(w)) score++; });
  return score / Math.max(qWords.size, 1);
};

// ─── MAIN COMPONENT ───────────────────────────────────────────────────────────
export default function AgentStudioV2() {
  // Core state
  const [messages,       setMessages]       = useState([]);
  const [input,          setInput]          = useState("");
  const [loading,        setLoading]        = useState(false);
  const [activeAgents,   setActiveAgents]   = useState(["executor"]);
  const [agentPipeline,  setAgentPipeline]  = useState(false);
  const [currentAgent,   setCurrentAgent]   = useState(null);

  // Models
  const [ollamaModels,   setOllamaModels]   = useState([]);
  const [ollamaStatus,   setOllamaStatus]   = useState("checking");
  const [selectedModel,  setSelectedModel]  = useState("claude");

  // Output
  const [outputMode,     setOutputMode]     = useState("code");
  const [generatedOutput,setGeneratedOutput]= useState(null);
  const [sandboxHtml,    setSandboxHtml]    = useState("");
  const [showSandbox,    setShowSandbox]    = useState(false);

  // MCP
  const [mcpTools,       setMcpTools]       = useState(MCP_REGISTRY);
  const [mcpFilter,      setMcpFilter]      = useState("all");

  // Memory / RAG
  const [memories,       setMemories]       = useState([]);
  const [ragResults,     setRagResults]     = useState([]);
  const [vectorStore,    setVectorStore]    = useState([]);
  const [showRag,        setShowRag]        = useState(false);

  // Debug
  const [debugMode,      setDebugMode]      = useState(false);
  const [debugPermanent, setDebugPermanent] = useState(false);
  const [debugErrors,    setDebugErrors]    = useState([]);
  const [debugIteration, setDebugIteration] = useState(0);
  const [autoDebugRunning,setAutoDebugRunning]=useState(false);

  // Network
  const [networkInfo,    setNetworkInfo]    = useState(null);
  const [networkLog,     setNetworkLog]     = useState([]);

  // Observability (LangSmith-like traces)
  const [traces,         setTraces]         = useState([]);
  const [totalTokens,    setTotalTokens]    = useState(0);
  const [totalCost,      setTotalCost]      = useState(0);

  // GitHub
  const [githubRepo,     setGithubRepo]     = useState("");
  const [githubData,     setGithubData]     = useState(null);
  const [githubLoading,  setGithubLoading]  = useState(false);

  // API Key Manager
  const [apiKeys,        setApiKeys]        = useState([]); // [{id, providerId, label, encKey, addedAt, lastUsed}]
  const [showKeyMgr,     setShowKeyMgr]     = useState(false);
  const [keyForm,        setKeyForm]        = useState({ providerId:"", customLabel:"", keyValue:"", envVar:"" });
  const [keySearch,      setKeySearch]      = useState("");
  const [revealedKeys,   setRevealedKeys]   = useState(new Set());
  const [autoDetected,   setAutoDetected]   = useState([]); // provider ids detected in current input
  const [lastInjected,   setLastInjected]   = useState([]); // keys auto-used in last call

  // Context7 — fetched library docs
  const [context7Cache,  setContext7Cache]  = useState({});

  // Web Access
  const [webAccess,      setWebAccess]      = useState(false);
  const [webAccessLog,   setWebAccessLog]   = useState([]); // [{id,url,method,status,time,bytes}]
  const [webProxyMode,   setWebProxyMode]   = useState("direct"); // "direct"|"brave"|"firecrawl"
  const [webSearchQuery, setWebSearchQuery] = useState("");
  const [webSearchResults,setWebSearchResults]=useState([]);
  const [webSearchLoading,setWebSearchLoading]=useState(false);

  // File System Access (File System Access API)
  const [fsPermission,   setFsPermission]   = useState("denied");  // "denied"|"granted"|"requesting"
  const [fsHandle,       setFsHandle]       = useState(null);       // DirectoryFileSystemHandle
  const [fsRootPath,     setFsRootPath]     = useState("");         // display path
  const [fsCustomPath,   setFsCustomPath]   = useState("");         // manual typed path
  const [fsTree,         setFsTree]         = useState([]);         // [{name,kind,path,handle,children}]
  const [fsLoading,      setFsLoading]      = useState(false);
  const [fsSelected,     setFsSelected]     = useState(null);       // selected file handle
  const [fsFileContent,  setFsFileContent]  = useState("");         // open file content
  const [fsLog,          setFsLog]          = useState([]);         // file ops log
  const [fsOutputPath,   setFsOutputPath]   = useState("");         // fixed output path inside fsHandle
  const [showFsModal,    setShowFsModal]    = useState(false);

  // ── Terminal emulator ──────────────────────────────────────────────────────
  const [termLines,     setTermLines]     = useState([
    { id:uuid(), type:"system", text:"AgentStudio Terminal v2.0 — conectado al FS cuando acceso esté concedido" },
    { id:uuid(), type:"system", text:'Escribe "help" para ver comandos disponibles.' },
  ]);
  const [termInput,     setTermInput]     = useState("");
  const [termCwd,       setTermCwd]       = useState("/");
  const [termHistory,   setTermHistory]   = useState([]);
  const [termHistIdx,   setTermHistIdx]   = useState(-1);
  const termRef = useRef(null);
  const termInputRef = useRef(null);

  // ── Project Templates ──────────────────────────────────────────────────────
  const [showTemplates, setShowTemplates] = useState(false);
  const [templateSearch,setTemplateSearch]= useState("");
  const [templateLoading,setTemplateLoading]=useState(false);

  // ── Voice Input (Web Speech API) ──────────────────────────────────────────
  const [voiceActive,   setVoiceActive]   = useState(false);
  const [voiceSupported,setVoiceSupported]= useState(false);
  const [voiceTranscript,setVoiceTranscript]=useState("");
  const recognitionRef = useRef(null);

  // ── Prompt Library ────────────────────────────────────────────────────────
  const [savedPrompts,  setSavedPrompts]  = useState([]);
  const [showPromptLib, setShowPromptLib] = useState(false);
  const [promptSearch,  setPromptSearch]  = useState("");
  const [promptForm,    setPromptForm]    = useState({ title:"", content:"", tags:"" });

  // ── Model Comparison ──────────────────────────────────────────────────────
  const [compareMode,    setCompareMode]    = useState(false);
  const [compareModelB,  setCompareModelB]  = useState("claude");
  const [compareRespB,   setCompareRespB]   = useState(null);
  const [compareLoading, setCompareLoading] = useState(false);

  // ── 🪄 Prompt Auto-Enhancer ────────────────────────────────────────────────
  const [enhancing,      setEnhancing]      = useState(false);
  const [enhancePreview, setEnhancePreview] = useState(null); // {original, enhanced}
  const [showEnhance,    setShowEnhance]    = useState(false);

  // ── ⚡ Code Runner ──────────────────────────────────────────────────────────
  const [runnerCode,     setRunnerCode]     = useState("");
  const [runnerLang,     setRunnerLang]     = useState("javascript");
  const [runnerOutput,   setRunnerOutput]   = useState([]);  // [{type,text,time}]
  const [runnerRunning,  setRunnerRunning]  = useState(false);
  const [showRunner,     setShowRunner]     = useState(false);
  const [runnerSrcDoc,   setRunnerSrcDoc]   = useState("");
  const runnerIframeRef  = useRef(null);

  // ── 📊 Token Budget ─────────────────────────────────────────────────────────
  const [tokenBudget,    setTokenBudget]    = useState(200000); // claude 200k
  const [compressing,    setCompressing]    = useState(false);
  const [showTokenBar,   setShowTokenBar]   = useState(true);

  // ── 🔬 Self-Review ──────────────────────────────────────────────────────────
  const [selfReview,     setSelfReview]     = useState(null);  // {scores,issues,fixed}
  const [autoReview,     setAutoReview]     = useState(false);
  const [reviewing,      setReviewing]      = useState(false);
  const [showReview,     setShowReview]     = useState(false);

  // ── 📚 Snippet Bank ─────────────────────────────────────────────────────────
  const [snippets,       setSnippets]       = useState([]);  // [{id,lang,code,label,tags,from,addedAt,pinned}]
  const [snippetSearch,  setSnippetSearch]  = useState("");
  const [snippetFilter,  setSnippetFilter]  = useState("all");
  const [showSnippets,   setShowSnippets]   = useState(false);
  const [snippetPinned,  setSnippetPinned]  = useState(false);

  // ── 🌊 Streaming ───────────────────────────────────────────────────────────
  const [streamEnabled,  setStreamEnabled]  = useState(true);
  const [streamContent,  setStreamContent]  = useState("");   // live content while streaming
  const [streamMsgId,    setStreamMsgId]    = useState(null); // id of msg being streamed
  const abortCtrlRef = useRef(null);

  // ── 🤖 Custom Agent Builder ────────────────────────────────────────────────
  const [customAgents,   setCustomAgents]   = useState([]);   // [{id,name,icon,color,systemPrompt,model,temp,mcpTools,createdAt}]
  const [showAgentBuilder,setShowAgentBuilder]=useState(false);
  const [editingAgent,   setEditingAgent]   = useState(null); // null = new, id = edit
  const [agentForm,      setAgentForm]      = useState({ name:"", icon:"🤖", color:"#00f5a0", systemPrompt:"", model:"claude", temperature:0.7, description:"" });
  const [activeCustomAgent,setActiveCustomAgent]=useState(null); // id of selected custom agent

  // ── 📈 Analytics Dashboard ─────────────────────────────────────────────────
  const [showAnalytics,  setShowAnalytics]  = useState(false);
  const [analyticsTab,   setAnalyticsTab]   = useState("overview"); // overview|cost|quality|langs

  // ── 🌿 Conversation Branching ──────────────────────────────────────────────
  const [branches,       setBranches]       = useState([{ id:"main", label:"main", messages:[], createdAt:new Date().toLocaleString("es") }]);
  const [activeBranch,   setActiveBranch]   = useState("main");
  const [showBranches,   setShowBranches]   = useState(false);
  const [branchingFrom,  setBranchingFrom]  = useState(null); // {msgIndex, msgId}

  // ── 🔀 Smart Diff ──────────────────────────────────────────────────────────
  const [showDiff,       setShowDiff]       = useState(false);
  const [diffData,       setDiffData]       = useState(null); // {before, after, lang, stats}
  const [diffAutoMode,   setDiffAutoMode]   = useState(true); // auto-compute on new code

  // UI
  const [sidebarTab,     setSidebarTab]     = useState("models");
  const [rightPanel,     setRightPanel]     = useState("observe");
  const [showMemPanel,   setShowMemPanel]   = useState(false);
  const [sidebarCollapsed,setSidebarCollapsed]=useState(false);

  const chatRef = useRef(null);
  const inputRef= useRef(null);

  // ─── PERSISTENCE ────────────────────────────────────────────────────────────
  const persist = useCallback(async (key, val) => {
    try { await window.storage?.set(key, JSON.stringify(val)); } catch {}
  }, []);
  const hydrate = useCallback(async (key) => {
    try { const r = await window.storage?.get(key); return r ? JSON.parse(r.value) : null; } catch { return null; }
  }, []);

  // ─── INIT ───────────────────────────────────────────────────────────────────
  useEffect(() => {
    (async () => {
      const [msgs, mems, vecs, dbg, dbgP, mode, model, toks, cost, trc, keys] = await Promise.all([
        hydrate("v2:messages"), hydrate("v2:memories"), hydrate("v2:vectors"),
        hydrate("v2:debugErrors"), hydrate("v2:debugPermanent"),
        hydrate("v2:outputMode"), hydrate("v2:selectedModel"),
        hydrate("v2:totalTokens"), hydrate("v2:totalCost"), hydrate("v2:traces"),
        hydrate("v2:apiKeys"),
      ]);
      if (msgs)  setMessages(msgs);
      if (mems)  setMemories(mems);
      if (vecs)  setVectorStore(vecs);
      if (dbg)   setDebugErrors(dbg);
      if (dbgP?.on) { setDebugPermanent(true); setDebugMode(true); }
      if (mode?.v)  setOutputMode(mode.v);
      if (model?.v) setSelectedModel(model.v);
      if (toks?.v)  setTotalTokens(toks.v);
      if (cost?.v)  setTotalCost(cost.v);
      if (trc)      setTraces(trc);
      if (keys)     setApiKeys(keys);
      // Load saved prompts
      const sp = await hydrate("v2:savedPrompts");
      if (sp) setSavedPrompts(sp);
      const snips = await hydrate("v2:snippets");
      if (snips) setSnippets(snips);
      const ar = await hydrate("v2:autoReview");
      if (ar?.on) setAutoReview(true);
      const ca = await hydrate("v2:customAgents");
      if (ca) setCustomAgents(ca);
      const brch = await hydrate("v2:branches");
      if (brch) setBranches(brch);
      // Detect voice support
      if ("webkitSpeechRecognition" in window || "SpeechRecognition" in window) setVoiceSupported(true);
      fetchOllamaModels();
      checkNetwork();
    })();
  }, []);

  // ── Token budget real-time estimate ─────────────────────────────────────────
  const estimatedTokens = useMemo(() => {
    const text = messages.map(m => m.content).join(" ") + input;
    return Math.ceil(text.length / 3.8); // GPT-4 tokenizer approximation
  }, [messages, input]);

  const tokenPct = Math.min(100, Math.round((estimatedTokens / tokenBudget) * 100));
  const tokenColor = tokenPct > 80 ? "#ef4444" : tokenPct > 60 ? "#f59e0b" : "#00f5a0";

  // ── Code runner: listen to iframe console messages ───────────────────────────
  useEffect(() => {
    const handler = (e) => {
      if (e.data?.type === "runner-log") {
        setRunnerOutput(prev => [...prev, { id:uuid(), type:e.data.level||"log", text:String(e.data.args?.join(" ")||""), time:ts() }]);
      }
      if (e.data?.type === "runner-error") {
        setRunnerOutput(prev => [...prev, { id:uuid(), type:"error", text:e.data.message, time:ts() }]);
      }
    };
    window.addEventListener("message", handler);
    return () => window.removeEventListener("message", handler);
  }, []);

  // ── Auto-extract snippets from new AI messages ───────────────────────────────
  useEffect(() => {
    const lastAI = messages.filter(m => m.role === "assistant" && !m._snippetsExtracted).slice(-1)[0];
    if (!lastAI) return;
    const extMap={javascript:"js",typescript:"ts",python:"py",jsx:"jsx",tsx:"tsx",html:"html",css:"css",json:"json",yaml:"yml",sh:"sh",sql:"sql",rust:"rs",go:"go",vue:"vue",svelte:"svelte",markdown:"md"};
    const re = /```(\w+)\n([\s\S]*?)```/g;
    let m; const found = [];
    while ((m = re.exec(lastAI.content)) !== null) {
      const lang = m[1].toLowerCase();
      const code = m[2].trim();
      if (code.length < 20) continue;
      found.push({ id:uuid(), lang, ext:extMap[lang]||"txt", code, label:code.split("\n")[0].replace(/^\/\/\s*/,"").slice(0,60)||`${lang} snippet`, tags:[lang], from:lastAI.time||ts(), addedAt:ts(), pinned:false, usedCount:0 });
    }
    if (found.length) {
      setSnippets(prev => [...found, ...prev].slice(0, 500));
      setMessages(prev => prev.map(msg => msg.id === lastAI.id ? {...msg, _snippetsExtracted:true} : msg));
    }
  }, [messages]);

  // Auto-scroll terminal
  useEffect(() => { termRef.current?.scrollTo({top:termRef.current.scrollHeight,behavior:"smooth"}); }, [termLines]);

  // Auto-scroll chat
  useEffect(() => { chatRef.current?.scrollTo({top:chatRef.current.scrollHeight,behavior:"smooth"}); }, [messages, loading, streamContent]);

  // Auto-compute diff when new AI message arrives
  useEffect(() => {
    if (!diffAutoMode) return;
    const aiMsgs = messages.filter(m => m.role==="assistant" && m.content.includes("```"));
    if (aiMsgs.length < 2) return;
    const extractCode = (msg) => { const m=msg.content.match(/```(\w+)\n([\s\S]*?)```/); return m?{lang:m[1],code:m[2].trim()}:null; };
    const latest = extractCode(aiMsgs[aiMsgs.length-1]);
    const prev   = extractCode(aiMsgs[aiMsgs.length-2]);
    if (!latest||!prev||latest.lang!==prev.lang) return;
    const diff = computeDiff(prev.code, latest.code);
    if (diff.changed > 0) setDiffData({ before:prev.code, after:latest.code, lang:latest.lang, stats:diff });
  }, [messages, diffAutoMode]);

  // Persist on change
  useEffect(() => { persist("v2:messages",    messages);    }, [messages]);
  useEffect(() => { persist("v2:memories",    memories);    }, [memories]);
  useEffect(() => { persist("v2:vectors",     vectorStore); }, [vectorStore]);
  useEffect(() => { persist("v2:debugErrors", debugErrors); }, [debugErrors]);
  useEffect(() => { persist("v2:debugPermanent",{on:debugPermanent}); }, [debugPermanent]);
  useEffect(() => { persist("v2:outputMode",  {v:outputMode});  }, [outputMode]);
  useEffect(() => { persist("v2:selectedModel",{v:selectedModel}); }, [selectedModel]);
  useEffect(() => { persist("v2:totalTokens", {v:totalTokens}); }, [totalTokens]);
  useEffect(() => { persist("v2:totalCost",   {v:totalCost});   }, [totalCost]);
  useEffect(() => { persist("v2:traces",      traces.slice(0,200)); }, [traces]);
  useEffect(() => { persist("v2:apiKeys",     apiKeys); }, [apiKeys]);
  useEffect(() => { persist("v2:savedPrompts",savedPrompts); }, [savedPrompts]);
  useEffect(() => { persist("v2:snippets",    snippets.slice(0,500)); }, [snippets]);
  useEffect(() => { persist("v2:autoReview",  {on:autoReview}); }, [autoReview]);
  useEffect(() => { persist("v2:customAgents",customAgents); }, [customAgents]);
  useEffect(() => { persist("v2:branches",    branches.map(b=>({...b,messages:b.messages.slice(-100)}))); }, [branches]);

  // ─── OLLAMA ─────────────────────────────────────────────────────────────────
  const fetchOllamaModels = async () => {
    setOllamaStatus("checking");
    try {
      const res = await fetch(`${OLLAMA_BASE}/api/tags`, { signal: AbortSignal.timeout(3000) });
      if (res.ok) {
        const d = await res.json();
        setOllamaModels(d.models || []);
        setOllamaStatus("online");
        netLog("Ollama", "GET /api/tags", "200 OK", 0);
      }
    } catch {
      setOllamaStatus("offline");
      setOllamaModels(OSS_MODELS.map(m => ({ name: m.id, _meta: m, _cached: true, size: 0 })));
      netLog("Ollama", "GET /api/tags", "offline — showing cache", 0);
    }
  };

  // ─── NETWORK ────────────────────────────────────────────────────────────────
  const checkNetwork = async () => {
    const start = now();
    try {
      await fetch(ANTHROPIC_BASE, { method:"HEAD", signal:AbortSignal.timeout(4000) });
      const lat = now() - start;
      setNetworkInfo({ anthropic:true, ollama:ollamaStatus==="online", internet:true, latency:`${lat}ms`, checked:ts() });
      netLog("Network", "Connectivity check", "Online", lat);
    } catch {
      setNetworkInfo({ anthropic:false, ollama:false, internet:false, latency:"—", checked:ts() });
      netLog("Network", "Connectivity check", "Offline", 0);
    }
  };

  // ─── WEB ACCESS ─────────────────────────────────────────────────────────────

  const toggleWebAccess = () => {
    setWebAccess(p => {
      const next = !p;
      setWebAccessLog(prev => [{id:uuid(),url:next?"Web access ENABLED":"Web access DISABLED",method:"—",status:next?"ON":"OFF",bytes:0,time:ts()},...prev.slice(0,199)]);
      return next;
    });
  };

  const addWebLog = (url, method, status, bytes) =>
    setWebAccessLog(prev => [{id:uuid(),url,method,status,bytes,time:ts()},...prev.slice(0,199)]);

  const webFetchForAgent = async (query) => {
    if (!webAccess) return null;
    const start = now();
    try {
      const res = await fetch(ANTHROPIC_BASE, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:MODEL_CLAUDE, max_tokens:800, messages:[{role:"user",content:`Search the web and return a concise factual summary (max 300 words) for: ${query}`}] })
      });
      const d = await res.json();
      const result = d.content?.[0]?.text || "";
      addWebLog(`Search: ${query.slice(0,50)}`, "GET", "200 OK", JSON.stringify(d).length);
      netLog("WebAgent", query.slice(0,40), "200 OK", now()-start);
      return result;
    } catch(e) { addWebLog(`Search: ${query.slice(0,50)}`, "GET", `ERR: ${e.message}`, 0); return null; }
  };

  const agentWebSearch = async () => {
    if (!webSearchQuery.trim() || !webAccess) return;
    setWebSearchLoading(true);
    const result = await webFetchForAgent(webSearchQuery);
    if (result) setWebSearchResults(prev => [{id:uuid(),query:webSearchQuery,result,time:ts()},...prev.slice(0,49)]);
    setWebSearchLoading(false);
    setWebSearchQuery("");
  };

  // ─── FILE SYSTEM ACCESS API ─────────────────────────────────────────────────

  const requestFsAccess = async () => {
    if (!("showDirectoryPicker" in window)) {
      setFsPermission("denied");
      setFsLog(prev => [{id:uuid(),op:"ERROR",path:"showDirectoryPicker",status:"Requiere Chrome/Edge 86+",time:ts(),color:"#ef4444"},...prev]);
      return;
    }
    setFsPermission("requesting");
    try {
      const handle = await window.showDirectoryPicker({ mode:"readwrite", startIn:"desktop" });
      setFsHandle(handle);
      setFsRootPath(handle.name);
      setFsPermission("granted");
      setFsLog(prev => [{id:uuid(),op:"ACCESS",path:handle.name,status:"✓ Permiso readwrite concedido",time:ts(),color:"#f59e0b"},...prev]);
      netLog("FileSystem", `Dir: ${handle.name}`, "granted", 0);
      setFsLoading(true);
      await buildFsTree(handle, "", 0);
      setFsLoading(false);
      setRightPanel("files");
    } catch(e) {
      setFsPermission("denied");
      setFsLog(prev => [{id:uuid(),op:"ERROR",path:"showDirectoryPicker",status:e.name==="AbortError"?"Cancelado por usuario":e.message,time:ts(),color:"#ef4444"},...prev]);
    }
  };

  const buildFsTree = async (dirHandle, path, depth) => {
    if (depth > 3) return [];
    const entries = [];
    try {
      for await (const [name, handle] of dirHandle.entries()) {
        const fullPath = path ? `${path}/${name}` : name;
        const node = { id:uuid(), name, kind:handle.kind, path:fullPath, handle };
        if (handle.kind==="directory" && depth<2) node.children = await buildFsTree(handle, fullPath, depth+1);
        entries.push(node);
      }
      entries.sort((a,b) => a.kind===b.kind?a.name.localeCompare(b.name):a.kind==="directory"?-1:1);
    } catch {}
    if (depth===0) setFsTree(entries);
    return entries;
  };

  const refreshFsTree = async () => {
    if (!fsHandle) return;
    setFsLoading(true);
    await buildFsTree(fsHandle, "", 0);
    setFsLoading(false);
  };

  const addFsLog = (op, path, status) => {
    const c={WRITE:"#00f5a0",MKDIR:"#06b6d4",READ:"#7c3aed",DELETE:"#ef4444",ACCESS:"#f59e0b",ERROR:"#ef4444",ERR:"#ef4444"};
    setFsLog(prev => [{id:uuid(),op,path,status,time:ts(),color:c[op]||"#888"},...prev.slice(0,299)]);
  };

  const fsWriteFile = async (filePath, content) => {
    if (!fsHandle) return false;
    try {
      const parts = filePath.replace(/^\/+/,"").split("/").filter(Boolean);
      let cur = fsHandle;
      for (let i=0; i<parts.length-1; i++) cur = await cur.getDirectoryHandle(parts[i],{create:true});
      const fh = await cur.getFileHandle(parts[parts.length-1],{create:true});
      const w = await fh.createWritable();
      await w.write(content);
      await w.close();
      addFsLog("WRITE", filePath, `✓ ${(content.length/1024).toFixed(1)} KB`);
      return true;
    } catch(e) { addFsLog("ERR", filePath, e.message); return false; }
  };

  const fsCreateFolder = async (folderPath) => {
    if (!fsHandle) return false;
    try {
      const parts = folderPath.replace(/^\/+/,"").split("/").filter(Boolean);
      let cur = fsHandle;
      for (const p of parts) cur = await cur.getDirectoryHandle(p,{create:true});
      addFsLog("MKDIR", folderPath, "✓ Carpeta creada");
      await refreshFsTree();
      return true;
    } catch(e) { addFsLog("ERR", folderPath, e.message); return false; }
  };

  const fsReadFile = async (fileHandle, displayPath) => {
    try {
      const file = await fileHandle.getFile();
      const text = await file.text();
      setFsFileContent(text);
      setFsSelected({handle:fileHandle, path:displayPath||fileHandle.name});
      addFsLog("READ", displayPath||fileHandle.name, `✓ ${(text.length/1024).toFixed(1)} KB`);
      return text;
    } catch(e) { addFsLog("ERR", displayPath||"?", e.message); return null; }
  };

  const fsDeleteEntry = async (node) => {
    if (!fsHandle) return;
    try {
      const parts = node.path.replace(/^\/+/,"").split("/").filter(Boolean);
      let cur = fsHandle;
      for (let i=0; i<parts.length-1; i++) cur = await cur.getDirectoryHandle(parts[i]);
      if (node.kind==="directory") await cur.removeEntry(parts[parts.length-1],{recursive:true});
      else await cur.removeEntry(parts[parts.length-1]);
      addFsLog("DELETE", node.path, "✓ Eliminado");
      if (fsSelected?.path===node.path) { setFsSelected(null); setFsFileContent(""); }
      await refreshFsTree();
    } catch(e) { addFsLog("ERR", node.path, e.message); }
  };

  // ─── WRITE AI OUTPUT → FILESYSTEM ────────────────────────────────────────────

  const writeProjectToFs = async (aiResponse) => {
    if (fsPermission !== "granted") return 0;
    const base = (fsOutputPath||"AgentStudio-Output").replace(/\/+$/,"");
    let written = 0;
    const extMap={javascript:"js",typescript:"ts",python:"py",rust:"rs",go:"go",java:"java",css:"css",jsx:"jsx",tsx:"tsx",html:"html",json:"json",yaml:"yml",sh:"sh",bash:"sh",sql:"sql",markdown:"md",vue:"vue",svelte:"svelte"};

    // 1. Multi-file: // === ARCHIVO: path ===
    const re = /\/\/\s*===\s*ARCHIVO:\s*(.+?)\s*===([\s\S]*?)(?=\/\/\s*===\s*ARCHIVO:|$)/gi;
    let m; const files=[];
    while ((m=re.exec(aiResponse))!==null) files.push({path:m[1].trim(),content:m[2].trim()});
    for (const f of files) { await fsWriteFile(`${base}/${f.path}`,f.content); written++; }

    // 2. Fenced code blocks
    if (!written) {
      const codeRe = /```(\w+)\n([\s\S]*?)```/g;
      let idx=0;
      while ((m=codeRe.exec(aiResponse))!==null) {
        const ext=extMap[m[1].toLowerCase()]||"txt";
        await fsWriteFile(`${base}/${idx===0?`output.${ext}`:`output_${idx}.${ext}`}`,m[2].trim());
        written++; idx++;
      }
    }

    if (written>0) {
      addFsLog("WRITE",`${base}/ (${written} archivo${written>1?"s":""})`,`✓ Guardado en escritorio`);
      await refreshFsTree();
    }
    return written;
  };

  // ─── TERMINAL EMULATOR ───────────────────────────────────────────────────────

  const termPrint = (text, type="output") => {
    setTermLines(prev => [...prev, { id:uuid(), type, text }].slice(-500));
    setTimeout(() => { termRef.current?.scrollTo({top:termRef.current.scrollHeight,behavior:"smooth"}); }, 30);
  };

  const executeTermCmd = useCallback(async (rawCmd) => {
    const cmd = rawCmd.trim();
    if (!cmd) return;
    setTermHistory(p => [cmd, ...p.slice(0,99)]);
    setTermHistIdx(-1);
    termPrint(`${fsRootPath||"~"}${termCwd} $ ${cmd}`, "prompt");

    const [prog, ...args] = cmd.split(/\s+/);
    const arg0 = args[0] || "";

    const termHelp = () => termPrint([
      "Comandos disponibles:", "  ls [dir]        — Listar contenido", "  cd <dir>        — Cambiar directorio",
      "  mkdir <dir>     — Crear carpeta",  "  touch <file>    — Crear archivo vacío",
      "  cat <file>      — Ver contenido de archivo", "  echo <text>     — Imprimir texto",
      "  rm <path>       — Eliminar archivo/carpeta", "  pwd             — Mostrar ruta actual",
      "  clear           — Limpiar terminal", "  write <f> <txt> — Escribir en archivo",
      "  ask <prompt>    — Preguntar al agente AI", "  generate <type> — Generar código (react|api|html|py)",
      "  models          — Listar modelos disponibles", "  mcpls           — Listar MCP tools activos",
      "  status          — Estado del sistema", "  help            — Esta ayuda",
    ].join("\n"), "system");

    switch (prog) {
      case "help": termHelp(); break;
      case "clear": setTermLines([]); break;
      case "pwd":   termPrint(fsPermission==="granted" ? `/${fsRootPath}${termCwd}` : "~/ (sin acceso FS)"); break;
      case "echo":  termPrint(args.join(" ")); break;
      case "models": termPrint(["Modelos disponibles:", "  ⬡ claude-sonnet-4 (Anthropic)", ...ollamaModels.map(m=>`  ⚡ ${m.name} ${m._cached?"[cache]":"[local]"}`)].join("\n"), "system"); break;
      case "mcpls": termPrint(["MCP tools activos:", ...mcpTools.filter(t=>t.enabled).map(t=>`  ${t.icon} ${t.name} — ${t.cmd}`)].join("\n"), "system"); break;
      case "status": termPrint([
        `Sistema: AgentStudio v2.0`, `Modelo: ${selectedModel}`, `Modo: ${outputMode}`,
        `Ollama: ${ollamaStatus}`, `FS: ${fsPermission}${fsPermission==="granted"?` (${fsRootPath})`:""}`,
        `Web: ${webAccess?"activo":"inactivo"}`, `MCP: ${mcpTools.filter(t=>t.enabled).length} activos`,
        `Keys: ${apiKeys.length} guardadas`, `Tokens: ${totalTokens.toLocaleString()}`, `Costo: $${totalCost.toFixed(4)}`,
      ].join("\n"), "system"); break;

      case "ls": {
        if (fsPermission !== "granted") { termPrint("Sin acceso al FS. Haz click en 📁 FILES en el header.", "error"); break; }
        try {
          const target = termCwd === "/" ? fsHandle : await (async()=>{
            const p=termCwd.replace(/^\//,"").split("/").filter(Boolean); let c=fsHandle;
            for(const s of p) c=await c.getDirectoryHandle(s); return c;
          })();
          const entries = [];
          for await (const [name, handle] of target.entries()) {
            entries.push(`${handle.kind==="directory"?"📁 ":"📄 "}${name}`);
          }
          termPrint(entries.length ? entries.sort().join("\n") : "(vacío)"); } catch(e) { termPrint(e.message,"error"); }
        break;
      }
      case "cd": {
        if (!arg0 || arg0 === "~") { setTermCwd("/"); termPrint("~"); break; }
        if (arg0 === "..") {
          const parts = termCwd.replace(/^\//,"").split("/").filter(Boolean);
          parts.pop(); setTermCwd("/" + parts.join("/"));
          termPrint(parts.join("/") || "/");
        } else {
          setTermCwd(prev => { const next=(prev==="/"?"":prev)+"/"+arg0; return next; });
          termPrint(`→ ${termCwd}/${arg0}`);
        }
        break;
      }
      case "mkdir": {
        if (!arg0) { termPrint("Uso: mkdir <nombre>","error"); break; }
        const path = (termCwd==="/"?"":termCwd)+"/"+arg0;
        const ok = await fsCreateFolder(path.replace(/^\//,""));
        termPrint(ok ? `✓ Carpeta creada: ${path}` : "Error al crear carpeta", ok?"output":"error");
        break;
      }
      case "touch": {
        if (!arg0) { termPrint("Uso: touch <archivo>","error"); break; }
        const fpath = (termCwd==="/"?"":termCwd)+"/"+arg0;
        const ok = await fsWriteFile(fpath.replace(/^\//,""), "");
        termPrint(ok ? `✓ Archivo creado: ${fpath}` : "Error al crear archivo", ok?"output":"error");
        break;
      }
      case "cat": {
        if (fsPermission !== "granted") { termPrint("Sin acceso FS","error"); break; }
        try {
          const parts = ((termCwd==="/"?"":termCwd)+"/"+arg0).replace(/^\//,"").split("/").filter(Boolean);
          let cur = fsHandle;
          for (let i=0; i<parts.length-1; i++) cur = await cur.getDirectoryHandle(parts[i]);
          const fh = await cur.getFileHandle(parts[parts.length-1]);
          const file = await fh.getFile();
          const text = await file.text();
          termPrint(text.slice(0,2000) + (text.length>2000?"\n...(truncado)":""));
        } catch(e) { termPrint(e.message,"error"); }
        break;
      }
      case "write": {
        if (args.length < 2) { termPrint("Uso: write <archivo> <contenido>","error"); break; }
        const [wFile, ...wContent] = args;
        const wPath = (termCwd==="/"?"":termCwd)+"/"+wFile;
        const ok = await fsWriteFile(wPath.replace(/^\//,""), wContent.join(" "));
        termPrint(ok ? `✓ Escrito: ${wPath}` : "Error al escribir", ok?"output":"error");
        break;
      }
      case "rm": {
        const rpath = ((termCwd==="/"?"":termCwd)+"/"+arg0).replace(/^\//,"");
        const parts = rpath.split("/").filter(Boolean);
        try {
          let cur = fsHandle;
          for (let i=0; i<parts.length-1; i++) cur = await cur.getDirectoryHandle(parts[i]);
          await cur.removeEntry(parts[parts.length-1], {recursive:true});
          termPrint(`✓ Eliminado: ${arg0}`);
          await refreshFsTree();
        } catch(e) { termPrint(e.message,"error"); }
        break;
      }
      case "ask": {
        if (!args.length) { termPrint("Uso: ask <prompt>","error"); break; }
        termPrint("⌛ Consultando al agente...", "system");
        try {
          const res = await fetch(ANTHROPIC_BASE, {
            method:"POST", headers:{"Content-Type":"application/json"},
            body: JSON.stringify({ model:MODEL_CLAUDE, max_tokens:600, messages:[{role:"user",content:args.join(" ")}] })
          });
          const d = await res.json();
          termPrint(d.content?.[0]?.text||"Sin respuesta");
        } catch(e) { termPrint(e.message,"error"); }
        break;
      }
      case "generate": {
        const genMap = { react:"Genera un componente React funcional completo y moderno", api:"Genera una API REST con Express.js completa", html:"Genera una landing page HTML/CSS/JS moderna", py:"Genera un script Python bien documentado" };
        const prompt = genMap[arg0] || `Genera código de tipo: ${arg0}`;
        termPrint(`⌛ Generando ${arg0||"código"}...`, "system");
        setInput(prompt);
        termPrint(`✓ Prompt enviado al chat. Presiona Enter para ejecutar.`, "system");
        break;
      }
      default: termPrint(`Comando no reconocido: "${prog}". Escribe "help" para ver comandos.`, "error");
    }
  }, [fsHandle, fsPermission, fsRootPath, termCwd, ollamaModels, mcpTools, selectedModel, outputMode, webAccess, apiKeys, totalTokens, totalCost, ollamaStatus]);

  const handleTermKey = (e) => {
    if (e.key === "Enter") { executeTermCmd(termInput); setTermInput(""); }
    else if (e.key === "ArrowUp") {
      const idx = Math.min(termHistIdx + 1, termHistory.length - 1);
      setTermHistIdx(idx); setTermInput(termHistory[idx] || "");
    } else if (e.key === "ArrowDown") {
      const idx = Math.max(termHistIdx - 1, -1);
      setTermHistIdx(idx); setTermInput(idx === -1 ? "" : termHistory[idx] || "");
    } else if (e.key === "Tab") {
      e.preventDefault();
      const cmds = ["ls","cd","mkdir","touch","cat","rm","write","echo","ask","generate","models","mcpls","status","clear","help","pwd"];
      const match = cmds.find(c => c.startsWith(termInput));
      if (match) setTermInput(match + " ");
    }
  };

  // ─── VOICE INPUT ──────────────────────────────────────────────────────────

  const toggleVoice = () => {
    if (!voiceSupported) return;
    if (voiceActive) {
      recognitionRef.current?.stop();
      setVoiceActive(false);
    } else {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
      const rec = new SR();
      rec.lang = "es-ES";
      rec.continuous = true;
      rec.interimResults = true;
      rec.onresult = (e) => {
        let final = "", interim = "";
        for (let i = e.resultIndex; i < e.results.length; i++) {
          if (e.results[i].isFinal) final += e.results[i][0].transcript;
          else interim += e.results[i][0].transcript;
        }
        if (final) { setInput(p => p + final + " "); setVoiceTranscript(""); }
        else setVoiceTranscript(interim);
      };
      rec.onerror = () => { setVoiceActive(false); setVoiceTranscript(""); };
      rec.onend   = () => { setVoiceActive(false); setVoiceTranscript(""); };
      rec.start();
      recognitionRef.current = rec;
      setVoiceActive(true);
    }
  };

  // ─── ZIP EXPORT ───────────────────────────────────────────────────────────

  const downloadZip = useCallback(() => {
    // Build all generated files from last AI response
    const lastAI = messages.filter(m=>m.role==="assistant").slice(-1)[0];
    if (!lastAI) return;
    const content = lastAI.content;
    const files = [];
    const re = /\/\/\s*===\s*ARCHIVO:\s*(.+?)\s*===([\s\S]*?)(?=\/\/\s*===\s*ARCHIVO:|$)/gi;
    let m;
    while ((m=re.exec(content))!==null) files.push({name:m[1].trim(),data:m[2].trim()});
    if (!files.length) {
      const extMap={javascript:"js",typescript:"ts",python:"py",jsx:"jsx",tsx:"tsx",html:"html",css:"css",json:"json",yaml:"yml",sh:"sh",sql:"sql",markdown:"md"};
      const codeRe=/```(\w+)\n([\s\S]*?)```/g; let idx=0;
      while((m=codeRe.exec(content))!==null){
        const ext=extMap[m[1].toLowerCase()]||"txt";
        files.push({name:idx===0?`output.${ext}`:`output_${idx}.${ext}`,data:m[2].trim()});
        idx++;
      }
    }
    if (!files.length) { termPrint("Sin archivos en la última respuesta para exportar.","error"); return; }

    // Build a simple ZIP-like bundle (tar-style in base64, or individual downloads)
    // For single file: direct download. For multi: download each or build manifest
    if (files.length === 1) {
      const blob = new Blob([files[0].data], { type:"text/plain" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = files[0].name.split("/").pop();
      a.click();
      URL.revokeObjectURL(a.href);
    } else {
      // Create a self-extracting HTML bundle
      const manifest = files.map(f=>`  📄 ${f.name} (${(f.data.length/1024).toFixed(1)} KB)`).join("\n");
      const encoded = files.map(f => `<!-- FILE:${f.name} -->\n${f.data}`).join("\n\n");
      const bundleHtml = `<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>AgentStudio Export</title>
<style>body{font-family:monospace;background:#080a0e;color:#c8cdd8;padding:20px}
h1{color:#00f5a0}pre{background:#0c0e14;border:1px solid #1a1d26;padding:12px;border-radius:8px;overflow:auto;max-height:300px}
button{background:#00f5a020;border:1px solid #00f5a040;color:#00f5a0;padding:6px 12px;border-radius:6px;cursor:pointer;margin:4px;font-family:monospace}
</style></head><body>
<h1>⬡ AgentStudio Export</h1>
<p>Generado: ${new Date().toLocaleString("es")} · ${files.length} archivos</p>
<pre>${manifest}</pre>
${files.map((f,i)=>`<button onclick="download(${i})">⬇ ${f.name.split("/").pop()}</button>`).join("")}
<script>
const files=${JSON.stringify(files)};
function download(i){const f=files[i];const b=new Blob([f.data],{type:"text/plain"});const a=document.createElement("a");a.href=URL.createObjectURL(b);a.download=f.name.split("/").pop();a.click();}
</script>
<hr style="border-color:#1a1d26;margin:20px 0">
${files.map(f=>`<h3 style="color:#7c3aed">📄 ${f.name}</h3><pre>${f.data.replace(/</g,"&lt;")}</pre>`).join("")}
</body></html>`;
      const blob = new Blob([bundleHtml],{type:"text/html"});
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `AgentStudio-Export-${Date.now()}.html`;
      a.click();
      URL.revokeObjectURL(a.href);
    }
  }, [messages]);

  // ─── PROMPT LIBRARY ───────────────────────────────────────────────────────

  const savePromptToLib = () => {
    if (!promptForm.content.trim()) return;
    const p = { id:uuid(), title:promptForm.title||promptForm.content.slice(0,40), content:promptForm.content, tags:promptForm.tags.split(",").map(t=>t.trim()).filter(Boolean), createdAt:new Date().toLocaleString("es"), usedCount:0 };
    setSavedPrompts(prev => [p, ...prev]);
    setPromptForm({title:"",content:"",tags:""});
  };
  const deletePrompt = (id) => setSavedPrompts(prev => prev.filter(p=>p.id!==id));
  const usePrompt = (p) => {
    setInput(p.content);
    setSavedPrompts(prev => prev.map(pr => pr.id===p.id ? {...pr,usedCount:pr.usedCount+1} : pr));
    setShowPromptLib(false);
    inputRef.current?.focus();
  };

  // ─── MODEL COMPARISON ─────────────────────────────────────────────────────

  const runComparison = useCallback(async (userText, historyMsgs) => {
    if (!compareMode || compareModelB===selectedModel) return;
    setCompareLoading(true);
    try {
      const sysPr = buildSystemPrompt("executor", [], "", []);
      let response = "";
      if (compareModelB === "claude") {
        const res = await fetch(ANTHROPIC_BASE,{method:"POST",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({model:MODEL_CLAUDE,max_tokens:2048,system:sysPr,messages:historyMsgs.slice(-10).map(m=>({role:m.role,content:m.content}))})});
        const d = await res.json();
        response = d.content?.[0]?.text||"";
      } else {
        const res = await fetch(`${OLLAMA_BASE}/api/chat`,{method:"POST",headers:{"Content-Type":"application/json"},
          body:JSON.stringify({model:compareModelB,messages:[{role:"system",content:sysPr},...historyMsgs.slice(-8).map(m=>({role:m.role,content:m.content}))],stream:false})});
        const d = await res.json();
        response = d.message?.content||"";
      }
      setCompareRespB({ content:response, model:compareModelB, time:ts() });
    } catch(e) { setCompareRespB({ content:`Error: ${e.message}`, model:compareModelB, time:ts(), isError:true }); }
    finally { setCompareLoading(false); }
  }, [compareMode, compareModelB, selectedModel]);

  // ─── PROJECT TEMPLATES ────────────────────────────────────────────────────

  const applyTemplate = async (tpl) => {
    setShowTemplates(false);
    setTemplateLoading(true);
    const prompt = `Genera el proyecto completo "${tpl.name}" con la siguiente estructura:\n${tpl.structure}\n\nRequisitos:\n${tpl.requirements}\n\nUsa el formato: // === ARCHIVO: ruta/nombre.ext === para cada archivo. Incluye package.json, README.md y código funcional completo listo para ejecutar.`;
    setInput(prompt);
    setOutputMode("project");
    setTemplateLoading(false);
    inputRef.current?.focus();
  };

  // ════════════════════════════════════════════════════════════════════════════
  // 🪄 PROMPT AUTO-ENHANCER
  // ════════════════════════════════════════════════════════════════════════════
  const enhancePrompt = async () => {
    if (!input.trim() || enhancing) return;
    setEnhancing(true);
    const original = input.trim();
    try {
      const res = await fetch(ANTHROPIC_BASE, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model: MODEL_CLAUDE, max_tokens: 800,
          messages:[{ role:"user", content:
`Eres un experto en prompt engineering. Convierte este prompt vago en un prompt detallado, estructurado y de alta calidad para un agente de IA.

PROMPT ORIGINAL: "${original}"

MODO ACTUAL: ${outputMode} ${outputMode==="project"?"(genera proyecto multi-archivo)":outputMode==="webapp"?"(genera web app completa)":""}

Devuelve SOLO el prompt mejorado (sin explicaciones, sin etiquetas, sin comillas alrededor). El prompt mejorado debe:
1. Especificar el stack tecnológico exacto
2. Listar todos los requisitos funcionales
3. Especificar estándares de calidad (TypeScript strict, error handling, etc.)
4. Indicar el diseño visual si aplica
5. Pedir tests si es código
Sé específico, técnico y completo. Máximo 300 palabras.`
          }]
        })
      });
      const d = await res.json();
      const enhanced = d.content?.[0]?.text?.trim() || original;
      setEnhancePreview({ original, enhanced });
      setShowEnhance(true);
    } catch(e) { netLog("Enhancer","enhance prompt",`ERR: ${e.message}`,0); }
    finally { setEnhancing(false); }
  };

  const applyEnhanced = () => { if (enhancePreview) { setInput(enhancePreview.enhanced); setShowEnhance(false); setEnhancePreview(null); inputRef.current?.focus(); } };
  const discardEnhanced = () => { setShowEnhance(false); setEnhancePreview(null); };

  // ════════════════════════════════════════════════════════════════════════════
  // ⚡ CODE RUNNER
  // ════════════════════════════════════════════════════════════════════════════
  const buildRunnerDoc = (code, lang) => {
    const consolePatch = `<script>
(function(){
  const orig={log:console.log,error:console.error,warn:console.warn,info:console.info};
  ['log','error','warn','info'].forEach(fn=>{
    console[fn]=(...args)=>{
      orig[fn](...args);
      try{window.parent.postMessage({type:'runner-log',level:fn,args:args.map(a=>typeof a==='object'?JSON.stringify(a,null,2):String(a))},'*');}catch(e){}
    };
  });
  window.onerror=(msg,src,line,col,err)=>{
    window.parent.postMessage({type:'runner-error',message:\`\${msg} (line \${line})\`},'*');
  };
  window.onunhandledrejection=(e)=>{
    window.parent.postMessage({type:'runner-error',message:\`Unhandled Promise: \${e.reason}\`},'*');
  };
})();
<\/script>`;

    if (lang === "html") {
      // Inject console patch into HTML
      return code.includes("</head>") ? code.replace("</head>", consolePatch+"</head>") : consolePatch + code;
    }
    return `<!DOCTYPE html><html><head><meta charset="utf-8">${consolePatch}</head><body style="background:#030406;color:#a8b4c8;font-family:monospace;padding:8px;margin:0">
<script>${code}<\/script></body></html>`;
  };

  const runCode = () => {
    if (!runnerCode.trim()) return;
    setRunnerOutput([{ id:uuid(), type:"system", text:`▶ Ejecutando ${runnerLang}...`, time:ts() }]);
    setRunnerRunning(true);
    const doc = buildRunnerDoc(runnerCode, runnerLang);
    setRunnerSrcDoc(doc);
    setTimeout(() => setRunnerRunning(false), 3000);
  };

  const loadCodeFromLastAI = () => {
    const last = messages.filter(m => m.role==="assistant").slice(-1)[0];
    if (!last) return;
    const m = last.content.match(/```(\w+)\n([\s\S]*?)```/);
    if (m) { setRunnerCode(m[2].trim()); setRunnerLang(m[1].toLowerCase()); }
  };

  // ════════════════════════════════════════════════════════════════════════════
  // 📊 TOKEN BUDGET MANAGER
  // ════════════════════════════════════════════════════════════════════════════
  const compressContext = async () => {
    if (messages.length < 6 || compressing) return;
    setCompressing(true);
    const toCompress = messages.slice(0, -4); // Keep last 4 messages intact
    const transcript = toCompress.map(m => `[${m.role.toUpperCase()}]: ${m.content.slice(0,400)}`).join("\n\n");
    try {
      const res = await fetch(ANTHROPIC_BASE, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model: MODEL_CLAUDE, max_tokens: 600,
          messages:[{ role:"user", content:
`Resume esta conversación en 3-5 puntos clave preservando: código generado (nombres de archivos/funciones), decisiones de arquitectura, errores encontrados y cómo se resolvieron, y preferencias del usuario. Sé denso y técnico. Formato: bullet points.

CONVERSACIÓN:
${transcript}` }]
        })
      });
      const d = await res.json();
      const summary = d.content?.[0]?.text || "";
      const summaryMsg = { id:uuid(), role:"assistant", content:`📊 **Contexto comprimido** (${toCompress.length} mensajes → resumen):\n\n${summary}`, time:ts(), mode:"system", agent:"system", _isCompressed:true };
      setMessages(prev => [summaryMsg, ...prev.slice(-4)]);
      addTrace("compressor","claude",transcript.slice(0,100),summary,0,Math.ceil(transcript.length/4));
    } catch(e) { netLog("TokenMgr","compress",`ERR: ${e.message}`,0); }
    finally { setCompressing(false); }
  };

  // ════════════════════════════════════════════════════════════════════════════
  // 🔬 AI SELF-REVIEW
  // ════════════════════════════════════════════════════════════════════════════
  const runSelfReview = async (codeContent) => {
    if (!codeContent || reviewing) return;
    setReviewing(true);
    setSelfReview(null);
    try {
      const res = await fetch(ANTHROPIC_BASE, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model: MODEL_CLAUDE, max_tokens: 1000,
          messages:[{ role:"user", content:
`Eres un revisor de código senior. Analiza este código y devuelve ÚNICAMENTE un JSON válido con esta estructura exacta:
{
  "scores": {
    "completeness": <0-100>,
    "security": <0-100>,
    "performance": <0-100>,
    "errorHandling": <0-100>,
    "codeQuality": <0-100>
  },
  "overall": <0-100>,
  "critical": [<string>, ...],
  "warnings": [<string>, ...],
  "positives": [<string>, ...],
  "autofix": "<código corregido o empty string si está bien>"
}

CÓDIGO A REVISAR:
${codeContent.slice(0,3000)}` }]
        })
      });
      const d = await res.json();
      const raw = d.content?.[0]?.text?.trim() || "{}";
      const clean = raw.replace(/^```json\n?|```$/g,"").trim();
      const review = JSON.parse(clean);
      setSelfReview(review);
      setShowReview(true);
    } catch(e) {
      setSelfReview({ scores:{completeness:0,security:0,performance:0,errorHandling:0,codeQuality:0}, overall:0, critical:["Error al parsear review: "+e.message], warnings:[], positives:[], autofix:"" });
      setShowReview(true);
    } finally { setReviewing(false); }
  };

  const reviewLastResponse = () => {
    const last = messages.filter(m => m.role==="assistant").slice(-1)[0];
    if (last) runSelfReview(last.content);
  };

  // ════════════════════════════════════════════════════════════════════════════
  // 📚 SNIPPET BANK
  // ════════════════════════════════════════════════════════════════════════════
  const pinSnippet   = (id) => setSnippets(prev => prev.map(s => s.id===id ? {...s,pinned:!s.pinned} : s));
  const deleteSnippet= (id) => setSnippets(prev => prev.filter(s => s.id!==id));
  const copySnippet  = (s)  => { navigator.clipboard.writeText(s.code); setSnippets(prev => prev.map(x => x.id===s.id?{...x,usedCount:x.usedCount+1}:x)); };
  const useSnippet   = (s)  => { setInput(prev => prev + "\n\n```"+s.lang+"\n"+s.code+"\n```"); setShowSnippets(false); setSnippets(prev => prev.map(x => x.id===s.id?{...x,usedCount:x.usedCount+1}:x)); inputRef.current?.focus(); };
  const renameSnippet= (id, label) => setSnippets(prev => prev.map(s => s.id===id?{...s,label}:s));

  const filteredSnippets = useMemo(() => {
    let s = snippets;
    if (snippetPinned) s = s.filter(x => x.pinned);
    if (snippetFilter !== "all") s = s.filter(x => x.lang === snippetFilter);
    if (snippetSearch) s = s.filter(x => x.label.toLowerCase().includes(snippetSearch.toLowerCase()) || x.code.toLowerCase().includes(snippetSearch.toLowerCase()) || x.lang.toLowerCase().includes(snippetSearch.toLowerCase()));
    return s;
  }, [snippets, snippetSearch, snippetFilter, snippetPinned]);

  const snippetLangs = useMemo(() => [...new Set(snippets.map(s=>s.lang))], [snippets]);

  // ════════════════════════════════════════════════════════════════════════════
  // 📈 ANALYTICS — derived from traces
  // ════════════════════════════════════════════════════════════════════════════
  const analytics = useMemo(() => {
    if (!traces.length) return null;
    const byModel = {};
    const byAgent = {};
    const byDay   = {};
    const costByDay = {};
    const qualityOverTime = [];
    traces.forEach(t => {
      // by model
      byModel[t.model] = byModel[t.model] || { calls:0, tokens:0, cost:0, avgMs:0, totalMs:0 };
      byModel[t.model].calls++; byModel[t.model].tokens+=t.tokens; byModel[t.model].cost+=parseFloat(t.cost||0); byModel[t.model].totalMs+=t.ms||0;
      // by agent
      byAgent[t.agent] = byAgent[t.agent] || { calls:0, tokens:0 };
      byAgent[t.agent].calls++; byAgent[t.agent].tokens+=t.tokens;
      // by day (last 7)
      const day = t.time?.split(":")[0] || "?";
      byDay[day] = (byDay[day]||0)+1;
      costByDay[day] = (costByDay[day]||0)+parseFloat(t.cost||0);
    });
    Object.keys(byModel).forEach(k => { byModel[k].avgMs = Math.round(byModel[k].totalMs/byModel[k].calls); });
    const langCounts = {};
    snippets.forEach(s => { langCounts[s.lang]=(langCounts[s.lang]||0)+1; });
    const topLangs = Object.entries(langCounts).sort((a,b)=>b[1]-a[1]).slice(0,8);
    const sessionCost = traces.reduce((s,t)=>s+parseFloat(t.cost||0),0);
    const avgLatency  = traces.reduce((s,t)=>s+(t.ms||0),0)/Math.max(traces.length,1);
    const successRate = Math.round((traces.filter(t=>!t.error).length/traces.length)*100);
    return { byModel, byAgent, byDay, costByDay, topLangs, sessionCost, avgLatency:Math.round(avgLatency), successRate, totalTraces:traces.length };
  }, [traces, snippets]);

  // ════════════════════════════════════════════════════════════════════════════
  // 🌊 STREAMING API CALL
  // ════════════════════════════════════════════════════════════════════════════
  const callAPIStream = async (systemPrompt, msgs, agentName, onToken, onDone, onError) => {
    const start = now();
    abortCtrlRef.current = new AbortController();
    netLog(agentName, `${selectedModel} → stream`, "Connecting...", 0);
    try {
      const res = await fetch(ANTHROPIC_BASE, {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        signal: abortCtrlRef.current.signal,
        body: JSON.stringify({
          model: MODEL_CLAUDE, max_tokens: 4096, stream: true,
          system: systemPrompt,
          messages: msgs.slice(-20).map(m=>({role:m.role,content:m.content}))
        })
      });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let full = ""; let inputTok=0; let outputTok=0;
      while (true) {
        const {done,value} = await reader.read();
        if (done) break;
        const chunk = decoder.decode(value, {stream:true});
        const lines = chunk.split("\n").filter(l=>l.startsWith("data: "));
        for (const line of lines) {
          const data = line.slice(6).trim();
          if (data==="[DONE]") continue;
          try {
            const j = JSON.parse(data);
            if (j.type==="content_block_delta" && j.delta?.text) {
              full += j.delta.text;
              onToken(full);
            }
            if (j.type==="message_delta" && j.usage) outputTok = j.usage.output_tokens||0;
            if (j.type==="message_start" && j.message?.usage) inputTok = j.message.usage.input_tokens||0;
          } catch {}
        }
      }
      const ms = now()-start;
      const tokens = inputTok+outputTok||Math.ceil(full.length/4);
      addTrace(agentName, selectedModel, systemPrompt.slice(0,100), full.slice(0,100), ms, tokens);
      netLog(agentName, `${selectedModel} → stream`, `${ms}ms · ${tokens}tok`, ms);
      onDone(full, ms, tokens);
    } catch(e) {
      if (e.name==="AbortError") { onDone("","",0); return; }
      netLog(agentName, "stream", `ERR: ${e.message}`, 0);
      onError(e.message);
    }
  };

  // ════════════════════════════════════════════════════════════════════════════
  // 🤖 CUSTOM AGENT BUILDER
  // ════════════════════════════════════════════════════════════════════════════
  const saveCustomAgent = () => {
    if (!agentForm.name.trim()||!agentForm.systemPrompt.trim()) return;
    const agent = {
      id:       editingAgent || uuid(),
      name:     agentForm.name,
      icon:     agentForm.icon,
      color:    agentForm.color,
      systemPrompt: agentForm.systemPrompt,
      model:    agentForm.model,
      temperature: parseFloat(agentForm.temperature)||0.7,
      description: agentForm.description,
      createdAt: new Date().toLocaleString("es"),
      usedCount: editingAgent ? (customAgents.find(a=>a.id===editingAgent)?.usedCount||0) : 0,
    };
    setCustomAgents(prev => editingAgent ? prev.map(a=>a.id===editingAgent?agent:a) : [agent,...prev]);
    setShowAgentBuilder(false);
    setEditingAgent(null);
    setAgentForm({name:"",icon:"🤖",color:"#00f5a0",systemPrompt:"",model:"claude",temperature:0.7,description:""});
  };
  const deleteCustomAgent = (id) => { setCustomAgents(prev=>prev.filter(a=>a.id!==id)); if(activeCustomAgent===id)setActiveCustomAgent(null); };
  const activateCustomAgent = (id) => { setActiveCustomAgent(prev=>prev===id?null:id); setCustomAgents(prev=>prev.map(a=>a.id===id?{...a,usedCount:a.usedCount+1}:a)); };

  const AGENT_PRESETS = [
    { name:"React Architect", icon:"⚛", color:"#61dafb", description:"Especialista en React 18, Next.js, performance y arquitectura de componentes", systemPrompt:"Eres un arquitecto senior de React con 10 años de experiencia. Siempre usas TypeScript strict, React 18 features (Suspense, Server Components), Zustand para estado global, React Query para data fetching. Tus componentes son siempre accesibles (ARIA), testables y con error boundaries. Prefieres composición sobre herencia. Generas código con JSDoc." },
    { name:"Security Auditor", icon:"🔐", color:"#ef4444", description:"Analiza código buscando vulnerabilidades OWASP, inyecciones, XSS, CSRF", systemPrompt:"Eres un experto en ciberseguridad especializado en auditoría de código. Siempre buscas: SQL injection, XSS, CSRF, SSRF, insecure deserialization, broken auth, exposed secrets, path traversal, race conditions. Para cada vulnerabilidad muestras: severidad (CRITICAL/HIGH/MEDIUM/LOW), CVE si aplica, línea exacta del problema y el fix seguro. No minimices riesgos." },
    { name:"DB Architect", icon:"🗄️", color:"#f59e0b", description:"Experto en PostgreSQL, indexación, query optimization, schema design", systemPrompt:"Eres un arquitecto de bases de datos con experiencia en PostgreSQL, MySQL y MongoDB. Siempre: optimizas queries con EXPLAIN ANALYZE, creas índices apropiados (B-tree, GiST, GIN), aplicas normalization correcta (3NF/BCNF), usas particionamiento cuando necesario, escribes migraciones reversibles, y consideras ACID y concurrencia. Siempre muestra el plan de query estimado." },
    { name:"DevOps Engineer", icon:"🚀", color:"#7c3aed", description:"Docker, K8s, CI/CD, Terraform, monitoreo y deployment strategies", systemPrompt:"Eres un DevOps/SRE senior. Siempre produces: Dockerfiles multi-stage optimizados, docker-compose para local, pipelines CI/CD completos (GitHub Actions), manifiestos Kubernetes con limits/requests/probes, Terraform para infra, alertas de Prometheus/Grafana, y runbooks para incidentes. Priorizas: reproducibilidad, zero-downtime deployments y observabilidad." },
    { name:"Performance Expert", icon:"⚡", color:"#00f5a0", description:"Core Web Vitals, profiling, bundle analysis, caching strategies", systemPrompt:"Eres un experto en performance web. Tu obsesión es: LCP < 2.5s, FID < 100ms, CLS < 0.1. Siempre: analizas bundle size (webpack-bundle-analyzer), aplicas code splitting y lazy loading, optimizas imágenes (WebP/AVIF, srcset), implementas caching estratégico (SW, Cache-Control), reduces JS parse time, uses React.memo/useMemo/useCallback correctamente, y mides con Lighthouse." },
    { name:"Test Engineer", icon:"🧪", color:"#10b981", description:"TDD, Jest, Playwright, coverage 100%, mutation testing", systemPrompt:"Eres un ingeniero de testing especializado en TDD y calidad de software. Siempre: escribes tests antes del código (red-green-refactor), cubres casos edge y boundary values, usas mocking apropiado (no over-mocking), implementas integration tests con MSW, E2E con Playwright, mutation testing con Stryker. Tus tests tienen nombres descriptivos en formato 'should [behavior] when [condition]'." },
  ];

  // ════════════════════════════════════════════════════════════════════════════
  // 🌿 CONVERSATION BRANCHING
  // ════════════════════════════════════════════════════════════════════════════
  const forkConversation = (msgIndex) => {
    const label = `branch-${branches.length}`;
    const forkedMsgs = messages.slice(0, msgIndex+1);
    const newBranch = { id:uuid(), label, parentBranch:activeBranch, forkPoint:msgIndex, messages:forkedMsgs, createdAt:new Date().toLocaleString("es") };
    setBranches(prev => [...prev, newBranch]);
    // Switch to new branch
    setActiveBranch(newBranch.id);
    setMessages(forkedMsgs);
    setBranchingFrom({msgIndex, msgId: messages[msgIndex]?.id});
    setShowBranches(true);
    netLog("Branching", `fork at msg ${msgIndex}`, `→ ${label}`, 0);
  };

  const switchBranch = (branchId) => {
    // Save current messages to current branch
    setBranches(prev => prev.map(b => b.id===activeBranch ? {...b,messages:[...messages]} : b));
    // Load target branch messages
    const target = branches.find(b=>b.id===branchId);
    if (target) { setMessages(target.messages); setActiveBranch(branchId); }
  };

  const deleteBranch = (branchId) => {
    if (branchId==="main") return;
    if (activeBranch===branchId) switchBranch("main");
    setBranches(prev=>prev.filter(b=>b.id!==branchId));
  };

  // ════════════════════════════════════════════════════════════════════════════
  // 🔀 SMART DIFF ENGINE
  // ════════════════════════════════════════════════════════════════════════════
  // Unified diff algorithm — Myers diff simplified
  const computeDiff = (before, after) => {
    const aLines = before.split("\n");
    const bLines = after.split("\n");
    const result = [];
    let added=0, removed=0, unchanged=0;
    // LCS-based line diff (simple greedy for performance)
    let ai=0, bi=0;
    const maxLines = Math.max(aLines.length, bLines.length);
    while (ai<aLines.length||bi<bLines.length) {
      const aLine = aLines[ai];
      const bLine = bLines[bi];
      if (ai>=aLines.length) { result.push({type:"add",text:bLine,lineB:bi+1}); bi++; added++; }
      else if (bi>=bLines.length) { result.push({type:"remove",text:aLine,lineA:ai+1}); ai++; removed++; }
      else if (aLine===bLine) { result.push({type:"same",text:aLine,lineA:ai+1,lineB:bi+1}); ai++; bi++; unchanged++; }
      else {
        // Look ahead to find match
        const lookAhead = 3;
        let matched = false;
        for (let d=1;d<=lookAhead&&!matched;d++) {
          if (bi+d<bLines.length && aLine===bLines[bi+d]) {
            for (let k=0;k<d;k++) { result.push({type:"add",text:bLines[bi+k],lineB:bi+k+1}); added++; } bi+=d; matched=true;
          } else if (ai+d<aLines.length && aLines[ai+d]===bLine) {
            for (let k=0;k<d;k++) { result.push({type:"remove",text:aLines[ai+k],lineA:ai+k+1}); removed++; } ai+=d; matched=true;
          }
        }
        if (!matched) { result.push({type:"remove",text:aLine,lineA:ai+1}); result.push({type:"add",text:bLine,lineB:bi+1}); ai++; bi++; removed++; added++; }
      }
    }
    return { lines:result, added, removed, unchanged, changed:added+removed, pctChanged:Math.round(((added+removed)/Math.max(aLines.length,bLines.length))*100) };
  };

  const showDiffForLast = () => {
    const aiMsgs = messages.filter(m=>m.role==="assistant"&&m.content.includes("```"));
    if (aiMsgs.length<2) return;
    const ex=(msg)=>{const m=msg.content.match(/```(\w+)\n([\s\S]*?)```/);return m?{lang:m[1],code:m[2].trim()}:null;};
    const a=ex(aiMsgs[aiMsgs.length-2]), b=ex(aiMsgs[aiMsgs.length-1]);
    if (!a||!b) return;
    setDiffData({before:a.code,after:b.code,lang:b.lang,stats:computeDiff(a.code,b.code)});
    setShowDiff(true);
  };

  // ─── API KEY MANAGER ─────────────────────────────────────────────────────────

  // Detect which providers are mentioned in text → returns matched provider ids
  const detectProviders = useCallback((text) => {
    const lower = text.toLowerCase();
    return API_PROVIDERS.filter(p =>
      p.keywords.some(kw => lower.includes(kw))
    ).map(p => p.id);
  }, []);

  // Get decrypted value of a stored key by providerId or customLabel match
  const resolveKey = useCallback((providerId) => {
    const stored = apiKeys.find(k => k.providerId === providerId);
    if (!stored) return null;
    return { label: stored.label, value: deobfuscate(stored.encKey), envVar: stored.envVar, providerId };
  }, [apiKeys]);

  // Auto-scan input and highlight detected providers
  const scanInputForKeys = useCallback((text) => {
    const detected = detectProviders(text);
    setAutoDetected(detected);
    return detected;
  }, [detectProviders]);

  // Build a keys context block for injection into system prompt
  const buildKeyContext = useCallback((providerIds) => {
    if (!providerIds || providerIds.length === 0) return "";
    const resolved = providerIds.map(id => resolveKey(id)).filter(Boolean);
    if (resolved.length === 0) return "";
    setLastInjected(resolved);
    // Mark as last used
    setApiKeys(prev => prev.map(k =>
      resolved.find(r => r.providerId === k.providerId)
        ? { ...k, lastUsed: ts() }
        : k
    ));
    return `\n═══ API KEYS DISPONIBLES (inyectadas automáticamente por contexto):\n${
      resolved.map(r => `${r.envVar}=${r.value}  # ${r.label}`).join("\n")
    }\nÚsalas directamente en el código sin pedirlas al usuario.\n`;
  }, [resolveKey]);

  // Save a new key
  const saveKey = useCallback(() => {
    if (!keyForm.keyValue.trim()) return;
    const provider = API_PROVIDERS.find(p => p.id === keyForm.providerId);
    const entry = {
      id:         uuid(),
      providerId: keyForm.providerId || "custom",
      label:      keyForm.customLabel || provider?.name || "Custom Key",
      envVar:     keyForm.envVar || provider?.envVar || "CUSTOM_KEY",
      encKey:     obfuscate(keyForm.keyValue.trim()),
      addedAt:    new Date().toLocaleString("es"),
      lastUsed:   null,
    };
    setApiKeys(prev => {
      const filtered = prev.filter(k => k.providerId !== entry.providerId || entry.providerId === "custom");
      return [entry, ...filtered];
    });
    setKeyForm({ providerId:"", customLabel:"", keyValue:"", envVar:"" });
  }, [keyForm]);

  // Delete a key
  const deleteKey = useCallback((id) => {
    setApiKeys(prev => prev.filter(k => k.id !== id));
  }, []);

  // Toggle key reveal
  const toggleReveal = useCallback((id) => {
    setRevealedKeys(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }, []);

  // ─── CONTEXT7 — fetch docs ──────────────────────────────────────────────────
  const context7Fetch = async (libName) => {
    if (context7Cache[libName]) return context7Cache[libName];
    try {
      const res = await fetch(`https://api.anthropic.com/v1/messages`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model: MODEL_CLAUDE, max_tokens: 400,
          messages:[{ role:"user", content:`Give me the current API summary for the ${libName} library in 200 words or less. Focus on latest version changes.` }]
        })
      });
      const d = await res.json();
      const doc = d.content?.[0]?.text || "";
      setContext7Cache(p => ({ ...p, [libName]: doc }));
      return doc;
    } catch { return ""; }
  };

  // ─── RAG — vector search ────────────────────────────────────────────────────
  const ragSearch = useCallback((query, k=5) => {
    const scored = vectorStore.map(v => ({ ...v, score: vectorSimilarity(query, v.content) }));
    const top = scored.sort((a,b) => b.score - a.score).filter(v => v.score > 0).slice(0, k);
    setRagResults(top);
    return top;
  }, [vectorStore]);

  const ragInsert = useCallback((content, metadata={}) => {
    const entry = { id:uuid(), content, metadata, time:ts(), embedding:"simulated" };
    setVectorStore(prev => [entry, ...prev.slice(0, 999)]);
    return entry;
  }, []);

  // ─── MEMORY ─────────────────────────────────────────────────────────────────
  const extractMemory = (userMsg, aiResp) => {
    const triggers = ["recuerda","importante","nota:","guardar","siempre","nunca","prefiero","mi nombre","soy ","trabajo","proyecto se llama","usa como base","el stack es"];
    const lower = userMsg.toLowerCase();
    if (triggers.some(t => lower.includes(t))) {
      const mem = { id:uuid(), content:userMsg.slice(0,200), response:aiResp.slice(0,100), time:new Date().toLocaleString("es"), tags:triggers.filter(t=>lower.includes(t)) };
      setMemories(p => [mem, ...p.slice(0,199)]);
      ragInsert(userMsg, { type:"memory", time:ts() });
      return mem;
    }
    // Always insert into vector store for future RAG
    ragInsert(userMsg + " " + aiResp.slice(0,200), { type:"conversation", time:ts() });
    return null;
  };

  // ─── TRACE / OBSERVABILITY ─────────────────────────────────────────────────
  const addTrace = (agent, model, prompt, response, ms, tokens) => {
    const cost_est = tokens * 0.000003;
    const trace = { id:uuid(), agent, model, prompt:prompt.slice(0,120), response:response.slice(0,120), ms, tokens, cost:cost_est.toFixed(5), time:ts(), mode:outputMode };
    setTraces(p => [trace, ...p.slice(0,299)]);
    setTotalTokens(p => p + tokens);
    setTotalCost(p => p + cost_est);
  };

  // ─── SYSTEM PROMPT BUILDER ──────────────────────────────────────────────────
  const buildSystemPrompt = (agentRole, ragContext, context7Docs, detectedProviders=[]) => {
    const mode    = OUTPUT_MODES.find(m => m.id === outputMode);
    const active  = mcpTools.filter(t => t.enabled).map(t => `${t.icon} ${t.name}`).join(", ");
    const memCtx  = memories.slice(0,8).map(m => `• ${m.content}`).join("\n");
    const ragCtx  = ragContext?.map(r => `[${(r.score*100).toFixed(0)}%] ${r.content.slice(0,120)}`).join("\n") || "—";
    const ctx7    = context7Docs || "";
    const dbgCtx  = debugErrors.filter(e=>!e.resolved).map(e=>e.msg).join("; ");

    const keyCtx  = buildKeyContext(detectedProviders);
    const webCtx  = webAccess ? `\n═══ ACCESO WEB ACTIVO: Puedes hacer referencias a datos en tiempo real. El agente tiene acceso a internet.\n` : "";
    const fsCtx   = fsPermission==="granted" ? `\n═══ FILESYSTEM ACTIVO: Ruta de salida="${fsOutputPath||"AgentStudio-Output"}/" en directorio="${fsRootPath}". Los archivos generados se guardan automáticamente en disco.\n` : "";
    const rolePrompts = {
      planner:  `Eres el agente PLANIFICADOR. Usa pensamiento secuencial: descompón la tarea en pasos atómicos numerados. Devuelve siempre un plan estructurado antes de cualquier código.`,
      detector: `Eres el agente DETECTOR de contexto. Tu trabajo es identificar librerías/frameworks en la solicitud, verificar su documentación actualizada, y preparar el contexto para el Executor. ${ctx7 ? "Documentación Context7:\n"+ctx7 : ""}`,
      executor: `Eres el agente EXECUTOR principal. Genera código de producción completo y funcional.`,
      debugger: `Eres el agente DEBUGGER recursivo permanente. Iteración #${debugIteration}. Errores activos: ${dbgCtx||"ninguno"}.
REGLAS: 1) Lista TODOS los errores encontrados. 2) Propón fix específico para cada uno. 3) Verifica compatibilidad de versiones. 4) Confirma que paquetes estén sincronizados. 5) No pares hasta que no haya errores.`,
    };

    return `${rolePrompts[agentRole] || rolePrompts.executor}

═══ MODO DE SALIDA: ${mode?.label} — ${mode?.desc}
${outputMode==="webapp"  ? "→ Genera HTML+CSS+JS completo autocontenido. Diseño visual excepcional." : ""}
${outputMode==="project" ? "→ Separa archivos con: // === ARCHIVO: ruta/nombre.ext ===" : ""}
${outputMode==="debug"   ? "→ MODO DEBUG RECURSIVO ACTIVO. Analiza, fija, verifica." : ""}

═══ HERRAMIENTAS MCP ACTIVAS: ${active}
${webCtx}${fsCtx}${keyCtx}
═══ CONTEXTO RAG (memorias relevantes recuperadas):
${ragCtx}

═══ MEMORIA PERSISTIDA:
${memCtx || "Sin memorias aún."}

═══ REGLAS GLOBALES:
• Código siempre completo y ejecutable, nunca fragmentado
• Manejo de errores explícito en todo el código
• Versiones de dependencias siempre pinned y compatibles
• Responde en el idioma del usuario
• Si produces múltiples archivos, usa separadores === ARCHIVO ===
• NUNCA pidas API keys al usuario — están inyectadas arriba si están disponibles`;
  };

  // ─── CALL API (streaming-aware + custom agent) ──────────────────────────────
  const callAPI = async (systemPrompt, msgs, agentName, useStream=false) => {
    const start = now();
    // Inject active custom agent system prompt overlay
    const customAg = activeCustomAgent ? customAgents.find(a=>a.id===activeCustomAgent) : null;
    const finalSys = customAg && agentName==="executor"
      ? `${customAg.systemPrompt}\n\n═══ PLATAFORMA:\n${systemPrompt}`
      : systemPrompt;

    // Streaming path — only for executor on final response
    if (streamEnabled && useStream) {
      return new Promise((resolve, reject) => {
        callAPIStream(finalSys, msgs, agentName,
          (partial) => setStreamContent(partial),
          (full) => { setStreamContent(""); resolve(full); },
          (err)  => { setStreamContent(""); reject(new Error(err)); }
        );
      });
    }

    // Non-streaming (for sub-agents: planner, detector, debugger)
    netLog(agentName, `${selectedModel}`, "Calling...", 0);
    let response="", tokens=0;
    if (selectedModel==="claude"||!selectedModel.includes(":")) {
      const res = await fetch(ANTHROPIC_BASE, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:MODEL_CLAUDE, max_tokens:4096, system:finalSys, messages:msgs.slice(-20).map(m=>({role:m.role,content:m.content})) })
      });
      const d = await res.json();
      if (d.error) throw new Error(d.error.message);
      response = d.content?.[0]?.text||"";
      tokens   = (d.usage?.input_tokens||0)+(d.usage?.output_tokens||0)||Math.ceil(response.length/4);
    } else {
      const res = await fetch(`${OLLAMA_BASE}/api/chat`, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ model:selectedModel, messages:[{role:"system",content:finalSys},...msgs.slice(-10).map(m=>({role:m.role,content:m.content}))], stream:false })
      });
      const d = await res.json();
      if (!res.ok) throw new Error(d.error||"Ollama error");
      response = d.message?.content||""; tokens=Math.ceil(response.length/4);
    }
    const ms=now()-start;
    addTrace(agentName,selectedModel,finalSys.slice(0,100),response.slice(0,100),ms,tokens);
    netLog(agentName,selectedModel,`${fmtMs(ms)} · ${tokens}tok`,ms);
    return response;
  };

  // ─── DETECT LIBRARIES (Context7) ────────────────────────────────────────────
  const detectLibraries = (text) => {
    const libs = ["react","vue","nextjs","tailwind","express","fastapi","django","pytorch","tensorflow","langchain","langraph","ollama","qdrant","chromadb","supabase","prisma","drizzle","astro","svelte","remix","hono"];
    return libs.filter(l => text.toLowerCase().includes(l));
  };

  // ─── SEND MESSAGE (Full Pipeline) ──────────────────────────────────────────
  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userText = input.trim();
    const userMsg  = { id:uuid(), role:"user", content:userText, time:ts(), mode:outputMode };
    const history  = [...messages, userMsg];
    setMessages(history);
    setInput("");
    setLoading(true);

    try {
      // 1. RAG search — retrieve relevant context
      const ragCtx = ragSearch(userText);
      setShowRag(ragCtx.length > 0);

      // 1b. API KEY auto-detection
      const detectedProvs = scanInputForKeys(userText);

      let finalResponse = "";
      let planText = "";

      // 2. PLANNER agent (if pipeline enabled)
      if (agentPipeline && activeAgents.includes("planner")) {
        setCurrentAgent("planner");
        const planSys = buildSystemPrompt("planner", ragCtx, "", detectedProvs);
        planText = await callAPI(planSys, [{ role:"user", content:`Planifica: ${userText}` }], "Planner");
        const planMsg = { id:uuid(), role:"assistant", content:planText, time:ts(), mode:outputMode, agent:"planner" };
        setMessages(p => [...p, planMsg]);
      }

      // 3. DETECTOR agent — Context7 (if pipeline enabled)
      let ctx7Docs = "";
      if (agentPipeline && activeAgents.includes("detector")) {
        setCurrentAgent("detector");
        const libs = detectLibraries(userText);
        if (libs.length > 0 && mcpTools.find(t=>t.id==="context7")?.enabled) {
          const docPromises = libs.slice(0,3).map(l => context7Fetch(l));
          const docs = await Promise.all(docPromises);
          ctx7Docs = libs.map((l,i) => `### ${l}\n${docs[i]}`).join("\n\n");
          netLog("Context7", `Fetched docs: ${libs.join(",")}`, "OK", 0);
        }
      }

      // 4. EXECUTOR agent — main response (streaming-aware)
      setCurrentAgent("executor");
      const execSys = buildSystemPrompt("executor", ragCtx, ctx7Docs, detectedProvs);
      const planContext = planText ? [{ role:"user", content:userText }, { role:"assistant", content:`[Plan]\n${planText}` }] : [];

      // Insert streaming placeholder bubble
      const streamPlaceholderId = uuid();
      if (streamEnabled) {
        setStreamMsgId(streamPlaceholderId);
        setMessages(prev => [...prev, { id:streamPlaceholderId, role:"assistant", content:"", time:ts(), mode:outputMode, agent:"executor", _streaming:true }]);
      }
      finalResponse = await callAPI(execSys, [...history, ...planContext], "Executor", streamEnabled);

      // Replace streaming placeholder with final message
      if (streamEnabled) {
        setStreamMsgId(null);
        setMessages(prev => prev.filter(m => m.id !== streamPlaceholderId));
      }

      // 5. DEBUGGER (if mode=debug or permanent)
      if (outputMode === "debug" || debugPermanent) {
        setCurrentAgent("debugger");
        await processDebug(finalResponse);
        if (debugPermanent && debugErrors.filter(e=>!e.resolved).length > 0) {
          const dbgSys = buildSystemPrompt("debugger", ragCtx, "", detectedProvs);
          const dbgResp = await callAPI(dbgSys, [{ role:"user", content:`Errores detectados:\n${debugErrors.filter(e=>!e.resolved).map(e=>e.msg).join("\n")}\n\nCódigo:\n${finalResponse.slice(0,2000)}` }], "Debugger");
          finalResponse = dbgResp;
        }
      }

      setCurrentAgent(null);

      // Build final AI message
      const aiMsg = { id:uuid(), role:"assistant", content:finalResponse, time:ts(), mode:outputMode, agent:"executor",
        ragUsed: ragCtx.length > 0, ctx7Used: ctx7Docs.length > 0, planUsed: planText.length > 0,
        keysInjected: detectedProvs.filter(id => apiKeys.find(k=>k.providerId===id)) };
      setMessages(p => [...p, aiMsg]);

      // Extract memory & add to vector store
      extractMemory(userText, finalResponse);

      // Run model comparison in parallel if enabled
      if (compareMode && compareModelB !== selectedModel) {
        runComparison(userText, [...history]);
      }

      // Auto self-review if enabled
      if (autoReview && finalResponse.includes("```")) {
        setTimeout(() => runSelfReview(finalResponse), 800);
      }

      // Auto-save to filesystem if access granted
      if (fsPermission === "granted") {
        const written = await writeProjectToFs(finalResponse);
        if (written > 0) {
          const fsNote = { id:uuid(), role:"assistant", content:`📁 **${written} archivo${written>1?"s":""} guardado${written>1?"s":""}** automáticamente en \`${fsRootPath}/${fsOutputPath||"AgentStudio-Output"}/\``, time:ts(), mode:"system", agent:"executor" };
          setMessages(p => [...p, fsNote]);
        }
      }

      // Parse output artifacts
      parseOutput(finalResponse, outputMode);

    } catch (err) {
      setCurrentAgent(null);
      const errMsg = { id:uuid(), role:"assistant", content:`⚠️ **Error en pipeline:** ${err.message}`, time:ts(), mode:"error", isError:true };
      setMessages(p => [...p, errMsg]);
      if (debugPermanent) {
        setDebugErrors(p => [...p, { id:uuid(), msg:err.message, time:ts(), iteration:debugIteration, resolved:false }]);
        setDebugIteration(i => i+1);
      }
      netLog("Error", err.message, "FAILED", 0);
    } finally {
      setLoading(false);
      if (debugPermanent && outputMode==="debug") setTimeout(autoDebug, 1500);
    }
  };

  // ─── DEBUG PROCESSOR ────────────────────────────────────────────────────────
  const processDebug = async (text) => {
    const patterns = [
      { re:/TypeError:\s*.+/g,     label:"TypeError" },
      { re:/SyntaxError:\s*.+/g,   label:"SyntaxError" },
      { re:/ReferenceError:\s*.+/g,label:"ReferenceError" },
      { re:/Error:\s*Cannot find module\s*.+/g,label:"Module not found" },
      { re:/ENOENT:\s*.+/g,        label:"File not found" },
      { re:/npm ERR!\s*.+/g,       label:"NPM Error" },
      { re:/version mismatch/gi,   label:"Version mismatch" },
      { re:/peer dep\w*/gi,        label:"Peer dependency" },
      { re:/deprecated/gi,         label:"Deprecated API" },
      { re:/undefined is not/g,    label:"Null/Undefined" },
      { re:/CORS/gi,               label:"CORS Error" },
      { re:/401|403|500|502/g,     label:"HTTP Error" },
    ];
    const found = [];
    patterns.forEach(({ re, label }) => {
      const m = text.match(re);
      if (m) m.forEach(msg => found.push({ id:uuid(), label, msg:msg.trim().slice(0,120), time:ts(), iteration:debugIteration, resolved:false }));
    });
    if (found.length) {
      setDebugErrors(p => [...p.filter(e=>e.resolved), ...found]);
      setDebugIteration(i => i+1);
    } else {
      setDebugErrors(p => p.map(e => ({ ...e, resolved:true })));
    }
  };

  // ─── AUTO DEBUG ─────────────────────────────────────────────────────────────
  const autoDebug = () => {
    const unresolved = debugErrors.filter(e => !e.resolved);
    if (unresolved.length === 0 || autoDebugRunning) return;
    const summary = unresolved.map(e => `[${e.label}] ${e.msg}`).join("\n");
    setInput(`[AUTO-DEBUG · iteración ${debugIteration + 1}]\nAnaliza y corrige TODOS estos errores:\n${summary}`);
    setOutputMode("debug");
  };

  // ─── OUTPUT PARSER ───────────────────────────────────────────────────────────
  const parseOutput = (content, mode) => {
    if (mode === "webapp") {
      const m = content.match(/```html([\s\S]*?)```/i) || content.match(/<html[\s\S]*?<\/html>/i);
      if (m) {
        const html = m[1]?.trim() || m[0];
        setGeneratedOutput({ type:"webapp", content:html });
        setSandboxHtml(html);
      }
    }
    if (mode === "project") {
      const files = [];
      const re = /\/\/\s*===\s*ARCHIVO:\s*(.+?)\s*===([\s\S]*?)(?=\/\/\s*===\s*ARCHIVO:|$)/gi;
      let match;
      while ((match = re.exec(content)) !== null) files.push({ name:match[1].trim(), content:match[2].trim() });
      if (files.length) setGeneratedOutput({ type:"project", files });
    }
    // Detect charts
    const chartMatch = content.match(/```(json|echarts)([\s\S]*?)```/i);
    if (chartMatch) setGeneratedOutput(p => ({ ...p, chart:chartMatch[2]?.trim() }));
  };

  // ─── GITHUB ─────────────────────────────────────────────────────────────────
  const fetchGitHub = async () => {
    if (!githubRepo.trim()) return;
    setGithubLoading(true);
    const clean = githubRepo.replace("https://github.com/","").replace(/\/$/, "");
    try {
      const [repoRes, readmeRes] = await Promise.all([
        fetch(`https://api.github.com/repos/${clean}`),
        fetch(`https://api.github.com/repos/${clean}/readme`)
      ]);
      const repo   = await repoRes.json();
      const readme = readmeRes.ok ? await readmeRes.json() : null;
      const readmeText = readme?.content ? atob(readme.content) : "";
      setGithubData({ ...repo, readmeText: readmeText.slice(0,2000) });
      netLog("GitHub", `GET ${clean}`, "200 OK", 0);
      // Inject into context
      ragInsert(`GitHub repo: ${repo.full_name}. ${repo.description || ""}. Stars:${repo.stargazers_count}. Lang:${repo.language}. ${readmeText.slice(0,500)}`, { type:"github" });
    } catch (e) {
      netLog("GitHub", `GET ${clean}`, `Error: ${e.message}`, 0);
    } finally { setGithubLoading(false); }
  };

  // ─── KEYBOARD ────────────────────────────────────────────────────────────────
  const handleKey = e => { if (e.key==="Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } };
  const handleInputChange = e => { setInput(e.target.value); scanInputForKeys(e.target.value); };

  // ─── COMPUTED ────────────────────────────────────────────────────────────────
  const unresolvedErrors = useMemo(() => debugErrors.filter(e=>!e.resolved), [debugErrors]);
  const activeMcp        = useMemo(() => mcpTools.filter(t=>t.enabled), [mcpTools]);
  const mcpCategories    = useMemo(() => [...new Set(MCP_REGISTRY.map(t=>t.category))], []);
  const filteredMcp      = useMemo(() => mcpFilter==="all" ? mcpTools : mcpTools.filter(t=>t.category===mcpFilter), [mcpTools, mcpFilter]);

  const clearAll = () => { setMessages([]); setGeneratedOutput(null); setSandboxHtml(""); persist("v2:messages",[]); };

  // ════════════════════════════════════════════════════════════════════════════
  //  RENDER
  // ════════════════════════════════════════════════════════════════════════════
  return (
    <div style={S.root}>
      <div style={S.scan} />

      {/* ── HEADER ─────────────────────────────────────────────────────────── */}
      <header style={S.header}>
        <div style={S.hLeft}>
          <button onClick={()=>setSidebarCollapsed(p=>!p)} style={S.iconBtn}>☰</button>
          <div style={S.logo}><span style={S.logoMark}>⬡</span><span style={S.logoTxt}>AGENT<span style={S.logoAcc}>STUDIO</span></span><span style={S.logoVer}>v2.0</span></div>
          <div style={S.hStatus}>
            <Dot color={ollamaStatus==="online"?"#00f5a0":"#444"}   label="Ollama" />
            <Dot color={networkInfo?.anthropic!==false?"#00f5a0":"#ef4444"} label="Anthropic" />
            <Dot color={networkInfo?.internet!==false?"#00f5a0":"#444"}    label="Internet" />
            {agentPipeline && <span style={S.pipelineBadge}>⚡ Pipeline: {activeAgents.join("→")}</span>}
            {currentAgent  && <span style={{...S.pipelineBadge,background:"#00f5a020",borderColor:"#00f5a0",color:"#00f5a0",animation:"blink 1s infinite"}}>{AGENTS.find(a=>a.id===currentAgent)?.icon} {currentAgent}</span>}
            {debugPermanent && <span style={S.dbgBadge}>🔬 DEBUG·LOCK {unresolvedErrors.length>0?`[${unresolvedErrors.length}err]`:"[✓]"}</span>}
          </div>
        </div>
        <div style={S.hRight}>
          <span style={S.tokenBadge}>⚡ {totalTokens.toLocaleString()} tok · ${totalCost.toFixed(4)}</span>
          <button onClick={()=>setShowKeyMgr(p=>!p)} style={{...S.iconBtn,color:showKeyMgr?"#f59e0b":apiKeys.length>0?"#00f5a0":"#555",position:"relative"}} title="API Key Manager">
            🔑<span style={{fontSize:8,position:"absolute",top:2,right:2,color:"#00f5a0"}}>{apiKeys.length||""}</span>
          </button>

          {/* ── WEB ACCESS TOGGLE ── */}
          <button onClick={toggleWebAccess}
            title={webAccess?"Desactivar acceso web":"Activar acceso web para agentes"}
            style={{...S.iconBtn, display:"flex",alignItems:"center",gap:4,padding:"4px 8px",
              background: webAccess?"#06b6d418":"transparent",
              border: webAccess?"1px solid #06b6d440":"1px solid transparent",
              borderRadius:6, color: webAccess?"#06b6d4":"#555"}}>
            <span style={{fontSize:13}}>🌐</span>
            <span style={{fontSize:9,fontWeight:700}}>{webAccess?"WEB ON":"WEB"}</span>
            <div style={{width:6,height:6,borderRadius:"50%",background:webAccess?"#06b6d4":"#333",boxShadow:webAccess?"0 0 6px #06b6d4":"none"}}/>
          </button>

          {/* ── FILESYSTEM ACCESS ── */}
          <button
            onClick={fsPermission==="granted"?()=>setRightPanel(p=>p==="files"?null:"files"):requestFsAccess}
            title={fsPermission==="granted"?`Explorador: ${fsRootPath}`:"Solicitar acceso al sistema de archivos"}
            style={{...S.iconBtn, display:"flex",alignItems:"center",gap:4,padding:"4px 8px",
              background: fsPermission==="granted"?"#f59e0b18":fsPermission==="requesting"?"#7c3aed18":"transparent",
              border: `1px solid ${fsPermission==="granted"?"#f59e0b40":fsPermission==="requesting"?"#7c3aed40":"transparent"}`,
              borderRadius:6, color: fsPermission==="granted"?"#f59e0b":fsPermission==="requesting"?"#7c3aed":"#555"}}>
            <span style={{fontSize:13}}>{fsPermission==="granted"?"📂":fsPermission==="requesting"?"⏳":"📁"}</span>
            <span style={{fontSize:9,fontWeight:700}}>
              {fsPermission==="granted"?fsRootPath.slice(0,8)||"FILES":fsPermission==="requesting"?"...":"FILES"}
            </span>
            <div style={{width:6,height:6,borderRadius:"50%",
              background:fsPermission==="granted"?"#f59e0b":fsPermission==="requesting"?"#7c3aed":"#333",
              boxShadow:fsPermission==="granted"?"0 0 6px #f59e0b":"none"}}/>
          </button>

          <button onClick={()=>setRightPanel(p=>p==="web"?null:"web")} style={{...S.iconBtn,color:rightPanel==="web"?"#06b6d4":"#888"}} title="Web Monitor">📡</button>
          <button onClick={()=>setRightPanel(p=>p==="term"?null:"term")} style={{...S.iconBtn,color:rightPanel==="term"?"#00f5a0":"#888"}} title="Terminal">⌨️</button>
          <button onClick={()=>setShowTemplates(true)} style={{...S.iconBtn,color:"#a78bfa"}} title="Plantillas de proyecto">📋</button>
          <button onClick={()=>setShowPromptLib(p=>!p)} style={{...S.iconBtn,color:showPromptLib?"#f59e0b":"#888",position:"relative"}} title="Biblioteca de prompts">
            ⚡<span style={{fontSize:7,position:"absolute",top:2,right:1,color:"#f59e0b"}}>{savedPrompts.length||""}</span>
          </button>
          <button onClick={downloadZip} style={{...S.iconBtn,color:"#06b6d4"}} title="Exportar proyecto como ZIP/Bundle">📦</button>
          <button onClick={()=>setShowRunner(p=>!p)} style={{...S.iconBtn,color:showRunner?"#00f5a0":"#888"}} title="Code Runner — ejecutar código">▶️</button>
          <button onClick={()=>setShowSnippets(p=>!p)} style={{...S.iconBtn,color:showSnippets?"#a78bfa":"#888",position:"relative"}} title="Snippet Bank">
            🗂<span style={{fontSize:7,position:"absolute",top:2,right:1,color:"#a78bfa"}}>{snippets.length||""}</span>
          </button>
          <button onClick={reviewLastResponse} disabled={reviewing} title="Auto Self-Review — la IA critica su propio output"
            style={{...S.iconBtn,color:reviewing?"#f59e0b":autoReview?"#06b6d4":"#888",animation:reviewing?"blink 1s infinite":"none"}}>
            {reviewing?"⌛":"🔬"}
          </button>

          {/* ── NEW FEATURE BUTTONS ── */}
          <button onClick={()=>setShowAgentBuilder(true)} title="🤖 Crear/gestionar agentes personalizados"
            style={{...S.iconBtn,color:activeCustomAgent?"#00f5a0":"#888",position:"relative"}}>
            🤖{activeCustomAgent&&<span style={{position:"absolute",top:1,right:1,width:6,height:6,borderRadius:"50%",background:"#00f5a0",boxShadow:"0 0 4px #00f5a0"}}/>}
          </button>
          <button onClick={()=>setShowAnalytics(true)} title="📈 Analytics dashboard" style={{...S.iconBtn,color:"#888"}}>📈</button>
          <button onClick={()=>setShowBranches(p=>!p)} title="🌿 Branches de conversación"
            style={{...S.iconBtn,color:showBranches?"#00f5a0":"#888",position:"relative"}}>
            🌿{branches.length>1&&<span style={{fontSize:7,position:"absolute",top:2,right:1,color:"#00f5a0"}}>{branches.length}</span>}
          </button>
          <button onClick={showDiffForLast} title="🔀 Diff entre últimas versiones de código" style={{...S.iconBtn,color:diffData?"#7c3aed":"#888"}}>🔀</button>
          <button onClick={()=>setStreamEnabled(p=>!p)} title={streamEnabled?"Streaming ON — click para desactivar":"Streaming OFF — click para activar"}
            style={{...S.iconBtn,color:streamEnabled?"#00f5a0":"#555",fontSize:11,fontFamily:"monospace",padding:"0 4px"}}>
            {streamEnabled?"▶~":"▶"}
          </button>

          <button onClick={()=>setRightPanel(p=>p==="observe"?null:"observe")} style={{...S.iconBtn,color:rightPanel==="observe"?"#06b6d4":"#888"}} title="Observability">🔭</button>
          <button onClick={()=>setRightPanel(p=>p==="sandbox"?null:"sandbox")} style={{...S.iconBtn,color:rightPanel==="sandbox"?"#00f5a0":"#888"}} title="Sandbox">⚗️</button>
          <button onClick={()=>setRightPanel(p=>p==="github"?null:"github")} style={{...S.iconBtn,color:rightPanel==="github"?"#7c3aed":"#888"}} title="GitHub">🐙</button>
          <button onClick={clearAll} style={S.iconBtn} title="Clear">⌫</button>
        </div>
      </header>

      {/* ── BODY ───────────────────────────────────────────────────────────── */}
      <div style={S.body}>

        {/* ─ SIDEBAR ─────────────────────────────────────────────────────── */}
        {!sidebarCollapsed && (
          <aside style={S.sidebar}>
            <div style={S.sTabs}>
              {[["models","🤖"],["mcp","🔧"],["agents","⚡"],["memory","🧠"],["net","📡"],["debug","🔬"],["keys","🔑"]].map(([id,icon]) => (
                <button key={id} onClick={()=>setSidebarTab(id)} style={{...S.sTab,...(sidebarTab===id?S.sTabOn:{})}}>
                  {icon}<span style={{fontSize:8,display:"block"}}>{id}</span>
                </button>
              ))}
            </div>
            <div style={S.sContent}>

              {/* MODELS */}
              {sidebarTab==="models" && <>
                <Sec>CLAUDE — ANTHROPIC</Sec>
                <MdCard m={{id:"claude",name:"Claude Sonnet 4",note:"Recomendado",tags:["agent","code","reason"]}} sel={selectedModel==="claude"} onSel={()=>setSelectedModel("claude")} color="#7c3aed"/>

                <Sec style={{marginTop:12}}>
                  OLLAMA — LOCAL
                  <button onClick={fetchOllamaModels} style={S.refreshBtn}>↻ scan</button>
                </Sec>
                <div style={{fontSize:11,marginBottom:8,display:"flex",alignItems:"center",gap:6}}>
                  <span style={{color:ollamaStatus==="online"?"#00f5a0":"#ef4444"}}>● {ollamaStatus}</span>
                  <span style={{color:"#444"}}>localhost:11434</span>
                </div>
                {ollamaModels.map(m => {
                  const meta = m._meta || OSS_MODELS.find(x=>x.id===m.name);
                  const size = m.size ? (m.size/1e9).toFixed(1)+"GB" : m._cached?"cache":"?";
                  return <MdCard key={m.name} m={{id:m.name,name:m.name.split(":")[0],note:size,tags:meta?.tags||[]}} sel={selectedModel===m.name} onSel={()=>setSelectedModel(m.name)} color="#00f5a0" disabled={m._cached&&ollamaStatus==="offline"}/>;
                })}
              </>}

              {/* MCP */}
              {sidebarTab==="mcp" && <>
                <Sec>MCP TOOLS REGISTRY ({activeMcp.length}/{mcpTools.length} activos)</Sec>
                <div style={{display:"flex",flexWrap:"wrap",gap:4,marginBottom:10}}>
                  {["all",...mcpCategories].map(c=>(
                    <button key={c} onClick={()=>setMcpFilter(c)} style={{...S.filterChip,...(mcpFilter===c?{background:"#00f5a020",borderColor:"#00f5a040",color:"#00f5a0"}:{})}}>
                      {c}
                    </button>
                  ))}
                </div>
                {[1,2,3,4,5].map(tier=>{
                  const tools = filteredMcp.filter(t=>t.tier===tier);
                  if (!tools.length) return null;
                  const labels=["Essential","Productivity","Storage","Execution","Integrations"];
                  return <div key={tier}>
                    <div style={{fontSize:9,color:"#333",letterSpacing:1,marginBottom:4,marginTop:8}}>TIER {tier} — {labels[tier-1]}</div>
                    {tools.map(tool => (
                      <div key={tool.id} style={{...S.mcpRow,...(tool.enabled?{borderColor:tool.color+"30",background:tool.color+"08"}:{})}}
                        onClick={()=>setMcpTools(p=>p.map(t=>t.id===tool.id?{...t,enabled:!t.enabled}:t))}>
                        <span style={{fontSize:16}}>{tool.icon}</span>
                        <div style={{flex:1,minWidth:0}}>
                          <div style={{fontSize:11,color:tool.enabled?tool.color:"#666",fontWeight:600}}>{tool.name}</div>
                          <div style={{fontSize:9,color:"#444",marginTop:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{tool.desc}</div>
                          <div style={{fontSize:8,color:"#333",marginTop:1,fontFamily:"monospace"}}>{tool.cmd}</div>
                        </div>
                        <div style={{width:8,height:8,borderRadius:"50%",background:tool.enabled?tool.color:"#222",flexShrink:0}}/>
                      </div>
                    ))}
                  </div>;
                })}
              </>}

              {/* AGENTS */}
              {sidebarTab==="agents" && <>
                <Sec>MULTI-AGENT PIPELINE</Sec>
                <label style={S.toggle}>
                  <input type="checkbox" checked={agentPipeline} onChange={e=>setAgentPipeline(e.target.checked)} style={{display:"none"}}/>
                  <div style={{...S.toggleTrack,background:agentPipeline?"#00f5a0":"#222"}}/>
                  Pipeline activado
                </label>
                <div style={{fontSize:10,color:"#444",marginBottom:12,lineHeight:1.5}}>Cuando está activo, cada mensaje pasa por los agentes seleccionados en secuencia.</div>
                {AGENTS.map(ag=>(
                  <div key={ag.id} style={{...S.agentCard,...(activeAgents.includes(ag.id)?{borderColor:ag.color+"40",background:ag.color+"08"}:{}),
                    ...(currentAgent===ag.id?{boxShadow:`0 0 12px ${ag.color}40`,animation:"blink 0.8s infinite"}:{})}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <div style={{display:"flex",alignItems:"center",gap:6}}>
                        <span style={{fontSize:18}}>{ag.icon}</span>
                        <div>
                          <div style={{fontSize:12,fontWeight:700,color:activeAgents.includes(ag.id)?ag.color:"#666"}}>{ag.name}</div>
                          <div style={{fontSize:9,color:"#444"}}>{ag.role}</div>
                        </div>
                      </div>
                      <input type="checkbox" checked={activeAgents.includes(ag.id)}
                        onChange={e=>setActiveAgents(p=>e.target.checked?[...p,ag.id]:p.filter(a=>a!==ag.id))}
                        style={{accentColor:ag.color,width:14,height:14}}/>
                    </div>
                    {currentAgent===ag.id && <div style={{fontSize:9,color:ag.color,marginTop:6,animation:"blink 1s infinite"}}>● ejecutando...</div>}
                  </div>
                ))}
                <div style={{marginTop:12,padding:"8px",background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,fontSize:10,color:"#555",lineHeight:1.6}}>
                  <strong style={{color:"#888"}}>Flujo recomendado:</strong><br/>
                  Planner → Detector → Executor → Debugger
                </div>
              </>}

              {/* MEMORY */}
              {sidebarTab==="memory" && <>
                <Sec>VECTOR STORE — QDRANT-LIKE ({vectorStore.length} vectores)</Sec>
                <div style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"8px 10px",marginBottom:10,fontSize:11}}>
                  <div style={{color:"#888"}}>Vectores almacenados: <span style={{color:"#00f5a0"}}>{vectorStore.length}</span></div>
                  <div style={{color:"#888"}}>Memorias explícitas: <span style={{color:"#f59e0b"}}>{memories.length}</span></div>
                  <div style={{color:"#888"}}>Última búsqueda RAG: <span style={{color:"#7c3aed"}}>{ragResults.length} resultados</span></div>
                </div>
                {ragResults.length > 0 && <>
                  <Sec>ÚLTIMA BÚSQUEDA RAG</Sec>
                  {ragResults.map(r=>(
                    <div key={r.id} style={{borderLeft:`2px solid ${r.score>0.5?"#00f5a0":"#7c3aed"}`,padding:"4px 8px",marginBottom:4,fontSize:10}}>
                      <span style={{color:"#444"}}>[{(r.score*100).toFixed(0)}%]</span>
                      <div style={{color:"#888",marginTop:2}}>{r.content.slice(0,100)}...</div>
                    </div>
                  ))}
                </>}
                <Sec style={{marginTop:8}}>MEMORIAS EXPLÍCITAS</Sec>
                {memories.length===0 ? <div style={{color:"#444",fontSize:11}}>Di "recuerda que..." para guardar</div> :
                  memories.slice(0,15).map(m=>(
                    <div key={m.id} style={{borderLeft:"2px solid #f59e0b40",padding:"4px 8px",marginBottom:4}}>
                      <div style={{fontSize:11,color:"#888"}}>{m.content.slice(0,100)}</div>
                      <div style={{fontSize:9,color:"#444"}}>{m.time}</div>
                    </div>
                  ))
                }
                <button onClick={()=>{setMemories([]);setVectorStore([]);}} style={{...S.btn,marginTop:8,borderColor:"#ef444430",color:"#ef4444",background:"#ef444410"}}>
                  🗑 Limpiar memoria
                </button>
              </>}

              {/* NETWORK */}
              {sidebarTab==="net" && <>
                <Sec>ESTADO DE RED</Sec>
                <div style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"8px 12px",marginBottom:10}}>
                  {[["Anthropic API",networkInfo?.anthropic!==false],["Ollama Local",ollamaStatus==="online"],["Internet",networkInfo?.internet!==false]].map(([l,ok])=>(
                    <div key={l} style={{display:"flex",justifyContent:"space-between",padding:"3px 0",fontSize:12}}>
                      <span style={{color:"#666"}}>{l}</span>
                      <span style={{color:ok?"#00f5a0":"#ef4444"}}>{ok?"● Online":"● Offline"}</span>
                    </div>
                  ))}
                  <div style={{display:"flex",justifyContent:"space-between",padding:"3px 0",fontSize:12}}>
                    <span style={{color:"#666"}}>Latencia</span><span style={{color:"#888"}}>{networkInfo?.latency||"—"}</span>
                  </div>
                </div>
                <button onClick={checkNetwork} style={S.btn}>↻ Actualizar red</button>
                <Sec style={{marginTop:12}}>LOG DE RED</Sec>
                <div style={{fontFamily:"monospace",fontSize:9,lineHeight:1.8,maxHeight:240,overflow:"auto"}}>
                  {networkLog.slice(0,30).map(l=>(
                    <div key={l.id} style={{borderBottom:"1px solid #0d0f14",paddingBottom:1}}>
                      <span style={{color:"#444"}}>{l.time} </span>
                      <span style={{color:"#7c3aed"}}>[{l.src}] </span>
                      <span style={{color:"#666"}}>{l.action} </span>
                      <span style={{color:l.status.includes("OK")||l.status.includes("Online")?"#00f5a0":"#ef4444"}}>{l.status}</span>
                      {l.ms>0 && <span style={{color:"#333"}}> {fmtMs(l.ms)}</span>}
                    </div>
                  ))}
                </div>
              </>}

              {/* DEBUG */}
              {sidebarTab==="debug" && <>
                <Sec>DEPURACIÓN RECURSIVA</Sec>
                <label style={S.toggle}>
                  <input type="checkbox" checked={debugMode} onChange={e=>{setDebugMode(e.target.checked);if(e.target.checked)setSidebarTab("debug");}} style={{display:"none"}}/>
                  <div style={{...S.toggleTrack,background:debugMode?"#ef4444":"#222"}}/>
                  Modo debug activo
                </label>
                <label style={S.toggle}>
                  <input type="checkbox" checked={debugPermanent} onChange={e=>setDebugPermanent(e.target.checked)} style={{display:"none"}}/>
                  <div style={{...S.toggleTrack,background:debugPermanent?"#f59e0b":"#222"}}/>
                  🔒 Permanencia activada
                </label>
                <div style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"8px 10px",fontSize:12,lineHeight:2,marginTop:8}}>
                  <span style={{color:"#666"}}>Iteración:</span> <span style={{color:"#f59e0b"}}>{debugIteration}</span><br/>
                  <span style={{color:"#666"}}>Errores activos:</span> <span style={{color:"#ef4444"}}>{unresolvedErrors.length}</span><br/>
                  <span style={{color:"#666"}}>Resueltos:</span> <span style={{color:"#00f5a0"}}>{debugErrors.filter(e=>e.resolved).length}</span>
                </div>
                {unresolvedErrors.length > 0 && (
                  <button onClick={autoDebug} style={{...S.btn,marginTop:8,borderColor:"#ef444430",color:"#ef4444",background:"#ef444408"}}>
                    🔄 Auto-fix iteración {debugIteration+1}
                  </button>
                )}
                {unresolvedErrors.length===0 && debugErrors.length>0 && (
                  <div style={{color:"#00f5a0",fontSize:12,textAlign:"center",padding:8,border:"1px solid #00f5a030",borderRadius:6,marginTop:8}}>✓ Sin errores pendientes</div>
                )}
                <Sec style={{marginTop:12}}>REGISTRO DE ERRORES</Sec>
                {debugErrors.length===0 ? <div style={{color:"#444",fontSize:11}}>Sin errores registrados</div> :
                  debugErrors.slice(0,25).map(e=>(
                    <div key={e.id} style={{borderLeft:`2px solid ${e.resolved?"#00f5a040":"#ef444440"}`,padding:"4px 8px",marginBottom:4,opacity:e.resolved?0.4:1}}>
                      <div style={{display:"flex",gap:6,alignItems:"center"}}>
                        <span style={{color:e.resolved?"#00f5a0":"#ef4444",fontSize:10}}>{e.resolved?"✓":e.label||"●"}</span>
                        <span style={{color:"#444",fontSize:9}}>it.{e.iteration} · {e.time}</span>
                      </div>
                      <div style={{color:"#aaa",fontSize:10,marginTop:2}}>{e.msg}</div>
                    </div>
                  ))
                }
                <button onClick={()=>setDebugErrors([])} style={{...S.btn,marginTop:8,borderColor:"#33333380",color:"#555",background:"#11111180"}}>Limpiar errores</button>
              </>}

              {/* KEYS */}
              {sidebarTab==="keys" && <>
                <Sec>🔑 GESTOR DE API KEYS ({apiKeys.length} guardadas)</Sec>
                <div style={{fontSize:9,color:"#444",lineHeight:1.6,marginBottom:10,padding:"6px 8px",border:"1px solid #1a1d26",borderRadius:6,background:"#0c0e14"}}>
                  🔒 Cifrado XOR · Solo en tu navegador · Nunca se envían al servidor<br/>
                  ⚡ Auto-inyección cuando el contexto las necesita
                </div>

                {/* Add key form */}
                <div style={{border:"1px solid #1a2040",borderRadius:8,padding:10,marginBottom:12,background:"#0a0c14"}}>
                  <div style={{fontSize:9,color:"#00f5a0",letterSpacing:2,marginBottom:8}}>+ NUEVA API KEY</div>

                  {/* Provider selector */}
                  <div style={{marginBottom:6}}>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>PROVEEDOR</div>
                    <div style={{display:"flex",flexWrap:"wrap",gap:3,maxHeight:120,overflowY:"auto"}}>
                      {["custom",...[...new Set(API_PROVIDERS.map(p=>p.cat))]].map(cat=>{
                        const provs = cat==="custom" ? [{id:"custom",name:"Custom",icon:"⚙",color:"#888"}] : API_PROVIDERS.filter(p=>p.cat===cat);
                        return provs.map(p=>(
                          <button key={p.id} onClick={()=>{
                            setKeyForm(f=>({...f,providerId:p.id,envVar:p.envVar||"CUSTOM_KEY",customLabel:p.name||""}));
                          }} style={{
                            background:keyForm.providerId===p.id?p.color+"20":"#0c0e14",
                            border:`1px solid ${keyForm.providerId===p.id?p.color+"60":"#1a1d26"}`,
                            borderRadius:4,padding:"2px 6px",cursor:"pointer",fontSize:10,
                            color:keyForm.providerId===p.id?p.color:"#555",
                            display:"flex",alignItems:"center",gap:3
                          }}>
                            <span>{p.icon}</span>{p.name||p.id}
                          </button>
                        ));
                      })}
                    </div>
                  </div>

                  {keyForm.providerId==="custom" && (
                    <div style={{marginBottom:6}}>
                      <div style={{fontSize:9,color:"#444",marginBottom:3}}>ETIQUETA</div>
                      <input value={keyForm.customLabel} onChange={e=>setKeyForm(f=>({...f,customLabel:e.target.value}))}
                        placeholder="Mi Custom Key" style={S.keyInput}/>
                    </div>
                  )}

                  <div style={{marginBottom:6}}>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>ENV VAR</div>
                    <input value={keyForm.envVar} onChange={e=>setKeyForm(f=>({...f,envVar:e.target.value}))}
                      placeholder="MY_API_KEY" style={S.keyInput}/>
                  </div>

                  <div style={{marginBottom:8}}>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>API KEY VALUE</div>
                    <input type="password" value={keyForm.keyValue} onChange={e=>setKeyForm(f=>({...f,keyValue:e.target.value}))}
                      onKeyDown={e=>e.key==="Enter"&&saveKey()}
                      placeholder="sk-... / AIza... / pk_..." style={S.keyInput}/>
                  </div>

                  <button onClick={saveKey} disabled={!keyForm.keyValue.trim()||!keyForm.providerId}
                    style={{...S.btn,fontSize:11,opacity:(!keyForm.keyValue.trim()||!keyForm.providerId)?0.4:1}}>
                    💾 Guardar key cifrada
                  </button>
                </div>

                {/* Search */}
                {apiKeys.length>0 && (
                  <input value={keySearch} onChange={e=>setKeySearch(e.target.value)}
                    placeholder="🔍 Buscar keys..." style={{...S.keyInput,marginBottom:8}}/>
                )}

                {/* Stored keys list */}
                {apiKeys.length===0 ? (
                  <div style={{color:"#444",fontSize:11,textAlign:"center",padding:16}}>
                    Sin API keys guardadas.<br/>Añade tu primera key arriba.
                  </div>
                ) : apiKeys.filter(k=>
                    !keySearch || k.label.toLowerCase().includes(keySearch.toLowerCase()) ||
                    k.envVar.toLowerCase().includes(keySearch.toLowerCase()) ||
                    k.providerId.toLowerCase().includes(keySearch.toLowerCase())
                  ).map(k => {
                    const prov = API_PROVIDERS.find(p=>p.id===k.providerId);
                    const isRevealed = revealedKeys.has(k.id);
                    const isDetected = autoDetected.includes(k.providerId);
                    const wasInjected = lastInjected.find(i=>i.providerId===k.providerId);
                    return (
                      <div key={k.id} style={{
                        border:`1px solid ${isDetected?"#f59e0b60":wasInjected?"#00f5a040":"#1a1d26"}`,
                        borderRadius:8,padding:"8px 10px",marginBottom:6,background:"#0c0e14",
                        position:"relative",transition:"all 0.2s"
                      }}>
                        {isDetected && <div style={{position:"absolute",top:-8,right:8,background:"#f59e0b",color:"#000",fontSize:8,padding:"1px 6px",borderRadius:10,fontWeight:700}}>⚡ DETECTADA</div>}
                        {wasInjected && !isDetected && <div style={{position:"absolute",top:-8,right:8,background:"#00f5a0",color:"#000",fontSize:8,padding:"1px 6px",borderRadius:10,fontWeight:700}}>✓ INYECTADA</div>}
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:4}}>
                          <div style={{display:"flex",alignItems:"center",gap:6}}>
                            <span style={{fontSize:16}}>{prov?.icon||"🔑"}</span>
                            <div>
                              <div style={{fontSize:12,fontWeight:700,color:prov?.color||"#888"}}>{k.label}</div>
                              <div style={{fontSize:9,color:"#444",fontFamily:"monospace"}}>{k.envVar}</div>
                            </div>
                          </div>
                          <div style={{display:"flex",gap:4}}>
                            <button onClick={()=>toggleReveal(k.id)} style={S.keyBtn} title={isRevealed?"Ocultar":"Revelar"}>{isRevealed?"👁‍🗨":"👁"}</button>
                            <button onClick={()=>navigator.clipboard.writeText(deobfuscate(k.encKey))} style={S.keyBtn} title="Copiar">⎘</button>
                            <button onClick={()=>deleteKey(k.id)} style={{...S.keyBtn,color:"#ef4444"}} title="Eliminar">✕</button>
                          </div>
                        </div>
                        <div style={{fontFamily:"monospace",fontSize:10,color:isRevealed?"#00f5a0":"#444",background:"#080a0e",padding:"4px 8px",borderRadius:4,letterSpacing:isRevealed?0:2}}>
                          {isRevealed ? deobfuscate(k.encKey) : maskKey(deobfuscate(k.encKey))}
                        </div>
                        <div style={{fontSize:9,color:"#333",marginTop:4,display:"flex",justifyContent:"space-between"}}>
                          <span>Añadida: {k.addedAt}</span>
                          {k.lastUsed && <span style={{color:"#00f5a050"}}>Usado: {k.lastUsed}</span>}
                        </div>
                      </div>
                    );
                  })
                }

                {/* Auto-detected alert */}
                {autoDetected.filter(id=>apiKeys.find(k=>k.providerId===id)).length>0 && (
                  <div style={{background:"#f59e0b12",border:"1px solid #f59e0b30",borderRadius:8,padding:"8px 10px",marginTop:8}}>
                    <div style={{fontSize:10,color:"#f59e0b",fontWeight:700,marginBottom:4}}>⚡ Keys que se inyectarán automáticamente:</div>
                    {autoDetected.filter(id=>apiKeys.find(k=>k.providerId===id)).map(id=>{
                      const k = apiKeys.find(k=>k.providerId===id);
                      const p = API_PROVIDERS.find(p=>p.id===id);
                      return <div key={id} style={{fontSize:10,color:"#888",display:"flex",alignItems:"center",gap:4}}>
                        <span>{p?.icon}</span> {k?.label} <span style={{color:"#444",fontFamily:"monospace"}}>{k?.envVar}</span>
                      </div>;
                    })}
                  </div>
                )}

                {/* Missing keys alert */}
                {autoDetected.filter(id=>!apiKeys.find(k=>k.providerId===id)).length>0 && (
                  <div style={{background:"#ef444412",border:"1px solid #ef444430",borderRadius:8,padding:"8px 10px",marginTop:6}}>
                    <div style={{fontSize:10,color:"#ef4444",fontWeight:700,marginBottom:4}}>⚠ Keys detectadas pero no guardadas:</div>
                    {autoDetected.filter(id=>!apiKeys.find(k=>k.providerId===id)).map(id=>{
                      const p = API_PROVIDERS.find(p=>p.id===id);
                      return <div key={id} style={{fontSize:10,color:"#888",display:"flex",alignItems:"center",gap:4,cursor:"pointer"}}
                        onClick={()=>{setKeyForm(f=>({...f,providerId:id,envVar:p?.envVar||"",customLabel:p?.name||""}));setSidebarTab("keys");}}>
                        <span>{p?.icon}</span> {p?.name} <span style={{color:"#ef4444"}}>→ click para añadir</span>
                      </div>;
                    })}
                  </div>
                )}
              </>}
            </div>
          </aside>
        )}

        {/* ─ MAIN ────────────────────────────────────────────────────────── */}
        <main style={S.main}>
          {/* Output mode bar */}
          <div style={S.modeBar}>
            {OUTPUT_MODES.map((m,i)=>(
              <button key={m.id} onClick={()=>{setOutputMode(m.id);if(m.id==="debug"){setDebugMode(true);setSidebarTab("debug");}}}
                style={{...S.modeBtn,...(outputMode===m.id?{borderColor:m.color,color:m.color,background:m.color+"12"}:{})}}>
                <span style={S.modeNum}>{i+1}</span>{m.icon} {m.label}
              </button>
            ))}
            <div style={{flex:1}}/>
            <button onClick={()=>setAgentPipeline(p=>!p)} style={{...S.modeBtn,...(agentPipeline?{borderColor:"#06b6d4",color:"#06b6d4",background:"#06b6d412"}:{})}}>
              ⚡ Pipeline
            </button>
            <button onClick={()=>setCompareMode(p=>!p)} style={{...S.modeBtn,...(compareMode?{borderColor:"#a78bfa",color:"#a78bfa",background:"#a78bfa12"}:{})}}>
              ⚖ Comparar
            </button>
          </div>

          {/* Token Budget Bar */}
          {showTokenBar && (
            <div style={{display:"flex",alignItems:"center",gap:8,padding:"3px 12px",background:"#050608",borderBottom:"1px solid #0d0f14",flexShrink:0}}>
              <span style={{fontSize:9,color:"#444",flexShrink:0}}>CTX</span>
              <div style={{flex:1,height:3,background:"#111520",borderRadius:2,overflow:"hidden",position:"relative"}}>
                <div style={{height:"100%",width:`${tokenPct}%`,background:tokenColor,borderRadius:2,transition:"width 0.4s ease",boxShadow:`0 0 6px ${tokenColor}80`}}/>
              </div>
              <span style={{fontSize:9,color:tokenColor,flexShrink:0,fontFamily:"monospace"}}>{estimatedTokens.toLocaleString()}/{(tokenBudget/1000).toFixed(0)}k</span>
              <span style={{fontSize:9,color:tokenPct>60?tokenColor:"#333",flexShrink:0}}>{tokenPct}%</span>
              {tokenPct > 60 && (
                <button onClick={compressContext} disabled={compressing}
                  style={{fontSize:8,padding:"1px 7px",borderRadius:3,cursor:"pointer",border:`1px solid ${tokenColor}50`,
                    background:tokenColor+"12",color:tokenColor,fontFamily:"monospace",flexShrink:0,animation:tokenPct>80?"blink 2s infinite":"none"}}>
                  {compressing?"⌛ comprimiendo...":"⚡ comprimir"}
                </button>
              )}
            </div>
          )}
          {showMemPanel && (
            <div style={S.memPanel}>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                <span style={{fontSize:11,color:"#888"}}>🧠 MEMORIAS · RAG ({memories.length} explícitas · {vectorStore.length} vectores)</span>
                <button onClick={()=>setShowMemPanel(false)} style={{background:"none",border:"none",color:"#444",cursor:"pointer"}}>✕</button>
              </div>
              {ragResults.length>0 && <div style={{fontSize:10,color:"#7c3aed",marginBottom:4}}>⬡ RAG recuperó {ragResults.length} docs relevantes para tu última consulta</div>}
              <div style={{maxHeight:90,overflow:"auto",display:"flex",flexDirection:"column",gap:3}}>
                {memories.slice(0,6).map(m=>(
                  <div key={m.id} style={{fontSize:11,color:"#888",borderLeft:"2px solid #f59e0b40",padding:"2px 6px"}}>
                    <span style={{color:"#f59e0b"}}>◆</span> {m.content.slice(0,100)} <span style={{color:"#444",fontSize:9}}>· {m.time}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Output preview bar */}
          {generatedOutput && (
            <div style={S.outBar}>
              <span style={{color:"#00f5a0",fontSize:12}}>{generatedOutput.type==="webapp"?"🌐 Web App":"📦 Proyecto"} generado</span>
              <div style={{display:"flex",gap:6}}>
                {generatedOutput.type==="webapp" && <>
                  <button onClick={()=>{setSandboxHtml(generatedOutput.content);setRightPanel("sandbox");}} style={S.outBtn}>⚗️ Sandbox</button>
                  <button onClick={()=>{const w=window.open("");w.document.write(generatedOutput.content);w.document.close();}} style={S.outBtn}>↗ Abrir</button>
                </>}
                {generatedOutput.type==="project" && generatedOutput.files?.map(f=>(
                  <span key={f.name} style={{...S.outBtn,cursor:"default"}}>📄 {f.name}</span>
                ))}
                <button onClick={()=>setGeneratedOutput(null)} style={{...S.outBtn,color:"#555",borderColor:"#333"}}>✕</button>
              </div>
            </div>
          )}

          {/* Voice transcript live display */}
          {voiceActive && voiceTranscript && (
            <div style={{padding:"4px 12px",background:"#ef444410",borderBottom:"1px solid #ef444430",flexShrink:0,fontSize:11,color:"#ef4444",display:"flex",alignItems:"center",gap:6}}>
              <span style={{animation:"blink 0.8s infinite"}}>🎙</span> <span style={{color:"#c8cdd8"}}>{voiceTranscript}</span>
            </div>
          )}

          {/* Comparison model selector */}
          {compareMode && (
            <div style={{padding:"5px 12px",background:"#a78bfa0c",borderBottom:"1px solid #a78bfa20",flexShrink:0,display:"flex",alignItems:"center",gap:8,flexWrap:"wrap"}}>
              <span style={{fontSize:10,color:"#a78bfa"}}>⚖ Comparando con:</span>
              {["claude",...ollamaModels.slice(0,6).map(m=>m.name)].filter(m=>m!==selectedModel).map(m=>(
                <button key={m} onClick={()=>setCompareModelB(m)} style={{...S.chip,cursor:"pointer",
                  color:compareModelB===m?"#a78bfa":"#555",borderColor:compareModelB===m?"#a78bfa40":"#1a1d26",
                  background:compareModelB===m?"#a78bfa12":"#0c0e14"}}>
                  {m==="claude"?"⬡ claude":m.split(":")[0]}
                </button>
              ))}
              {compareRespB && <button onClick={()=>setCompareRespB(null)} style={{...S.chip,color:"#444",cursor:"pointer"}}>✕ Limpiar</button>}
            </div>
          )}

          {/* Chat + optional comparison split */}
          <div style={{flex:1,overflow:"hidden",display:"flex",flexDirection:compareMode&&compareRespB?"row":"column"}}>
            <div ref={chatRef} style={{...S.chat,flex:1}}>
              {messages.length===0 && <Welcome modes={OUTPUT_MODES} setMode={m=>{setOutputMode(m);}} agents={AGENTS} />}
            {messages.map(msg => {
              // Show streaming content for the placeholder bubble
              if (msg._streaming && streamMsgId===msg.id) {
                return (
                  <div key={msg.id} style={{display:"flex",gap:10,marginBottom:16,alignItems:"flex-start"}}>
                    <div style={{width:28,height:28,borderRadius:"50%",background:"#0c0e14",border:"1px solid #00f5a040",display:"flex",alignItems:"center",justifyContent:"center",fontSize:14,flexShrink:0}}>⚡</div>
                    <div style={{flex:1,maxWidth:"calc(100% - 60px)"}}>
                      <div style={{background:"#0c0e14",borderRadius:"0 10px 10px 10px",padding:"10px 14px",border:"1px solid #1a1d26",position:"relative"}}>
                        <div style={{fontSize:12,color:"#c8cdd8",lineHeight:1.7,whiteSpace:"pre-wrap",wordBreak:"break-word"}}>
                          {streamContent||<span style={{color:"#444",animation:"blink 1s infinite"}}>▌</span>}
                        </div>
                        {/* Abort streaming button */}
                        <button onClick={()=>abortCtrlRef.current?.abort()} style={{position:"absolute",top:6,right:8,background:"#ef444415",border:"1px solid #ef444430",borderRadius:4,color:"#ef4444",cursor:"pointer",fontSize:9,padding:"1px 6px"}}>⏹ stop</button>
                      </div>
                    </div>
                  </div>
                );
              }
              return <ChatMsg key={msg.id} msg={msg} modes={OUTPUT_MODES} agents={AGENTS} onFork={(idx)=>forkConversation(idx)} msgIndex={messages.indexOf(msg)}/>;
            })}
              {loading && (
                <div style={{display:"flex",alignItems:"center",gap:10,padding:"8px 0",marginBottom:8}}>
                  <div style={{width:28,height:28,borderRadius:"50%",background:"#0c0e14",border:`1px solid ${currentAgent?AGENTS.find(a=>a.id===currentAgent)?.color+"40":"#1a1d26"}`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:14}}>
                    {currentAgent?AGENTS.find(a=>a.id===currentAgent)?.icon:"⬡"}
                  </div>
                  <div style={{display:"flex",gap:4}}>{[0,150,300].map(d=><span key={d} style={{width:7,height:7,borderRadius:"50%",background:"#00f5a0",display:"inline-block",animation:`dotPulse 1.4s ease-in-out ${d}ms infinite`}}/>)}</div>
                  <span style={{color:"#444",fontSize:11}}>
                    {currentAgent?`${currentAgent} · `:""}
                    {selectedModel==="claude"?"claude-sonnet-4":selectedModel}
                  </span>
                </div>
              )}
            </div>

            {/* Comparison response pane */}
            {compareMode && compareRespB && (
              <div style={{flex:1,borderLeft:"1px solid #a78bfa30",display:"flex",flexDirection:"column",overflow:"hidden"}}>
                <div style={{padding:"6px 12px",background:"#a78bfa0c",borderBottom:"1px solid #a78bfa20",flexShrink:0,display:"flex",justifyContent:"space-between"}}>
                  <span style={{fontSize:10,color:"#a78bfa",fontWeight:700}}>⚖ {compareRespB.model==="claude"?"claude-sonnet-4":compareRespB.model}</span>
                  <span style={{fontSize:9,color:"#555"}}>{compareRespB.time}</span>
                </div>
                <div style={{flex:1,overflow:"auto",padding:14}}>
                  {compareLoading ? (
                    <div style={{display:"flex",gap:4,padding:8}}>{[0,150,300].map(d=><span key={d} style={{width:7,height:7,borderRadius:"50%",background:"#a78bfa",display:"inline-block",animation:`dotPulse 1.4s ease-in-out ${d}ms infinite`}}/>)}</div>
                  ) : (
                    <div style={{fontSize:12,color:"#c8cdd8",lineHeight:1.7,whiteSpace:"pre-wrap"}}>{compareRespB.content}</div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Input */}
          <div style={S.inputWrap}>
            <div style={S.inputMeta}>
              <span style={{...S.chip,color:"#00f5a0",borderColor:"#00f5a030",background:"#00f5a008"}}>{selectedModel==="claude"?"⬡ claude-sonnet-4":`⚡ ${selectedModel}`}</span>
              <span style={{...S.chip,color:OUTPUT_MODES.find(m=>m.id===outputMode)?.color,borderColor:OUTPUT_MODES.find(m=>m.id===outputMode)?.color+"30",background:OUTPUT_MODES.find(m=>m.id===outputMode)?.color+"08"}}>
                {OUTPUT_MODES.find(m=>m.id===outputMode)?.icon} {OUTPUT_MODES.find(m=>m.id===outputMode)?.label}
              </span>
              {agentPipeline && <span style={{...S.chip,color:"#06b6d4",borderColor:"#06b6d430",background:"#06b6d408"}}>⚡ pipeline·{activeAgents.length}</span>}
              {activeMcp.slice(0,4).map(t=><span key={t.id} style={{...S.chip,fontSize:14,padding:"1px 5px"}}>{t.icon}</span>)}
              {activeMcp.length>4 && <span style={S.chip}>+{activeMcp.length-4}</span>}
              {vectorStore.length>0 && <span style={{...S.chip,color:"#7c3aed",borderColor:"#7c3aed30",background:"#7c3aed08"}}>🧠 rag:{vectorStore.length}</span>}
              {autoDetected.filter(id=>apiKeys.find(k=>k.providerId===id)).map(id=>{
                const p=API_PROVIDERS.find(p=>p.id===id);
                return <span key={id} style={{...S.chip,color:"#f59e0b",borderColor:"#f59e0b40",background:"#f59e0b0c",fontSize:9}}>⚡{p?.icon}{p?.name?.split(" ")[0]}</span>;
              })}
              {autoDetected.filter(id=>!apiKeys.find(k=>k.providerId===id)).map(id=>{
                const p=API_PROVIDERS.find(p=>p.id===id);
                return <span key={id} title="Key no guardada — click para añadir" onClick={()=>{setKeyForm(f=>({...f,providerId:id,envVar:p?.envVar||"",customLabel:p?.name||""}));setSidebarTab("keys");}}
                  style={{...S.chip,color:"#ef4444",borderColor:"#ef444440",background:"#ef44440c",fontSize:9,cursor:"pointer"}}>🔑 {p?.name?.split(" ")[0]}?</span>;
              })}
            </div>
            <div style={{display:"flex",gap:8,alignItems:"flex-end"}}>
              {voiceSupported && (
                <button onClick={toggleVoice} title={voiceActive?"Detener dictado":"Iniciar dictado por voz"}
                  style={{...S.sendBtn,background:voiceActive?"#ef444420":"#0c0e14",borderColor:voiceActive?"#ef4444":"#1a1d26",
                    color:voiceActive?"#ef4444":"#555",animation:voiceActive?"blink 1s infinite":"none",width:38,height:38,fontSize:15}}>
                  {voiceActive?"⏹":"🎙"}
                </button>
              )}
              <button onClick={()=>setShowPromptLib(p=>!p)} title="Prompts guardados"
                style={{...S.sendBtn,background:"#0c0e14",borderColor:"#1a1d26",color:"#555",width:38,height:38,fontSize:14}}>
                ⚡
              </button>
              <div style={{flex:1,position:"relative"}}>
                <textarea ref={inputRef} value={input} onChange={handleInputChange} onKeyDown={handleKey} rows={3}
                  placeholder={`${voiceActive?"🎙 Escuchando...":""}${compareMode?"[⚖ Modo comparación] ":""}[${outputMode}] ${agentPipeline?`pipeline·`:""}${selectedModel==="claude"?"claude-sonnet-4":selectedModel} · Enter para enviar`}
                  style={{...S.textarea,width:"100%",borderColor:voiceActive?"#ef444440":showEnhance?"#a78bfa40":"#1a1d26"}}/>
                {/* Enhance button overlay */}
                <button onClick={enhancePrompt} disabled={enhancing||!input.trim()}
                  title="🪄 Mejorar prompt con IA"
                  style={{position:"absolute",bottom:8,right:10,fontSize:14,background:enhancing?"#a78bfa20":"transparent",
                    border:"none",cursor:input.trim()?"pointer":"default",opacity:input.trim()?1:0.3,
                    color:enhancing?"#a78bfa":"#555",transition:"all 0.2s",padding:"2px 4px",borderRadius:4}}>
                  {enhancing?"⌛":"🪄"}
                </button>
              </div>
              <button onClick={sendMessage} disabled={loading||!input.trim()} style={S.sendBtn}>{loading?"⌛":"▶"}</button>
            </div>
          </div>
        </main>

        {/* ─ RIGHT PANEL ─────────────────────────────────────────────────── */}
        {rightPanel && (
          <aside style={S.rightPanel}>
            <div style={S.rpHeader}>
              <div style={{display:"flex",gap:4}}>
                {[["observe","🔭 Traces"],["sandbox","⚗️ Sandbox"],["github","🐙 GitHub"],["files","📂 Archivos"],["web","🌐 Web"],["term","⌨️ Term"]].map(([id,label])=>(
                  <button key={id} onClick={()=>setRightPanel(id)} style={{...S.rpTab,...(rightPanel===id?S.rpTabOn:{})}}>
                    {label}
                  </button>
                ))}
              </div>
              <button onClick={()=>setRightPanel(null)} style={{background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:16}}>✕</button>
            </div>

            {/* OBSERVABILITY */}
            {rightPanel==="observe" && (
              <div style={S.rpBody}>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6,marginBottom:12}}>
                  {[
                    ["Total calls",traces.length,"#06b6d4"],
                    ["Tokens",totalTokens.toLocaleString(),"#00f5a0"],
                    ["Costo",`$${totalCost.toFixed(4)}`,"#f59e0b"],
                    ["Avg latency",traces.length?fmtMs(Math.round(traces.reduce((a,t)=>a+t.ms,0)/traces.length)):"—","#7c3aed"],
                  ].map(([l,v,c])=>(
                    <div key={l} style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"6px 10px"}}>
                      <div style={{fontSize:9,color:"#444",letterSpacing:1}}>{l.toUpperCase()}</div>
                      <div style={{fontSize:16,fontWeight:700,color:c,marginTop:2}}>{v}</div>
                    </div>
                  ))}
                </div>
                <Sec>TRACES</Sec>
                {traces.length===0 ? <div style={{color:"#444",fontSize:11}}>Sin traces aún</div> :
                  traces.slice(0,50).map(t=>(
                    <div key={t.id} style={{borderLeft:`2px solid ${AGENTS.find(a=>a.id===t.agent)?.color||"#444"}40`,padding:"4px 8px",marginBottom:6,fontSize:10}}>
                      <div style={{display:"flex",justifyContent:"space-between",marginBottom:2}}>
                        <span style={{color:AGENTS.find(a=>a.id===t.agent)?.color||"#888",fontWeight:600}}>{AGENTS.find(a=>a.id===t.agent)?.icon} {t.agent}</span>
                        <span style={{color:"#444"}}>{fmtMs(t.ms)}</span>
                      </div>
                      <div style={{color:"#555"}}>{t.model} · {t.tokens} tok · ${t.cost}</div>
                      <div style={{color:"#333",marginTop:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{t.prompt}</div>
                    </div>
                  ))
                }
                <button onClick={()=>{setTraces([]);setTotalTokens(0);setTotalCost(0);}} style={{...S.btn,borderColor:"#33333380",color:"#555",marginTop:8}}>Limpiar traces</button>
              </div>
            )}

            {/* SANDBOX */}
            {rightPanel==="sandbox" && (
              <div style={S.rpBody}>
                <div style={{fontSize:11,color:"#888",marginBottom:8}}>
                  ⚗️ E2B-like sandbox — ejecuta el código generado de forma segura
                </div>
                {sandboxHtml ? (
                  <div style={{flex:1,display:"flex",flexDirection:"column",gap:8}}>
                    <div style={{display:"flex",gap:6}}>
                      <button onClick={()=>{const w=window.open("");w.document.write(sandboxHtml);w.document.close();}} style={S.outBtn}>↗ Abrir</button>
                      <button onClick={()=>navigator.clipboard.writeText(sandboxHtml)} style={S.outBtn}>⎘ Copiar HTML</button>
                      <button onClick={()=>setSandboxHtml("")} style={{...S.outBtn,color:"#555",borderColor:"#333"}}>✕</button>
                    </div>
                    <iframe
                      srcDoc={sandboxHtml}
                      style={{flex:1,border:"1px solid #1a1d26",borderRadius:8,background:"white",minHeight:400}}
                      sandbox="allow-scripts allow-same-origin"
                      title="Sandbox preview"/>
                  </div>
                ) : (
                  <div style={{color:"#444",fontSize:11,lineHeight:1.6}}>
                    Genera una <strong style={{color:"#00f5a0"}}>Web App</strong> en el chat para ver el preview aquí.<br/><br/>
                    El sandbox ejecuta el código en un iframe aislado con sandbox="allow-scripts".
                  </div>
                )}
              </div>
            )}

            {/* GITHUB */}
            {rightPanel==="github" && (
              <div style={S.rpBody}>
                <Sec>GITHUB MCP</Sec>
                <div style={{display:"flex",gap:6,marginBottom:12}}>
                  <input value={githubRepo} onChange={e=>setGithubRepo(e.target.value)}
                    placeholder="owner/repo o URL completa"
                    onKeyDown={e=>e.key==="Enter"&&fetchGitHub()}
                    style={{flex:1,background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"6px 10px",color:"#c8cdd8",fontFamily:"monospace",fontSize:11,outline:"none"}}/>
                  <button onClick={fetchGitHub} disabled={githubLoading} style={{...S.outBtn,padding:"6px 12px"}}>
                    {githubLoading?"...":"→"}
                  </button>
                </div>
                {githubData ? (
                  <div style={{display:"flex",flexDirection:"column",gap:10}}>
                    <div style={{background:"#0c0e14",border:"1px solid #7c3aed40",borderRadius:8,padding:"10px 12px"}}>
                      <div style={{fontSize:13,fontWeight:700,color:"#7c3aed"}}>{githubData.full_name}</div>
                      <div style={{fontSize:11,color:"#888",marginTop:4}}>{githubData.description}</div>
                      <div style={{display:"flex",gap:12,marginTop:8,fontSize:11,color:"#666"}}>
                        <span>⭐ {githubData.stargazers_count?.toLocaleString()}</span>
                        <span>🍴 {githubData.forks_count?.toLocaleString()}</span>
                        <span>👁 {githubData.watchers_count?.toLocaleString()}</span>
                        <span>🔤 {githubData.language}</span>
                      </div>
                    </div>
                    {githubData.readmeText && <>
                      <Sec>README PREVIEW</Sec>
                      <div style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"8px 12px",fontSize:10,color:"#888",lineHeight:1.6,maxHeight:300,overflow:"auto",whiteSpace:"pre-wrap"}}>
                        {githubData.readmeText}
                      </div>
                    </>}
                    <button onClick={()=>setInput(`Analiza el repo ${githubData.full_name}: ${githubData.description}. README:\n${githubData.readmeText?.slice(0,500)}`)}
                      style={S.btn}>⬡ Analizar con AI</button>
                  </div>
                ) : (
                  <div style={{color:"#444",fontSize:11,lineHeight:1.6}}>
                    Ingresa un repositorio de GitHub para:<br/>
                    • Ver stats y README<br/>
                    • Inyectar contexto en RAG<br/>
                    • Analizar con el agente AI<br/>
                    • Generar PRs e issues
                  </div>
                )}
              </div>
            )}

            {/* ── FILES PANEL ─────────────────────────────────────────────── */}
            {rightPanel==="files" && (
              <div style={S.rpBody}>
                {fsPermission!=="granted" ? (
                  <div style={{display:"flex",flexDirection:"column",alignItems:"center",gap:16,padding:24,textAlign:"center"}}>
                    <span style={{fontSize:48}}>📁</span>
                    <div style={{fontFamily:"'Syne',sans-serif",fontSize:16,fontWeight:800,color:"#f59e0b"}}>Acceso al Sistema de Archivos</div>
                    <div style={{fontSize:11,color:"#555",lineHeight:1.7}}>
                      Otorga acceso para que los agentes puedan crear, editar y eliminar archivos y carpetas directamente en tu equipo.
                    </div>
                    <button onClick={requestFsAccess} style={{...S.btn,fontSize:13,padding:"10px 20px",
                      background:"#f59e0b18",borderColor:"#f59e0b50",color:"#f59e0b"}}>
                      {fsPermission==="requesting"?"⏳ Solicitando...":"📂 Seleccionar carpeta raíz"}
                    </button>
                    <div style={{fontSize:9,color:"#333",lineHeight:1.6}}>
                      Aparecerá un diálogo del sistema operativo.<br/>Requiere Chrome/Edge 86+ para File System Access API.
                    </div>
                  </div>
                ) : (
                  <div style={{display:"flex",flexDirection:"column",gap:0,height:"100%"}}>
                    {/* FS Header */}
                    <div style={{padding:"8px 10px",borderBottom:"1px solid #111520",flexShrink:0}}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:6}}>
                        <div style={{display:"flex",alignItems:"center",gap:6}}>
                          <span style={{color:"#f59e0b",fontSize:14}}>📂</span>
                          <span style={{fontSize:11,fontWeight:700,color:"#f59e0b"}}>{fsRootPath}</span>
                          <span style={{fontSize:9,color:"#00f5a0",background:"#00f5a010",padding:"1px 5px",borderRadius:3}}>readwrite</span>
                        </div>
                        <div style={{display:"flex",gap:4}}>
                          <button onClick={refreshFsTree} style={S.keyBtn} title="Refrescar">{fsLoading?"⌛":"↻"}</button>
                          <button onClick={requestFsAccess} style={S.keyBtn} title="Cambiar carpeta">⇄</button>
                        </div>
                      </div>
                      {/* Output path config */}
                      <div style={{display:"flex",gap:4,alignItems:"center"}}>
                        <span style={{fontSize:9,color:"#444",flexShrink:0}}>Salida:</span>
                        <input value={fsOutputPath} onChange={e=>setFsOutputPath(e.target.value)}
                          placeholder="AgentStudio-Output"
                          style={{...S.keyInput,fontSize:10,padding:"3px 7px",flex:1}}/>
                        <button onClick={()=>fsCreateFolder(fsOutputPath||"AgentStudio-Output")} style={{...S.keyBtn,fontSize:10,padding:"3px 7px"}}>+</button>
                      </div>
                    </div>

                    {/* FS Actions */}
                    <div style={{display:"flex",gap:4,padding:"6px 10px",borderBottom:"1px solid #111520",flexShrink:0}}>
                      <FsQuickAction icon="📄" label="Nuevo archivo" onClick={async()=>{
                        const name=prompt("Nombre del archivo (con extensión):","nuevo.js");
                        if(name) await fsWriteFile(`${fsOutputPath||"AgentStudio-Output"}/${name}`,"// Nuevo archivo\n");
                      }}/>
                      <FsQuickAction icon="📁" label="Nueva carpeta" onClick={async()=>{
                        const name=prompt("Nombre de la carpeta:");
                        if(name) await fsCreateFolder(`${fsOutputPath||"AgentStudio-Output"}/${name}`);
                      }}/>
                      <FsQuickAction icon="💾" label="Guardar output" onClick={()=>{
                        const last=messages.filter(m=>m.role==="assistant").slice(-1)[0];
                        if(last) writeProjectToFs(last.content);
                      }}/>
                    </div>

                    {/* FS Tree */}
                    <div style={{flex:1,overflow:"auto",padding:"8px 4px"}}>
                      {fsLoading ? (
                        <div style={{color:"#444",fontSize:11,padding:16,textAlign:"center"}}>⌛ Cargando árbol...</div>
                      ) : fsTree.length===0 ? (
                        <div style={{color:"#444",fontSize:11,padding:16,textAlign:"center"}}>Carpeta vacía</div>
                      ) : (
                        fsTree.map(node => <FsNode key={node.id} node={node} depth={0}
                          onRead={fsReadFile} onDelete={fsDeleteEntry}
                          onSelect={setFsSelected} selected={fsSelected?.path}/>)
                      )}
                    </div>

                    {/* File editor */}
                    {fsSelected && (
                      <div style={{borderTop:"1px solid #111520",flexShrink:0,maxHeight:220}}>
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"4px 10px",background:"#0c0e14",borderBottom:"1px solid #111520"}}>
                          <span style={{fontSize:10,color:"#7c3aed"}}>✎ {fsSelected.path}</span>
                          <div style={{display:"flex",gap:4}}>
                            <button onClick={async()=>{
                              await fsWriteFile(fsSelected.path,fsFileContent);
                            }} style={{...S.keyBtn,color:"#00f5a0",fontSize:9}}>💾 Guardar</button>
                            <button onClick={()=>{setFsSelected(null);setFsFileContent("");}} style={{...S.keyBtn,fontSize:9}}>✕</button>
                          </div>
                        </div>
                        <textarea value={fsFileContent} onChange={e=>setFsFileContent(e.target.value)}
                          style={{width:"100%",height:160,background:"#07080d",border:"none",outline:"none",
                            padding:"8px 10px",color:"#a8b4c8",fontFamily:"'JetBrains Mono',monospace",
                            fontSize:10,resize:"none",lineHeight:1.5}}/>
                      </div>
                    )}

                    {/* FS Log */}
                    <div style={{borderTop:"1px solid #111520",padding:"4px 8px",flexShrink:0,maxHeight:80,overflow:"auto"}}>
                      <div style={{fontSize:8,color:"#333",letterSpacing:1,marginBottom:3}}>FS LOG</div>
                      {fsLog.slice(0,10).map(l=>(
                        <div key={l.id} style={{fontSize:9,fontFamily:"monospace",display:"flex",gap:6,lineHeight:1.8}}>
                          <span style={{color:l.color,fontWeight:700}}>{l.op}</span>
                          <span style={{color:"#444"}}>{l.time}</span>
                          <span style={{color:"#888",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",flex:1}}>{l.path}</span>
                          <span style={{color:l.status.startsWith("✓")?"#00f5a0":"#ef4444",flexShrink:0}}>{l.status}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            )}

            {/* ── WEB PANEL ─────────────────────────────────────────────────── */}
            {rightPanel==="web" && (
              <div style={S.rpBody}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12}}>
                  <Sec>ACCESO WEB DE AGENTES</Sec>
                  <button onClick={toggleWebAccess}
                    style={{fontSize:10,padding:"3px 10px",borderRadius:5,cursor:"pointer",border:`1px solid ${webAccess?"#06b6d440":"#333"}`,
                      background:webAccess?"#06b6d418":"#111",color:webAccess?"#06b6d4":"#555",fontFamily:"monospace"}}>
                    {webAccess?"● ACTIVO":"○ INACTIVO"}
                  </button>
                </div>

                {!webAccess && (
                  <div style={{background:"#06b6d40c",border:"1px solid #06b6d425",borderRadius:8,padding:14,marginBottom:12,textAlign:"center"}}>
                    <div style={{fontSize:24,marginBottom:8}}>🌐</div>
                    <div style={{fontSize:12,color:"#06b6d4",fontWeight:700,marginBottom:6}}>Acceso Web para Agentes</div>
                    <div style={{fontSize:10,color:"#555",lineHeight:1.7,marginBottom:10}}>
                      Permite a los agentes buscar información en tiempo real,<br/>consultar APIs públicas y acceder a documentación actualizada.
                    </div>
                    <button onClick={toggleWebAccess} style={{...S.btn,borderColor:"#06b6d440",color:"#06b6d4",background:"#06b6d415",fontSize:12}}>
                      🌐 Activar acceso web
                    </button>
                  </div>
                )}

                {webAccess && (
                  <>
                    <div style={{background:"#06b6d40c",border:"1px solid #06b6d425",borderRadius:8,padding:"8px 12px",marginBottom:10,fontSize:10,color:"#06b6d4"}}>
                      ✓ Agentes con acceso a internet · Modo: {webProxyMode}
                    </div>

                    {/* Manual search */}
                    <Sec>BÚSQUEDA MANUAL DE AGENTE</Sec>
                    <div style={{display:"flex",gap:6,marginBottom:10}}>
                      <input value={webSearchQuery} onChange={e=>setWebSearchQuery(e.target.value)}
                        onKeyDown={e=>e.key==="Enter"&&agentWebSearch()}
                        placeholder="Buscar con el agente..." style={{...S.keyInput,flex:1}}/>
                      <button onClick={agentWebSearch} disabled={webSearchLoading||!webSearchQuery.trim()}
                        style={{...S.outBtn,padding:"6px 10px",flexShrink:0}}>
                        {webSearchLoading?"⌛":"🔍"}
                      </button>
                    </div>

                    {/* Search results */}
                    {webSearchResults.length>0 && (
                      <div style={{marginBottom:10}}>
                        <Sec>RESULTADOS</Sec>
                        {webSearchResults.slice(0,5).map(r=>(
                          <div key={r.id} style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,padding:"8px 10px",marginBottom:6}}>
                            <div style={{fontSize:10,color:"#06b6d4",marginBottom:4}}>{r.query}</div>
                            <div style={{fontSize:10,color:"#888",lineHeight:1.6}}>{r.result.slice(0,200)}...</div>
                            <div style={{display:"flex",gap:6,marginTop:6}}>
                              <button onClick={()=>setInput(`Basándote en esta info: "${r.result.slice(0,400)}"...`)} style={{...S.keyBtn,fontSize:9}}>→ Usar en chat</button>
                              <span style={{fontSize:9,color:"#444"}}>{r.time}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Web modes */}
                    <Sec>MODO DE ACCESO</Sec>
                    {[["direct","🔗 Directo","Llamadas directas a APIs públicas"],["brave","🦁 Brave Search","API de Brave para búsquedas privadas"],["firecrawl","🔥 Firecrawl","Web scraping profundo con estructuración"]].map(([id,label,desc])=>(
                      <div key={id} onClick={()=>setWebProxyMode(id)}
                        style={{...S.mcpRow,...(webProxyMode===id?{borderColor:"#06b6d430",background:"#06b6d40a"}:{}),cursor:"pointer",marginBottom:4}}>
                        <span style={{fontSize:14}}>{label.split(" ")[0]}</span>
                        <div style={{flex:1}}>
                          <div style={{fontSize:11,color:webProxyMode===id?"#06b6d4":"#666"}}>{label.slice(2)}</div>
                          <div style={{fontSize:9,color:"#444"}}>{desc}</div>
                        </div>
                        <div style={{width:8,height:8,borderRadius:"50%",background:webProxyMode===id?"#06b6d4":"#222"}}/>
                      </div>
                    ))}

                    {/* Web log */}
                    <Sec style={{marginTop:12}}>LOG DE ACTIVIDAD WEB</Sec>
                    <div style={{maxHeight:180,overflow:"auto"}}>
                      {webAccessLog.length===0 ? <div style={{fontSize:10,color:"#444"}}>Sin actividad</div> :
                        webAccessLog.slice(0,20).map(l=>(
                          <div key={l.id} style={{fontSize:9,fontFamily:"monospace",borderBottom:"1px solid #0d0f14",padding:"3px 0",lineHeight:1.8}}>
                            <span style={{color:"#444"}}>{l.time} </span>
                            <span style={{color:l.status.includes("ON")?"#06b6d4":l.status.includes("OK")?"#00f5a0":"#ef4444"}}>{l.status} </span>
                            <span style={{color:"#666",overflow:"hidden",textOverflow:"ellipsis",display:"block",whiteSpace:"nowrap"}}>{l.url}</span>
                          </div>
                        ))
                      }
                    </div>
                  </>
                )}
              </div>
            )}
            {/* ── TERMINAL PANEL ────────────────────────────────────────────── */}
            {rightPanel==="term" && (
              <div style={{display:"flex",flexDirection:"column",height:"100%",overflow:"hidden"}}>
                {/* Terminal header */}
                <div style={{padding:"6px 12px",background:"#040507",borderBottom:"1px solid #0d0f14",flexShrink:0,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{color:"#00f5a0",fontSize:13}}>⌨️</span>
                    <span style={{fontSize:10,color:"#00f5a0",fontWeight:700}}>TERMINAL</span>
                    {fsPermission==="granted" && <span style={{fontSize:9,color:"#f59e0b",background:"#f59e0b10",padding:"1px 5px",borderRadius:3}}>{fsRootPath}</span>}
                  </div>
                  <div style={{display:"flex",gap:6}}>
                    <button onClick={()=>setTermLines([])} style={{...S.keyBtn,fontSize:9}}>clear</button>
                    <button onClick={()=>{termPrint("help ejecutado","system");executeTermCmd("help");}} style={{...S.keyBtn,fontSize:9}}>help</button>
                  </div>
                </div>

                {/* Terminal output */}
                <div ref={termRef} onClick={()=>termInputRef.current?.focus()}
                  style={{flex:1,overflow:"auto",padding:"8px 12px",fontFamily:"'JetBrains Mono',monospace",fontSize:11,lineHeight:1.7,background:"#030406",cursor:"text"}}>
                  {termLines.map(l=>(
                    <div key={l.id} style={{color:l.type==="prompt"?"#7c3aed":l.type==="error"?"#ef4444":l.type==="system"?"#555":"#a8b4c8",whiteSpace:"pre-wrap",wordBreak:"break-all"}}>
                      {l.text}
                    </div>
                  ))}
                </div>

                {/* Terminal input */}
                <div style={{display:"flex",alignItems:"center",padding:"6px 12px",background:"#040507",borderTop:"1px solid #0d0f14",flexShrink:0,gap:6}}>
                  <span style={{color:"#00f5a0",fontSize:11,flexShrink:0,fontFamily:"monospace"}}>
                    {fsRootPath||"~"}{termCwd} $
                  </span>
                  <input ref={termInputRef} value={termInput}
                    onChange={e=>setTermInput(e.target.value)}
                    onKeyDown={handleTermKey}
                    placeholder="escribe un comando..."
                    style={{flex:1,background:"transparent",border:"none",outline:"none",color:"#00f5a0",fontFamily:"'JetBrains Mono',monospace",fontSize:11,caretColor:"#00f5a0"}}
                    autoComplete="off" spellCheck="false" autoCorrect="off"/>
                </div>
              </div>
            )}
          </aside>
        )}
      </div>

      {/* ── FLOATING API KEY MANAGER ─────────────────────────────────────── */}
      {showKeyMgr && (
        <div style={S.keyOverlay} onClick={()=>setShowKeyMgr(false)}>
          <div style={S.keyModal} onClick={e=>e.stopPropagation()}>
            <div style={S.keyModalHeader}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:20}}>🔑</span>
                <div>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,color:"#f59e0b"}}>API KEY VAULT</div>
                  <div style={{fontSize:9,color:"#444"}}>Cifrado local · Auto-inyección por contexto · {apiKeys.length} keys guardadas</div>
                </div>
              </div>
              <button onClick={()=>setShowKeyMgr(false)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:18}}>✕</button>
            </div>

            {/* Quick add form */}
            <div style={{padding:"12px 16px",borderBottom:"1px solid #111520"}}>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:10}}>
                <div>
                  <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:4}}>PROVEEDOR</div>
                  <select value={keyForm.providerId} onChange={e=>{
                    const p=API_PROVIDERS.find(pr=>pr.id===e.target.value);
                    setKeyForm(f=>({...f,providerId:e.target.value,envVar:p?.envVar||f.envVar,customLabel:p?.name||f.customLabel}));
                  }} style={{...S.keyInput,appearance:"none",cursor:"pointer"}}>
                    <option value="">-- Seleccionar --</option>
                    <option value="custom">⚙ Custom</option>
                    {["AI","Search","Dev","DB","Payment","Comms","Maps","Media","Cloud","Exec"].map(cat=>(
                      <optgroup key={cat} label={`── ${cat} ──`}>
                        {API_PROVIDERS.filter(p=>p.cat===cat).map(p=>(
                          <option key={p.id} value={p.id}>{p.icon} {p.name}</option>
                        ))}
                      </optgroup>
                    ))}
                  </select>
                </div>
                <div>
                  <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:4}}>ENV VARIABLE</div>
                  <input value={keyForm.envVar} onChange={e=>setKeyForm(f=>({...f,envVar:e.target.value}))}
                    placeholder="API_KEY_NAME" style={S.keyInput}/>
                </div>
              </div>
              {keyForm.providerId==="custom" && (
                <div style={{marginBottom:10}}>
                  <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:4}}>ETIQUETA PERSONALIZADA</div>
                  <input value={keyForm.customLabel} onChange={e=>setKeyForm(f=>({...f,customLabel:e.target.value}))}
                    placeholder="Nombre de tu key" style={S.keyInput}/>
                </div>
              )}
              <div style={{marginBottom:10}}>
                <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:4}}>API KEY</div>
                <input type="password" value={keyForm.keyValue} onChange={e=>setKeyForm(f=>({...f,keyValue:e.target.value}))}
                  onKeyDown={e=>e.key==="Enter"&&saveKey()}
                  placeholder="sk-... / AIza... / pk_live_... / Bearer ..." style={S.keyInput}/>
              </div>
              <div style={{display:"flex",gap:8}}>
                <button onClick={saveKey} disabled={!keyForm.keyValue.trim()||!keyForm.providerId}
                  style={{...S.btn,flex:1,opacity:(!keyForm.keyValue.trim()||!keyForm.providerId)?0.4:1}}>
                  💾 Guardar key cifrada
                </button>
                <button onClick={()=>setKeyForm({providerId:"",customLabel:"",keyValue:"",envVar:""})}
                  style={{...S.btn,flex:0,padding:"7px 12px",background:"none",color:"#555",borderColor:"#333"}}>✕ Limpiar</button>
              </div>
            </div>

            {/* Keys list in modal */}
            <div style={{flex:1,overflow:"auto",padding:"10px 16px"}}>
              {apiKeys.length===0 ? (
                <div style={{color:"#444",fontSize:12,textAlign:"center",padding:24}}>
                  Sin API keys guardadas aún.<br/>
                  <span style={{fontSize:10}}>Usa el formulario de arriba para añadir tu primera key.</span>
                </div>
              ) : (
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                  {apiKeys.map(k=>{
                    const prov=API_PROVIDERS.find(p=>p.id===k.providerId);
                    const isRevealed=revealedKeys.has(k.id);
                    const isDetected=autoDetected.includes(k.providerId);
                    return(
                      <div key={k.id} style={{
                        border:`1px solid ${isDetected?"#f59e0b60":"#1a1d26"}`,
                        borderRadius:8,padding:"8px 10px",background:"#0c0e14",position:"relative"
                      }}>
                        {isDetected && <div style={{position:"absolute",top:-7,right:8,background:"#f59e0b",color:"#000",fontSize:8,padding:"1px 6px",borderRadius:10,fontWeight:700}}>⚡ DETECTADA</div>}
                        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:6}}>
                          <div style={{display:"flex",alignItems:"center",gap:5}}>
                            <span style={{fontSize:18}}>{prov?.icon||"🔑"}</span>
                            <div>
                              <div style={{fontSize:11,fontWeight:700,color:prov?.color||"#888"}}>{k.label}</div>
                              <div style={{fontSize:8,color:"#444",fontFamily:"monospace"}}>{k.envVar}</div>
                            </div>
                          </div>
                          <div style={{display:"flex",gap:2}}>
                            <button onClick={()=>toggleReveal(k.id)} style={S.keyBtn}>{isRevealed?"🙈":"👁"}</button>
                            <button onClick={()=>navigator.clipboard.writeText(deobfuscate(k.encKey))} style={S.keyBtn}>⎘</button>
                            <button onClick={()=>deleteKey(k.id)} style={{...S.keyBtn,color:"#ef4444"}}>✕</button>
                          </div>
                        </div>
                        <div style={{fontFamily:"monospace",fontSize:9,color:isRevealed?"#00f5a0":"#333",background:"#07080d",padding:"3px 6px",borderRadius:4,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                          {isRevealed ? deobfuscate(k.encKey) : maskKey(deobfuscate(k.encKey))}
                        </div>
                        {k.lastUsed && <div style={{fontSize:8,color:"#00f5a040",marginTop:4}}>✓ Usado: {k.lastUsed}</div>}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ── PROJECT TEMPLATES MODAL ──────────────────────────────────────── */}
      {showTemplates && (
        <div style={S.keyOverlay} onClick={()=>setShowTemplates(false)}>
          <div style={{...S.keyModal,borderColor:"#a78bfa35",boxShadow:"0 0 80px #a78bfa12"}} onClick={e=>e.stopPropagation()}>
            <div style={S.keyModalHeader}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:22}}>📋</span>
                <div>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,color:"#a78bfa"}}>PLANTILLAS DE PROYECTO</div>
                  <div style={{fontSize:9,color:"#444"}}>Un click genera el scaffold completo · Modo Proyecto automático</div>
                </div>
              </div>
              <button onClick={()=>setShowTemplates(false)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:18}}>✕</button>
            </div>
            <div style={{padding:"8px 12px",borderBottom:"1px solid #111520",flexShrink:0}}>
              <input value={templateSearch} onChange={e=>setTemplateSearch(e.target.value)}
                placeholder="🔍 Buscar plantilla..." style={S.keyInput}/>
            </div>
            <div style={{flex:1,overflow:"auto",padding:12,display:"grid",gridTemplateColumns:"1fr 1fr",gap:10}}>
              {PROJECT_TEMPLATES.filter(t=>!templateSearch||t.name.toLowerCase().includes(templateSearch.toLowerCase())||t.tags.some(g=>g.includes(templateSearch.toLowerCase()))).map(tpl=>(
                <div key={tpl.id} onClick={()=>applyTemplate(tpl)}
                  style={{border:"1px solid #1a1d26",borderRadius:10,padding:"12px 14px",cursor:"pointer",background:"#0c0e14",transition:"all 0.2s",display:"flex",flexDirection:"column",gap:6}}
                  onMouseEnter={e=>e.currentTarget.style.borderColor=tpl.color}
                  onMouseLeave={e=>e.currentTarget.style.borderColor="#1a1d26"}>
                  <div style={{display:"flex",alignItems:"center",gap:8}}>
                    <span style={{fontSize:22}}>{tpl.icon}</span>
                    <div>
                      <div style={{fontSize:12,fontWeight:700,color:tpl.color}}>{tpl.name}</div>
                      <div style={{fontSize:9,color:"#444"}}>{tpl.stack}</div>
                    </div>
                  </div>
                  <div style={{fontSize:10,color:"#666",lineHeight:1.5}}>{tpl.desc}</div>
                  <div style={{display:"flex",gap:4,flexWrap:"wrap",marginTop:2}}>
                    {tpl.tags.map(t=><span key={t} style={{background:"#151820",color:"#555",fontSize:8,padding:"1px 5px",borderRadius:3}}>{t}</span>)}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ── PROMPT LIBRARY PANEL ──────────────────────────────────────────── */}
      {showPromptLib && (
        <div style={{position:"fixed",bottom:80,right:20,width:380,maxHeight:520,background:"#09090f",border:"1px solid #f59e0b35",borderRadius:12,boxShadow:"0 -8px 40px #f59e0b10",zIndex:500,display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{padding:"10px 14px",borderBottom:"1px solid #151820",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#0a0c14",flexShrink:0}}>
            <div style={{fontSize:13,fontWeight:700,color:"#f59e0b",fontFamily:"'Syne',sans-serif"}}>⚡ PROMPT LIBRARY</div>
            <button onClick={()=>setShowPromptLib(false)} style={{background:"none",border:"none",color:"#444",cursor:"pointer"}}>✕</button>
          </div>

          {/* Add new prompt */}
          <div style={{padding:"10px 12px",borderBottom:"1px solid #111520",flexShrink:0,display:"flex",flexDirection:"column",gap:6}}>
            <input value={promptForm.title} onChange={e=>setPromptForm(f=>({...f,title:e.target.value}))}
              placeholder="Título del prompt..." style={{...S.keyInput,fontSize:10}}/>
            <textarea value={promptForm.content} onChange={e=>setPromptForm(f=>({...f,content:e.target.value}))}
              placeholder="Escribe el prompt aquí..."
              style={{...S.keyInput,resize:"none",height:60,fontSize:10,lineHeight:1.5}}/>
            <div style={{display:"flex",gap:6}}>
              <input value={promptForm.tags} onChange={e=>setPromptForm(f=>({...f,tags:e.target.value}))}
                placeholder="tags: react, api, debug..." style={{...S.keyInput,fontSize:10,flex:1}}/>
              <button onClick={savePromptToLib} disabled={!promptForm.content.trim()}
                style={{...S.outBtn,padding:"4px 10px",opacity:!promptForm.content.trim()?0.4:1}}>+ Guardar</button>
            </div>
          </div>

          {/* Search & list */}
          <div style={{padding:"6px 12px",flexShrink:0}}>
            <input value={promptSearch} onChange={e=>setPromptSearch(e.target.value)}
              placeholder="🔍 Buscar prompts..." style={{...S.keyInput,fontSize:10}}/>
          </div>
          <div style={{flex:1,overflow:"auto",padding:"0 12px 12px"}}>
            {/* Built-in prompts */}
            {!promptSearch && <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:6,marginTop:4}}>PROMPTS RÁPIDOS</div>}
            {BUILTIN_PROMPTS.filter(p=>!promptSearch||p.title.toLowerCase().includes(promptSearch.toLowerCase())).map(p=>(
              <div key={p.id} onClick={()=>usePrompt(p)}
                style={{border:"1px solid #1a1d26",borderRadius:6,padding:"7px 10px",marginBottom:5,cursor:"pointer",background:"#0c0e14",transition:"all 0.15s"}}
                onMouseEnter={e=>e.currentTarget.style.borderColor="#f59e0b40"}
                onMouseLeave={e=>e.currentTarget.style.borderColor="#1a1d26"}>
                <div style={{fontSize:11,color:"#f59e0b",fontWeight:600}}>{p.icon} {p.title}</div>
                <div style={{fontSize:9,color:"#555",marginTop:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.content.slice(0,60)}</div>
              </div>
            ))}
            {savedPrompts.length>0 && <>
              <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:6,marginTop:8}}>MIS PROMPTS ({savedPrompts.length})</div>
              {savedPrompts.filter(p=>!promptSearch||p.title.toLowerCase().includes(promptSearch.toLowerCase())).map(p=>(
                <div key={p.id} style={{border:"1px solid #1a2040",borderRadius:6,padding:"7px 10px",marginBottom:5,background:"#0c0e14",display:"flex",justifyContent:"space-between",alignItems:"flex-start"}}>
                  <div onClick={()=>usePrompt(p)} style={{flex:1,cursor:"pointer"}}>
                    <div style={{fontSize:11,color:"#c8cdd8",fontWeight:600}}>{p.title}</div>
                    <div style={{fontSize:9,color:"#555",marginTop:2,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{p.content.slice(0,60)}</div>
                    <div style={{fontSize:8,color:"#333",marginTop:2}}>usados: {p.usedCount} · {p.createdAt}</div>
                  </div>
                  <button onClick={()=>deletePrompt(p.id)} style={{...S.keyBtn,color:"#ef4444",flexShrink:0}}>✕</button>
                </div>
              ))}
            </>}
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          🪄 PROMPT ENHANCER PREVIEW MODAL
      ══════════════════════════════════════════════════════════════════ */}
      {showEnhance && enhancePreview && (
        <div style={S.keyOverlay} onClick={discardEnhanced}>
          <div style={{...S.keyModal,borderColor:"#a78bfa40",boxShadow:"0 0 80px #a78bfa15",maxWidth:680}} onClick={e=>e.stopPropagation()}>
            <div style={{...S.keyModalHeader,borderColor:"#1a1d26"}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:22}}>🪄</span>
                <div>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,color:"#a78bfa"}}>PROMPT MEJORADO</div>
                  <div style={{fontSize:9,color:"#444"}}>La IA ha expandido y estructurado tu prompt. Acepta o descarta.</div>
                </div>
              </div>
              <button onClick={discardEnhanced} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:18}}>✕</button>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:0,flex:1,overflow:"hidden"}}>
              <div style={{padding:16,borderRight:"1px solid #111520",display:"flex",flexDirection:"column",gap:6}}>
                <div style={{fontSize:9,color:"#444",letterSpacing:2,marginBottom:4}}>ORIGINAL</div>
                <div style={{background:"#080a0e",border:"1px solid #1a1d26",borderRadius:8,padding:12,fontSize:11,color:"#666",lineHeight:1.7,flex:1,overflow:"auto"}}>
                  {enhancePreview.original}
                </div>
                <div style={{fontSize:9,color:"#333"}}>{Math.ceil(enhancePreview.original.length/4)} tokens estimados</div>
              </div>
              <div style={{padding:16,display:"flex",flexDirection:"column",gap:6}}>
                <div style={{fontSize:9,color:"#a78bfa",letterSpacing:2,marginBottom:4}}>✨ MEJORADO</div>
                <div style={{background:"#0d0814",border:"1px solid #a78bfa30",borderRadius:8,padding:12,fontSize:11,color:"#c8cdd8",lineHeight:1.7,flex:1,overflow:"auto"}}>
                  {enhancePreview.enhanced}
                </div>
                <div style={{fontSize:9,color:"#a78bfa50"}}>{Math.ceil(enhancePreview.enhanced.length/4)} tokens estimados · {Math.round(enhancePreview.enhanced.length/enhancePreview.original.length*10)/10}x más detallado</div>
              </div>
            </div>
            <div style={{display:"flex",gap:10,padding:"12px 16px",borderTop:"1px solid #111520",flexShrink:0}}>
              <button onClick={applyEnhanced} style={{...S.btn,flex:1,borderColor:"#a78bfa50",color:"#a78bfa",background:"#a78bfa12",fontSize:12}}>
                ✓ Usar prompt mejorado
              </button>
              <button onClick={discardEnhanced} style={{...S.btn,flex:0,padding:"7px 16px",background:"none",color:"#555",borderColor:"#333",fontSize:12}}>
                Mantener original
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          ⚡ CODE RUNNER MODAL
      ══════════════════════════════════════════════════════════════════ */}
      {showRunner && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.9)",zIndex:900,display:"flex",alignItems:"center",justifyContent:"center"}} onClick={()=>setShowRunner(false)}>
          <div style={{background:"#08090e",border:"1px solid #00f5a035",borderRadius:12,width:"min(1100px,96vw)",height:"85vh",display:"flex",flexDirection:"column",boxShadow:"0 0 80px #00f5a010",overflow:"hidden"}} onClick={e=>e.stopPropagation()}>
            {/* Runner header */}
            <div style={{display:"flex",alignItems:"center",gap:8,padding:"10px 16px",borderBottom:"1px solid #111520",flexShrink:0,background:"#0a0c14"}}>
              <span style={{fontSize:18}}>▶️</span>
              <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,color:"#00f5a0",fontSize:14}}>CODE RUNNER</span>
              <span style={{fontSize:9,color:"#444"}}>— Ejecuta código directamente en sandbox aislado</span>
              <div style={{flex:1}}/>
              {/* Lang selector */}
              {["javascript","html","css"].map(l=>(
                <button key={l} onClick={()=>setRunnerLang(l)} style={{...S.keyBtn,fontSize:10,color:runnerLang===l?"#00f5a0":"#555",borderColor:runnerLang===l?"#00f5a040":"#1a1d26",background:runnerLang===l?"#00f5a010":"transparent"}}>
                  {l}
                </button>
              ))}
              <button onClick={()=>setShowRunner(false)} style={{background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:18,marginLeft:8}}>✕</button>
            </div>
            {/* Main runner body */}
            <div style={{display:"flex",flex:1,overflow:"hidden"}}>
              {/* Code editor */}
              <div style={{flex:1,display:"flex",flexDirection:"column",borderRight:"1px solid #111520"}}>
                <div style={{display:"flex",gap:6,padding:"6px 12px",borderBottom:"1px solid #0d0f14",flexShrink:0,background:"#0a0c14"}}>
                  <button onClick={runCode} disabled={runnerRunning||!runnerCode.trim()}
                    style={{...S.outBtn,padding:"4px 14px",fontSize:11,fontWeight:700}}>
                    {runnerRunning?"⌛ Ejecutando...":"▶ Ejecutar"}
                  </button>
                  <button onClick={loadCodeFromLastAI} style={{...S.keyBtn,fontSize:10}}>⬇ Cargar última respuesta</button>
                  <button onClick={()=>{setRunnerCode("");setRunnerOutput([]);setRunnerSrcDoc("");}} style={{...S.keyBtn,fontSize:10}}>✕ Limpiar</button>
                </div>
                <div style={{flex:1,position:"relative"}}>
                  <textarea value={runnerCode} onChange={e=>setRunnerCode(e.target.value)}
                    placeholder={`// Escribe o pega código ${runnerLang} aquí...\nconsole.log("Hello from AgentStudio Runner!");`}
                    style={{width:"100%",height:"100%",background:"#030406",border:"none",outline:"none",padding:"12px 16px",
                      color:"#a8b4c8",fontFamily:"'JetBrains Mono',monospace",fontSize:12,resize:"none",lineHeight:1.7,
                      caretColor:"#00f5a0"}}
                    spellCheck={false} autoCorrect="off"/>
                  {/* Line numbers overlay hint */}
                  <div style={{position:"absolute",top:12,left:0,width:40,pointerEvents:"none",textAlign:"right",paddingRight:8,color:"#222",fontSize:12,fontFamily:"monospace",lineHeight:1.7,userSelect:"none"}}>
                    {runnerCode.split("\n").map((_,i)=><div key={i}>{i+1}</div>)}
                  </div>
                </div>
              </div>
              {/* Output + preview split */}
              <div style={{width:420,display:"flex",flexDirection:"column"}}>
                {/* Iframe preview */}
                {runnerSrcDoc && (
                  <div style={{height:"50%",borderBottom:"1px solid #111520",flexShrink:0}}>
                    <div style={{fontSize:9,color:"#444",padding:"4px 10px",background:"#0a0c14",letterSpacing:1}}>PREVIEW</div>
                    <iframe ref={runnerIframeRef} srcDoc={runnerSrcDoc}
                      sandbox="allow-scripts" style={{width:"100%",height:"calc(100% - 22px)",border:"none",background:"#030406"}}/>
                  </div>
                )}
                {/* Console output */}
                <div style={{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"}}>
                  <div style={{fontSize:9,color:"#444",padding:"4px 10px",background:"#0a0c14",letterSpacing:1,display:"flex",justifyContent:"space-between",flexShrink:0}}>
                    CONSOLE ({runnerOutput.length})
                    <button onClick={()=>setRunnerOutput([])} style={{background:"none",border:"none",color:"#333",cursor:"pointer",fontSize:9}}>clear</button>
                  </div>
                  <div style={{flex:1,overflow:"auto",padding:"6px 12px",fontFamily:"'JetBrains Mono',monospace",fontSize:11,lineHeight:1.8,background:"#030406"}}>
                    {runnerOutput.length===0 ? <div style={{color:"#333"}}>// Ejecuta código para ver output aquí</div> :
                      runnerOutput.map(l=>(
                        <div key={l.id} style={{color:l.type==="error"?"#ef4444":l.type==="warn"?"#f59e0b":l.type==="system"?"#555":"#a8b4c8",borderBottom:"1px solid #07080c",padding:"1px 0"}}>
                          <span style={{color:"#333",marginRight:8}}>{l.time}</span>
                          {l.type==="error"&&<span style={{color:"#ef4444",marginRight:4}}>✕</span>}
                          {l.type==="warn"&&<span style={{color:"#f59e0b",marginRight:4}}>⚠</span>}
                          {l.text}
                        </div>
                      ))
                    }
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          🔬 SELF-REVIEW PANEL (slide from right)
      ══════════════════════════════════════════════════════════════════ */}
      {showReview && selfReview && (
        <div style={{position:"fixed",top:50,right:rightPanel?354:0,width:360,bottom:0,background:"#08090e",border:"1px solid #06b6d430",boxShadow:"-8px 0 40px #06b6d410",zIndex:600,display:"flex",flexDirection:"column",overflow:"hidden",transition:"right 0.3s"}}>
          <div style={{padding:"10px 14px",borderBottom:"1px solid #111520",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#0a0c14",flexShrink:0}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span style={{fontSize:18}}>🔬</span>
              <div>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,color:"#06b6d4",fontSize:13}}>SELF-REVIEW</div>
                <div style={{fontSize:9,color:"#444"}}>Score del output generado por la IA</div>
              </div>
            </div>
            <div style={{display:"flex",gap:6,alignItems:"center"}}>
              <label style={{fontSize:9,color:"#555",display:"flex",alignItems:"center",gap:4,cursor:"pointer"}}>
                <input type="checkbox" checked={autoReview} onChange={e=>setAutoReview(e.target.checked)} style={{accentColor:"#06b6d4",width:10,height:10}}/>
                auto
              </label>
              <button onClick={()=>setShowReview(false)} style={{background:"none",border:"none",color:"#444",cursor:"pointer"}}>✕</button>
            </div>
          </div>

          {/* Overall score */}
          <div style={{padding:"12px 16px",borderBottom:"1px solid #111520",flexShrink:0}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:10}}>
              <span style={{fontSize:11,color:"#888"}}>Overall Score</span>
              <span style={{fontFamily:"'Syne',sans-serif",fontWeight:900,fontSize:28,color:selfReview.overall>=80?"#00f5a0":selfReview.overall>=60?"#f59e0b":"#ef4444"}}>
                {selfReview.overall}<span style={{fontSize:14,color:"#444"}}>/100</span>
              </span>
            </div>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {Object.entries(selfReview.scores||{}).map(([key,val])=>{
                const labels={completeness:"Completitud",security:"Seguridad",performance:"Rendimiento",errorHandling:"Error Handling",codeQuality:"Calidad"};
                const c = val>=80?"#00f5a0":val>=60?"#f59e0b":"#ef4444";
                return(
                  <div key={key} style={{background:"#0c0e14",borderRadius:6,padding:"6px 8px",border:"1px solid #1a1d26"}}>
                    <div style={{fontSize:8,color:"#444",marginBottom:4}}>{labels[key]||key}</div>
                    <div style={{display:"flex",alignItems:"center",gap:6}}>
                      <div style={{flex:1,height:4,background:"#111520",borderRadius:2,overflow:"hidden"}}>
                        <div style={{height:"100%",width:`${val}%`,background:c,borderRadius:2}}/>
                      </div>
                      <span style={{fontSize:10,color:c,fontWeight:700,flexShrink:0}}>{val}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Issues */}
          <div style={{flex:1,overflow:"auto",padding:"10px 14px",display:"flex",flexDirection:"column",gap:10}}>
            {selfReview.critical?.length>0 && (
              <div>
                <div style={{fontSize:9,color:"#ef4444",letterSpacing:1,marginBottom:6}}>⚠ CRÍTICOS ({selfReview.critical.length})</div>
                {selfReview.critical.map((c,i)=>(
                  <div key={i} style={{borderLeft:"2px solid #ef4444",padding:"4px 8px",marginBottom:4,fontSize:10,color:"#c8cdd8",lineHeight:1.5}}>{c}</div>
                ))}
              </div>
            )}
            {selfReview.warnings?.length>0 && (
              <div>
                <div style={{fontSize:9,color:"#f59e0b",letterSpacing:1,marginBottom:6}}>⚡ ADVERTENCIAS ({selfReview.warnings.length})</div>
                {selfReview.warnings.map((w,i)=>(
                  <div key={i} style={{borderLeft:"2px solid #f59e0b",padding:"4px 8px",marginBottom:4,fontSize:10,color:"#888",lineHeight:1.5}}>{w}</div>
                ))}
              </div>
            )}
            {selfReview.positives?.length>0 && (
              <div>
                <div style={{fontSize:9,color:"#00f5a0",letterSpacing:1,marginBottom:6}}>✓ PUNTOS FUERTES</div>
                {selfReview.positives.map((p,i)=>(
                  <div key={i} style={{borderLeft:"2px solid #00f5a040",padding:"4px 8px",marginBottom:4,fontSize:10,color:"#555",lineHeight:1.5}}>{p}</div>
                ))}
              </div>
            )}
            {selfReview.autofix && (
              <div>
                <div style={{fontSize:9,color:"#7c3aed",letterSpacing:1,marginBottom:6}}>🔧 AUTO-FIX DISPONIBLE</div>
                <button onClick={()=>{setInput("Aplica este fix al código anterior:\n\n"+selfReview.autofix.slice(0,400));setShowReview(false);}}
                  style={{...S.btn,borderColor:"#7c3aed40",color:"#7c3aed",background:"#7c3aed10",fontSize:11}}>
                  → Aplicar fix automático
                </button>
              </div>
            )}
          </div>

          <div style={{padding:"8px 14px",borderTop:"1px solid #111520",flexShrink:0}}>
            <button onClick={reviewLastResponse} disabled={reviewing} style={{...S.btn,fontSize:11,borderColor:"#06b6d440",color:"#06b6d4",background:"#06b6d410"}}>
              {reviewing?"⌛ Analizando...":"↺ Re-analizar última respuesta"}
            </button>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          📚 SNIPPET BANK MODAL
      ══════════════════════════════════════════════════════════════════ */}
      {showSnippets && (
        <div style={S.keyOverlay} onClick={()=>setShowSnippets(false)}>
          <div style={{...S.keyModal,borderColor:"#a78bfa35",width:"min(900px,96vw)",height:"80vh"}} onClick={e=>e.stopPropagation()}>
            <div style={S.keyModalHeader}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:20}}>🗂</span>
                <div>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,color:"#a78bfa"}}>SNIPPET BANK</div>
                  <div style={{fontSize:9,color:"#444"}}>{snippets.length} fragmentos extraídos automáticamente de tus conversaciones</div>
                </div>
              </div>
              <button onClick={()=>setShowSnippets(false)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:18}}>✕</button>
            </div>
            {/* Filters */}
            <div style={{padding:"8px 12px",borderBottom:"1px solid #111520",flexShrink:0,display:"flex",gap:6,alignItems:"center",flexWrap:"wrap"}}>
              <input value={snippetSearch} onChange={e=>setSnippetSearch(e.target.value)}
                placeholder="🔍 Buscar en snippets..." style={{...S.keyInput,width:200,flex:"none"}}/>
              <button onClick={()=>setSnippetPinned(p=>!p)}
                style={{...S.keyBtn,fontSize:10,color:snippetPinned?"#f59e0b":"#555",borderColor:snippetPinned?"#f59e0b40":"#1a1d26"}}>
                📌 Destacados
              </button>
              <div style={{display:"flex",gap:3,flexWrap:"wrap"}}>
                {["all",...snippetLangs].map(l=>(
                  <button key={l} onClick={()=>setSnippetFilter(l)}
                    style={{...S.filterChip,...(snippetFilter===l?{background:"#a78bfa20",borderColor:"#a78bfa50",color:"#a78bfa"}:{})}}>
                    {l}
                  </button>
                ))}
              </div>
              <div style={{flex:1,textAlign:"right",fontSize:10,color:"#444"}}>{filteredSnippets.length} resultados</div>
            </div>
            {/* Grid */}
            <div style={{flex:1,overflow:"auto",padding:12,display:"grid",gridTemplateColumns:"repeat(auto-fill,minmax(380px,1fr))",gap:10,alignContent:"start"}}>
              {filteredSnippets.length===0 ? (
                <div style={{gridColumn:"1/-1",textAlign:"center",padding:40,color:"#444",fontSize:13}}>
                  {snippets.length===0 ? "Los snippets se extraen automáticamente cuando el agente genera código. Empieza una conversación." : "No hay snippets con esos filtros."}
                </div>
              ) : filteredSnippets.map(s=>(
                <div key={s.id} style={{border:`1px solid ${s.pinned?"#f59e0b40":"#1a1d26"}`,borderRadius:8,overflow:"hidden",background:"#0c0e14",display:"flex",flexDirection:"column"}}>
                  {/* Snippet header */}
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"6px 10px",background:"#0d0f14",borderBottom:"1px solid #111520"}}>
                    <div style={{display:"flex",alignItems:"center",gap:6,minWidth:0}}>
                      <span style={{fontSize:9,background:"#151820",color:"#7c3aed",padding:"1px 6px",borderRadius:3,fontFamily:"monospace",flexShrink:0}}>{s.lang}</span>
                      <span style={{fontSize:11,color:"#888",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{s.label}</span>
                    </div>
                    <div style={{display:"flex",gap:3,flexShrink:0}}>
                      <button onClick={()=>pinSnippet(s.id)} style={{...S.keyBtn,fontSize:12,color:s.pinned?"#f59e0b":"#444"}} title="Destacar">📌</button>
                      <button onClick={()=>copySnippet(s)} style={{...S.keyBtn,fontSize:11}} title="Copiar">⎘</button>
                      <button onClick={()=>useSnippet(s)} style={{...S.keyBtn,fontSize:11,color:"#00f5a0",borderColor:"#00f5a030"}} title="Insertar en chat">→</button>
                      <button onClick={()=>deleteSnippet(s.id)} style={{...S.keyBtn,fontSize:11,color:"#ef4444"}} title="Eliminar">✕</button>
                    </div>
                  </div>
                  {/* Code preview */}
                  <pre style={{margin:0,padding:"8px 12px",fontSize:10,color:"#94a3b8",lineHeight:1.5,overflow:"auto",maxHeight:140,fontFamily:"'JetBrains Mono',monospace",background:"#07080d",flex:1}}>
                    {s.code.slice(0,400)}{s.code.length>400?"...":""}
                  </pre>
                  {/* Footer */}
                  <div style={{display:"flex",justifyContent:"space-between",padding:"4px 10px",borderTop:"1px solid #111520",fontSize:9,color:"#333"}}>
                    <span>{s.from}</span>
                    <span>usado: {s.usedCount}x · {(s.code.length/1024).toFixed(1)} KB</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          🤖 CUSTOM AGENT BUILDER MODAL
      ══════════════════════════════════════════════════════════════════ */}
      {showAgentBuilder && (
        <div style={S.keyOverlay} onClick={()=>setShowAgentBuilder(false)}>
          <div style={{...S.keyModal,borderColor:"#00f5a035",width:"min(860px,96vw)",height:"88vh"}} onClick={e=>e.stopPropagation()}>
            <div style={{...S.keyModalHeader,borderColor:"#111520"}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:22}}>{agentForm.icon||"🤖"}</span>
                <div>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,color:"#00f5a0"}}>
                    {editingAgent?"EDITAR AGENTE":"CREAR AGENTE PERSONALIZADO"}
                  </div>
                  <div style={{fontSize:9,color:"#444"}}>Agente con system prompt propio, modelo específico y personalidad dedicada</div>
                </div>
              </div>
              <button onClick={()=>setShowAgentBuilder(false)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:18}}>✕</button>
            </div>

            <div style={{display:"flex",flex:1,overflow:"hidden"}}>
              {/* Form */}
              <div style={{flex:1,padding:16,overflow:"auto",display:"flex",flexDirection:"column",gap:12,borderRight:"1px solid #111520"}}>
                {/* Basic info */}
                <div style={{display:"grid",gridTemplateColumns:"80px 1fr 120px",gap:8}}>
                  <div>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>ICONO</div>
                    <input value={agentForm.icon} onChange={e=>setAgentForm(f=>({...f,icon:e.target.value}))}
                      style={{...S.keyInput,textAlign:"center",fontSize:24,padding:"4px"}}/>
                  </div>
                  <div>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>NOMBRE DEL AGENTE</div>
                    <input value={agentForm.name} onChange={e=>setAgentForm(f=>({...f,name:e.target.value}))}
                      placeholder="Mi Agente Especializado" style={S.keyInput}/>
                  </div>
                  <div>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>COLOR</div>
                    <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                      {["#00f5a0","#7c3aed","#f59e0b","#ef4444","#06b6d4","#a78bfa","#ec4899","#10b981"].map(c=>(
                        <div key={c} onClick={()=>setAgentForm(f=>({...f,color:c}))}
                          style={{width:20,height:20,borderRadius:"50%",background:c,cursor:"pointer",border:agentForm.color===c?"2px solid white":"2px solid transparent",transition:"all 0.1s"}}/>
                      ))}
                    </div>
                  </div>
                </div>

                <div>
                  <div style={{fontSize:9,color:"#444",marginBottom:3}}>DESCRIPCIÓN CORTA</div>
                  <input value={agentForm.description} onChange={e=>setAgentForm(f=>({...f,description:e.target.value}))}
                    placeholder="Describe qué hace este agente..." style={S.keyInput}/>
                </div>

                <div style={{display:"grid",gridTemplateColumns:"1fr 120px",gap:8}}>
                  <div>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>MODELO BASE</div>
                    <select value={agentForm.model} onChange={e=>setAgentForm(f=>({...f,model:e.target.value}))}
                      style={{...S.keyInput,appearance:"none",cursor:"pointer"}}>
                      <option value="claude">⬡ Claude Sonnet 4 (recomendado)</option>
                      <optgroup label="── Ollama Local ──">
                        {OSS_MODELS.map(m=><option key={m.id} value={m.id}>{m.name}</option>)}
                      </optgroup>
                    </select>
                  </div>
                  <div>
                    <div style={{fontSize:9,color:"#444",marginBottom:3}}>TEMPERATURA ({agentForm.temperature})</div>
                    <input type="range" min="0" max="1" step="0.05" value={agentForm.temperature}
                      onChange={e=>setAgentForm(f=>({...f,temperature:e.target.value}))}
                      style={{width:"100%",accentColor:agentForm.color,marginTop:8}}/>
                    <div style={{display:"flex",justifyContent:"space-between",fontSize:8,color:"#333"}}>
                      <span>preciso</span><span>creativo</span>
                    </div>
                  </div>
                </div>

                <div style={{flex:1}}>
                  <div style={{fontSize:9,color:"#444",marginBottom:3,display:"flex",justifyContent:"space-between"}}>
                    SYSTEM PROMPT
                    <span style={{color:"#555"}}>{agentForm.systemPrompt.length} chars</span>
                  </div>
                  <textarea value={agentForm.systemPrompt} onChange={e=>setAgentForm(f=>({...f,systemPrompt:e.target.value}))}
                    placeholder="Eres un experto en [dominio]. Siempre [comportamiento]. Tu objetivo es [objetivo]..."
                    style={{...S.keyInput,resize:"none",height:200,lineHeight:1.7,fontSize:11}}/>
                </div>

                <div style={{display:"flex",gap:8}}>
                  <button onClick={saveCustomAgent} disabled={!agentForm.name.trim()||!agentForm.systemPrompt.trim()}
                    style={{...S.btn,flex:1,borderColor:agentForm.color+"60",color:agentForm.color,background:agentForm.color+"12",opacity:(!agentForm.name.trim()||!agentForm.systemPrompt.trim())?0.4:1}}>
                    {agentForm.icon} {editingAgent?"Guardar cambios":"Crear agente"}
                  </button>
                  {editingAgent && <button onClick={()=>{setEditingAgent(null);setAgentForm({name:"",icon:"🤖",color:"#00f5a0",systemPrompt:"",model:"claude",temperature:0.7,description:""});}}
                    style={{...S.btn,padding:"7px 14px",background:"none",color:"#555",borderColor:"#333"}}>Nuevo</button>}
                </div>
              </div>

              {/* Presets + saved agents */}
              <div style={{width:280,display:"flex",flexDirection:"column",overflow:"hidden"}}>
                {/* Presets */}
                <div style={{padding:"10px 12px",borderBottom:"1px solid #111520",flexShrink:0}}>
                  <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:8}}>PRESETS EXPERTOS</div>
                  <div style={{display:"flex",flexDirection:"column",gap:5,maxHeight:200,overflow:"auto"}}>
                    {AGENT_PRESETS.map(p=>(
                      <div key={p.name} onClick={()=>setAgentForm(f=>({...f,name:p.name,icon:p.icon,color:p.color,systemPrompt:p.systemPrompt,description:p.description}))}
                        style={{border:"1px solid #1a1d26",borderRadius:6,padding:"6px 10px",cursor:"pointer",background:"#0c0e14",transition:"all 0.15s",display:"flex",gap:8,alignItems:"center"}}
                        onMouseEnter={e=>e.currentTarget.style.borderColor=p.color+"50"}
                        onMouseLeave={e=>e.currentTarget.style.borderColor="#1a1d26"}>
                        <span style={{fontSize:16,flexShrink:0}}>{p.icon}</span>
                        <div>
                          <div style={{fontSize:11,color:p.color,fontWeight:600}}>{p.name}</div>
                          <div style={{fontSize:9,color:"#444",lineHeight:1.4}}>{p.description}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Saved agents */}
                <div style={{flex:1,overflow:"auto",padding:"10px 12px"}}>
                  <div style={{fontSize:9,color:"#444",letterSpacing:1,marginBottom:8}}>MIS AGENTES ({customAgents.length})</div>
                  {customAgents.length===0 ? (
                    <div style={{color:"#333",fontSize:10,textAlign:"center",padding:16}}>Sin agentes creados aún</div>
                  ) : customAgents.map(a=>(
                    <div key={a.id} style={{border:`1px solid ${activeCustomAgent===a.id?a.color+"50":"#1a1d26"}`,borderRadius:8,padding:"8px 10px",marginBottom:6,
                      background:activeCustomAgent===a.id?a.color+"0a":"#0c0e14",cursor:"pointer"}}
                      onClick={()=>activateCustomAgent(a.id)}>
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <div style={{display:"flex",alignItems:"center",gap:6}}>
                          <span style={{fontSize:18}}>{a.icon}</span>
                          <div>
                            <div style={{fontSize:11,fontWeight:700,color:a.color}}>{a.name}</div>
                            <div style={{fontSize:9,color:"#444"}}>{a.description?.slice(0,40)||"Agente personalizado"}</div>
                          </div>
                        </div>
                        <div style={{display:"flex",gap:3}}>
                          <button onClick={e=>{e.stopPropagation();setEditingAgent(a.id);setAgentForm({name:a.name,icon:a.icon,color:a.color,systemPrompt:a.systemPrompt,model:a.model,temperature:a.temperature,description:a.description||""});}}
                            style={S.keyBtn}>✎</button>
                          <button onClick={e=>{e.stopPropagation();deleteCustomAgent(a.id);}}
                            style={{...S.keyBtn,color:"#ef4444"}}>✕</button>
                        </div>
                      </div>
                      {activeCustomAgent===a.id && <div style={{fontSize:8,color:a.color,marginTop:4}}>● ACTIVO · usado: {a.usedCount}x</div>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          📈 ANALYTICS DASHBOARD MODAL
      ══════════════════════════════════════════════════════════════════ */}
      {showAnalytics && (
        <div style={S.keyOverlay} onClick={()=>setShowAnalytics(false)}>
          <div style={{...S.keyModal,borderColor:"#06b6d435",width:"min(900px,96vw)",height:"88vh"}} onClick={e=>e.stopPropagation()}>
            <div style={{...S.keyModalHeader}}>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <span style={{fontSize:20}}>📈</span>
                <div>
                  <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:15,color:"#06b6d4"}}>ANALYTICS DASHBOARD</div>
                  <div style={{fontSize:9,color:"#444"}}>Métricas reales · {traces.length} trazas · ${totalCost.toFixed(4)} total</div>
                </div>
              </div>
              <button onClick={()=>setShowAnalytics(false)} style={{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:18}}>✕</button>
            </div>

            {/* Tabs */}
            <div style={{display:"flex",gap:0,borderBottom:"1px solid #111520",flexShrink:0}}>
              {[["overview","🎯 Overview"],["cost","💰 Coste"],["quality","⭐ Calidad"],["langs","💻 Lenguajes"]].map(([id,label])=>(
                <button key={id} onClick={()=>setAnalyticsTab(id)} style={{...S.rpTab,...(analyticsTab===id?{...S.rpTabOn,borderBottom:"2px solid #06b6d4",borderRadius:0}:{}),padding:"10px 16px",fontSize:11}}>
                  {label}
                </button>
              ))}
            </div>

            <div style={{flex:1,overflow:"auto",padding:20}}>
              {!analytics ? (
                <div style={{textAlign:"center",padding:60,color:"#444"}}>Sin datos aún. Inicia conversaciones para ver métricas.</div>
              ) : analyticsTab==="overview" && (
                <>
                  {/* KPI cards */}
                  <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12,marginBottom:24}}>
                    {[
                      {label:"API Calls",value:analytics.totalTraces,color:"#06b6d4",icon:"📡"},
                      {label:"Tokens Totales",value:totalTokens.toLocaleString(),color:"#00f5a0",icon:"⚡"},
                      {label:"Coste Total",value:`$${totalCost.toFixed(4)}`,color:"#f59e0b",icon:"💰"},
                      {label:"Latencia Media",value:`${analytics.avgLatency}ms`,color:"#a78bfa",icon:"⏱"},
                    ].map((k,i)=>(
                      <div key={i} style={{background:"#0c0e14",border:`1px solid ${k.color}25`,borderRadius:10,padding:"14px 16px",textAlign:"center"}}>
                        <div style={{fontSize:20,marginBottom:4}}>{k.icon}</div>
                        <div style={{fontFamily:"'Syne',sans-serif",fontSize:18,fontWeight:900,color:k.color}}>{k.value}</div>
                        <div style={{fontSize:10,color:"#444",marginTop:2}}>{k.label}</div>
                      </div>
                    ))}
                  </div>

                  {/* By model */}
                  <div style={{marginBottom:20}}>
                    <div style={{fontSize:10,color:"#555",letterSpacing:1,marginBottom:10}}>LLAMADAS POR MODELO</div>
                    {Object.entries(analytics.byModel).map(([model,data])=>{
                      const maxCalls = Math.max(...Object.values(analytics.byModel).map(d=>d.calls));
                      return(
                        <div key={model} style={{display:"flex",alignItems:"center",gap:10,marginBottom:8}}>
                          <div style={{width:120,fontSize:10,color:"#888",overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap",flexShrink:0}}>{model==="claude"?"⬡ claude-sonnet":model}</div>
                          <div style={{flex:1,height:20,background:"#111520",borderRadius:4,overflow:"hidden",position:"relative"}}>
                            <div style={{height:"100%",width:`${(data.calls/maxCalls)*100}%`,background:"linear-gradient(90deg,#06b6d4,#7c3aed)",borderRadius:4,transition:"width 0.8s ease"}}/>
                            <div style={{position:"absolute",right:6,top:"50%",transform:"translateY(-50%)",fontSize:9,color:"#888"}}>{data.calls} calls · {data.tokens.toLocaleString()} tok · {data.avgMs}ms avg</div>
                          </div>
                          <div style={{fontSize:10,color:"#f59e0b",flexShrink:0}}>${data.cost.toFixed(4)}</div>
                        </div>
                      );
                    })}
                  </div>

                  {/* By agent */}
                  <div>
                    <div style={{fontSize:10,color:"#555",letterSpacing:1,marginBottom:10}}>DISTRIBUCIÓN POR AGENTE</div>
                    <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:8}}>
                      {Object.entries(analytics.byAgent).map(([ag,data])=>{
                        const agObj=AGENTS.find(a=>a.id===ag)||{color:"#888",icon:"⬡"};
                        return(
                          <div key={ag} style={{background:"#0c0e14",border:`1px solid ${agObj.color}25`,borderRadius:8,padding:"10px 12px",textAlign:"center"}}>
                            <div style={{fontSize:18}}>{agObj.icon||"⬡"}</div>
                            <div style={{fontSize:11,fontWeight:700,color:agObj.color,marginTop:4}}>{ag}</div>
                            <div style={{fontSize:13,fontWeight:900,color:"#c8cdd8",marginTop:2}}>{data.calls}</div>
                            <div style={{fontSize:9,color:"#444"}}>{data.tokens.toLocaleString()} tokens</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </>
              )}

              {analyticsTab==="cost" && analytics && (
                <div>
                  <div style={{fontSize:10,color:"#555",letterSpacing:1,marginBottom:12}}>DESGLOSE DE COSTE</div>
                  {/* Cost by model chart */}
                  <div style={{display:"flex",gap:16,marginBottom:20}}>
                    {Object.entries(analytics.byModel).map(([model,data])=>{
                      const pct = Math.round((data.cost/Math.max(analytics.sessionCost,0.0001))*100);
                      return(
                        <div key={model} style={{flex:1,background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:10,padding:14,textAlign:"center"}}>
                          <div style={{fontSize:10,color:"#888",marginBottom:8}}>{model==="claude"?"⬡ Claude":model.split(":")[0]}</div>
                          {/* Donut-like circle */}
                          <svg width={80} height={80} viewBox="0 0 80 80" style={{margin:"0 auto",display:"block"}}>
                            <circle cx={40} cy={40} r={30} fill="none" stroke="#111520" strokeWidth={10}/>
                            <circle cx={40} cy={40} r={30} fill="none" stroke="#f59e0b" strokeWidth={10}
                              strokeDasharray={`${pct*1.885} 188.5`} strokeDashoffset={47} strokeLinecap="round" transform="rotate(-90 40 40)"/>
                            <text x={40} y={44} textAnchor="middle" fill="#f59e0b" fontSize={14} fontWeight={700}>{pct}%</text>
                          </svg>
                          <div style={{fontSize:14,fontWeight:900,color:"#f59e0b",marginTop:6}}>${data.cost.toFixed(4)}</div>
                          <div style={{fontSize:9,color:"#444"}}>{data.calls} llamadas</div>
                        </div>
                      );
                    })}
                  </div>
                  <div style={{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:8,padding:16}}>
                    <div style={{fontSize:11,color:"#888",marginBottom:8}}>PROYECCIÓN (basada en uso actual)</div>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:12}}>
                      {[["Por sesión",totalCost],["Por día (10 sesiones)",totalCost*10],["Por mes (300 sesiones)",totalCost*300]].map(([label,val],i)=>(
                        <div key={i} style={{textAlign:"center"}}>
                          <div style={{fontSize:9,color:"#444",marginBottom:4}}>{label}</div>
                          <div style={{fontSize:16,fontWeight:900,color:val>1?"#ef4444":val>0.1?"#f59e0b":"#00f5a0"}}>${val.toFixed(3)}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {analyticsTab==="langs" && analytics && (
                <div>
                  <div style={{fontSize:10,color:"#555",letterSpacing:1,marginBottom:12}}>LENGUAJES GENERADOS — {snippets.length} snippets en banco</div>
                  <div style={{display:"flex",flexDirection:"column",gap:8}}>
                    {analytics.topLangs.map(([lang,count])=>{
                      const maxCount=analytics.topLangs[0]?.[1]||1;
                      const extColors={javascript:"#f0db4f",typescript:"#3178c6",jsx:"#61dafb",tsx:"#61dafb",python:"#3776ab",html:"#e34c26",css:"#264de4",json:"#f59e0b",rust:"#ce422b",go:"#00acd7",sql:"#00758f",bash:"#4ade80"};
                      const color=extColors[lang]||"#888";
                      return(
                        <div key={lang} style={{display:"flex",alignItems:"center",gap:12}}>
                          <div style={{width:90,fontSize:11,color:color,fontWeight:600,fontFamily:"monospace",textAlign:"right",flexShrink:0}}>{lang}</div>
                          <div style={{flex:1,height:28,background:"#111520",borderRadius:6,overflow:"hidden"}}>
                            <div style={{height:"100%",width:`${(count/maxCount)*100}%`,background:`linear-gradient(90deg,${color}40,${color}20)`,borderRadius:6,border:`1px solid ${color}40`,display:"flex",alignItems:"center",paddingLeft:8,transition:"width 0.8s ease"}}>
                              <span style={{fontSize:10,color:color,fontWeight:700}}>{count} snippets</span>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          🌿 BRANCH MANAGER PANEL
      ══════════════════════════════════════════════════════════════════ */}
      {showBranches && (
        <div style={{position:"fixed",top:50,left:sidebarCollapsed?0:290,width:300,bottom:0,background:"#08090e",border:"1px solid #00f5a030",boxShadow:"8px 0 40px #00f5a008",zIndex:600,display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{padding:"10px 14px",borderBottom:"1px solid #111520",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#0a0c14",flexShrink:0}}>
            <div style={{display:"flex",alignItems:"center",gap:8}}>
              <span style={{fontSize:16}}>🌿</span>
              <div>
                <div style={{fontFamily:"'Syne',sans-serif",fontWeight:800,color:"#00f5a0",fontSize:12}}>BRANCHES</div>
                <div style={{fontSize:9,color:"#444"}}>{branches.length} ramas · activa: {branches.find(b=>b.id===activeBranch)?.label||activeBranch}</div>
              </div>
            </div>
            <button onClick={()=>setShowBranches(false)} style={{background:"none",border:"none",color:"#444",cursor:"pointer"}}>✕</button>
          </div>

          <div style={{flex:1,overflow:"auto",padding:10}}>
            {branches.map(b=>{
              const isActive=b.id===activeBranch;
              return(
                <div key={b.id} style={{border:`1px solid ${isActive?"#00f5a040":"#1a1d26"}`,borderRadius:8,padding:"8px 12px",marginBottom:8,
                  background:isActive?"#00f5a008":"#0c0e14",cursor:"pointer"}}
                  onClick={()=>switchBranch(b.id)}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                    <div style={{display:"flex",alignItems:"center",gap:6}}>
                      <span style={{color:isActive?"#00f5a0":"#555",fontSize:14}}>{isActive?"●":"○"}</span>
                      <div>
                        <div style={{fontSize:11,fontWeight:700,color:isActive?"#00f5a0":"#888"}}>{b.label}</div>
                        <div style={{fontSize:9,color:"#444"}}>{b.messages.length} msgs · {b.createdAt}</div>
                      </div>
                    </div>
                    {b.id!=="main" && (
                      <button onClick={e=>{e.stopPropagation();deleteBranch(b.id);}} style={{...S.keyBtn,color:"#ef4444",fontSize:9}}>✕</button>
                    )}
                  </div>
                  {b.parentBranch && <div style={{fontSize:8,color:"#333",marginTop:4}}>↳ de: {b.parentBranch} · fork msg #{b.forkPoint}</div>}
                  {isActive && b.messages.length>0 && (
                    <div style={{fontSize:9,color:"#555",marginTop:6,borderTop:"1px solid #111520",paddingTop:4,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>
                      {b.messages[b.messages.length-1]?.content?.slice(0,60)||"..."}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div style={{padding:"8px 10px",borderTop:"1px solid #111520",flexShrink:0}}>
            <div style={{fontSize:9,color:"#333",textAlign:"center",lineHeight:1.6}}>
              Hover sobre cualquier mensaje en el chat y haz click en 🌿 fork para bifurcar
            </div>
          </div>
        </div>
      )}

      {/* ══════════════════════════════════════════════════════════════════
          🔀 SMART DIFF PANEL
      ══════════════════════════════════════════════════════════════════ */}
      {showDiff && diffData && (
        <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.92)",zIndex:950,display:"flex",flexDirection:"column"}} onClick={()=>setShowDiff(false)}>
          <div style={{background:"#08090e",border:"1px solid #7c3aed40",flex:1,margin:20,borderRadius:12,display:"flex",flexDirection:"column",overflow:"hidden",boxShadow:"0 0 80px #7c3aed10"}} onClick={e=>e.stopPropagation()}>
            {/* Diff header */}
            <div style={{padding:"10px 16px",borderBottom:"1px solid #111520",display:"flex",justifyContent:"space-between",alignItems:"center",background:"#0a0c14",flexShrink:0}}>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,color:"#7c3aed",fontSize:14}}>🔀 SMART DIFF</span>
                <span style={{fontSize:10,color:"#888"}}>{diffData.lang}</span>
                <span style={{fontSize:10,color:"#00f5a0",background:"#00f5a012",padding:"2px 8px",borderRadius:4}}>+{diffData.stats.added} added</span>
                <span style={{fontSize:10,color:"#ef4444",background:"#ef444412",padding:"2px 8px",borderRadius:4}}>-{diffData.stats.removed} removed</span>
                <span style={{fontSize:10,color:"#888"}}>{diffData.stats.pctChanged}% changed</span>
              </div>
              <div style={{display:"flex",gap:8,alignItems:"center"}}>
                <label style={{fontSize:10,color:"#555",display:"flex",gap:4,alignItems:"center",cursor:"pointer"}}>
                  <input type="checkbox" checked={diffAutoMode} onChange={e=>setDiffAutoMode(e.target.checked)} style={{accentColor:"#7c3aed"}}/>
                  auto-diff
                </label>
                <button onClick={()=>setShowDiff(false)} style={{background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:18}}>✕</button>
              </div>
            </div>

            {/* Column headers */}
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",borderBottom:"1px solid #111520",flexShrink:0}}>
              <div style={{padding:"6px 16px",background:"#0d0810",borderRight:"1px solid #111520",fontSize:10,color:"#ef4444"}}>← ANTES (versión anterior)</div>
              <div style={{padding:"6px 16px",background:"#080d08",fontSize:10,color:"#00f5a0"}}>→ DESPUÉS (versión actual)</div>
            </div>

            {/* Diff lines */}
            <div style={{flex:1,overflow:"auto",fontFamily:"'JetBrains Mono',monospace",fontSize:11,lineHeight:1.7}}>
              {diffData.stats.lines.map((line,i)=>{
                if (line.type==="same") return(
                  <div key={i} style={{display:"grid",gridTemplateColumns:"1fr 1fr",borderBottom:"1px solid #0a0c10"}}>
                    <div style={{padding:"0 16px",color:"#3a3e4a",whiteSpace:"pre",overflow:"hidden",borderRight:"1px solid #0a0c10"}}><span style={{color:"#222",marginRight:8,userSelect:"none"}}>{line.lineA}</span>{line.text}</div>
                    <div style={{padding:"0 16px",color:"#3a3e4a",whiteSpace:"pre",overflow:"hidden"}}><span style={{color:"#222",marginRight:8,userSelect:"none"}}>{line.lineB}</span>{line.text}</div>
                  </div>
                );
                if (line.type==="remove") return(
                  <div key={i} style={{display:"grid",gridTemplateColumns:"1fr 1fr",background:"#ef444408",borderBottom:"1px solid #ef444415"}}>
                    <div style={{padding:"0 16px",color:"#ef4444",whiteSpace:"pre",overflow:"hidden",borderRight:"1px solid #0a0c10"}}><span style={{color:"#ef444460",marginRight:8,userSelect:"none"}}>{line.lineA}</span>{line.text}</div>
                    <div style={{background:"#060810",borderRight:"none"}}/>
                  </div>
                );
                return(
                  <div key={i} style={{display:"grid",gridTemplateColumns:"1fr 1fr",background:"#00f5a008",borderBottom:"1px solid #00f5a015"}}>
                    <div style={{background:"#060810",borderRight:"1px solid #0a0c10"}}/>
                    <div style={{padding:"0 16px",color:"#00f5a0",whiteSpace:"pre",overflow:"hidden"}}><span style={{color:"#00f5a040",marginRight:8,userSelect:"none"}}>{line.lineB}</span>{line.text}</div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* CSS */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@300;400;500;700&family=Syne:wght@400;700;800;900&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#060810!important;}
        ::-webkit-scrollbar{width:3px;height:3px;}
        ::-webkit-scrollbar-track{background:#09090f;}
        ::-webkit-scrollbar-thumb{background:#1e2330;border-radius:2px;}
        @keyframes blink{0%,100%{opacity:1}50%{opacity:0.2}}
        @keyframes dotPulse{0%,80%,100%{transform:scale(0.5);opacity:0.2}40%{transform:scale(1);opacity:1}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:translateY(0)}}
        textarea:focus{border-color:#1a2040!important;outline:none;}
        input:focus{border-color:#1a2040!important;outline:none;}
      `}</style>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
//  SUB-COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function Dot({color,label}){
  return(
    <div style={{display:"flex",alignItems:"center",gap:4,fontSize:10,color:"#666"}}>
      <div style={{width:6,height:6,borderRadius:"50%",background:color,boxShadow:`0 0 6px ${color}`}}/>
      {label}
    </div>
  );
}

function Sec({children,style}){
  return <div style={{fontSize:9,color:"#333",letterSpacing:2,textTransform:"uppercase",marginBottom:8,marginTop:4,display:"flex",alignItems:"center",justifyContent:"space-between",...style}}>{children}</div>;
}

function MdCard({m,sel,onSel,color,disabled}){
  return(
    <div onClick={!disabled?onSel:undefined} style={{border:`1px solid ${sel?color+"50":"#1a1d26"}`,borderRadius:6,padding:"8px 10px",marginBottom:5,cursor:disabled?"not-allowed":"pointer",
      transition:"all 0.15s",background:sel?color+"10":"#0c0e14",opacity:disabled?0.35:1}}>
      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
        <span style={{color:sel?color:"#999",fontWeight:600,fontSize:12}}>{m.name}</span>
        <span style={{color:"#333",fontSize:10}}>{m.note}</span>
      </div>
      {m.tags?.length>0 && <div style={{display:"flex",gap:3,marginTop:4,flexWrap:"wrap"}}>
        {m.tags.map(t=><span key={t} style={{background:"#151820",color:"#555",fontSize:8,padding:"1px 5px",borderRadius:3,letterSpacing:0.5}}>{t}</span>)}
      </div>}
    </div>
  );
}

function Welcome({modes,setMode,agents}){
  return(
    <div style={{display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",height:"100%",gap:24,animation:"fadeUp 0.5s ease"}}>
      <div style={{textAlign:"center"}}>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:48,fontWeight:900,color:"#00f5a0",letterSpacing:6,filter:"drop-shadow(0 0 30px #00f5a050)",lineHeight:1}}>⬡ AGENT</div>
        <div style={{fontFamily:"'Syne',sans-serif",fontSize:48,fontWeight:900,color:"#e8ecf4",letterSpacing:6,lineHeight:1}}>STUDIO</div>
        <div style={{color:"#333",fontSize:12,letterSpacing:3,marginTop:8}}>v2.0 · Multi-Agent · RAG · 20+ MCP Tools</div>
      </div>
      <div style={{display:"grid",gridTemplateColumns:"repeat(2,1fr)",gap:10,maxWidth:460}}>
        {modes.map(m=>(
          <div key={m.id} onClick={()=>setMode(m.id)} style={{border:`1px solid #1a1d26`,borderRadius:10,padding:"14px 18px",cursor:"pointer",
            display:"flex",flexDirection:"column",gap:6,transition:"all 0.2s",background:"#0c0e14"}}
            onMouseEnter={e=>e.currentTarget.style.borderColor=m.color}
            onMouseLeave={e=>e.currentTarget.style.borderColor="#1a1d26"}>
            <span style={{fontSize:24}}>{m.icon}</span>
            <span style={{color:m.color,fontWeight:700,fontSize:13}}>{m.label}</span>
            <span style={{color:"#444",fontSize:11}}>{m.desc}</span>
          </div>
        ))}
      </div>
      <div style={{color:"#333",fontSize:10,letterSpacing:1}}>
        Context7 · Sequential Thinking · GitHub · Brave · Qdrant · E2B · ECharts · n8n
      </div>
    </div>
  );
}

function ChatMsg({msg,modes,agents,onFork,msgIndex}){
  const isUser  = msg.role==="user";
  const mode    = modes.find(m=>m.id===msg.mode);
  const agent   = agents.find(a=>a.id===msg.agent);
  const [copied,setCopied]=useState(false);
  const [hover, setHover]=useState(false);

  const copy=()=>{navigator.clipboard.writeText(msg.content);setCopied(true);setTimeout(()=>setCopied(false),1500);};

  const renderContent=(content)=>{
    const parts=content.split(/(```[\s\S]*?```)/g);
    return parts.map((part,i)=>{
      if(part.startsWith("```")){
        const lines=part.slice(3,-3).split("\n");
        const lang=lines[0].trim();
        const code=lines.slice(1).join("\n");
        const extColors={javascript:"#f0db4f",js:"#f0db4f",typescript:"#3178c6",ts:"#3178c6",jsx:"#61dafb",tsx:"#61dafb",python:"#3776ab",py:"#3776ab",html:"#e34c26",css:"#264de4",json:"#f59e0b",yaml:"#a0aec0",sql:"#00758f",rust:"#ce422b",go:"#00acd7",bash:"#4ade80",sh:"#4ade80"};
        const langColor=extColors[lang]||"#7c3aed";
        return(
          <div key={i} style={{background:"#060810",border:"1px solid #1a1d26",borderRadius:8,margin:"10px 0",overflow:"hidden",boxShadow:"0 2px 12px rgba(0,0,0,0.3)"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"5px 12px",background:"#0d0f14",borderBottom:"1px solid #1a1d26"}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <div style={{width:6,height:6,borderRadius:"50%",background:langColor}}/>
                <span style={{color:langColor,fontSize:10,fontFamily:"'JetBrains Mono',monospace",fontWeight:600}}>{lang||"code"}</span>
                <span style={{fontSize:9,color:"#333"}}>{code.split("\n").length} líneas</span>
              </div>
              <div style={{display:"flex",gap:4}}>
                <button onClick={()=>navigator.clipboard.writeText(code)} style={{background:"none",border:"1px solid #1a1d26",borderRadius:3,color:"#555",cursor:"pointer",fontSize:9,padding:"1px 8px",fontFamily:"monospace",transition:"all 0.15s"}}
                  onMouseEnter={e=>e.currentTarget.style.color="#00f5a0"} onMouseLeave={e=>e.currentTarget.style.color="#555"}>⎘ copy</button>
              </div>
            </div>
            <pre style={{padding:"12px 16px",fontSize:11.5,overflowX:"auto",lineHeight:1.65,color:"#a8b4c8",fontFamily:"'JetBrains Mono',monospace",margin:0}}>{code}</pre>
          </div>
        );
      }
      // Render bold/italic markdown inline
      const rendered = part.replace(/\*\*(.+?)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code style="background:#151820;padding:1px 5px;border-radius:3px;color:#a78bfa;font-size:11px">$1</code>');
      return<span key={i} style={{whiteSpace:"pre-wrap"}} dangerouslySetInnerHTML={{__html:rendered}}/>;
    });
  };

  return(
    <div onMouseEnter={()=>setHover(true)} onMouseLeave={()=>setHover(false)}
      style={{display:"flex",gap:10,marginBottom:16,alignItems:"flex-start",flexDirection:isUser?"row-reverse":"row",animation:"fadeUp 0.2s ease",position:"relative"}}>

      {/* Avatar */}
      <div style={{width:30,height:30,borderRadius:"50%",flexShrink:0,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,
        background:isUser?"#7c3aed22":agent?agent.color+"15":"#00f5a015",
        border:`1px solid ${isUser?"#7c3aed40":agent?agent.color+"35":"#00f5a030"}`,
        color:isUser?"#7c3aed":agent?.color||"#00f5a0",
        boxShadow:hover?`0 0 10px ${isUser?"#7c3aed20":agent?.color+"20"||"#00f5a020"}`:"none",transition:"box-shadow 0.2s"}}>
        {isUser?"U":agent?.icon||"⬡"}
      </div>

      {/* Bubble */}
      <div style={{maxWidth:"84%",borderRadius:isUser?"12px 0 12px 12px":"0 12px 12px 12px",padding:"10px 14px",lineHeight:1.75,fontSize:12.5,
        background:isUser?"linear-gradient(135deg,#7c3aed18,#7c3aed08)":msg.isError?"#ef444410":"#0c0e14",
        border:`1px solid ${isUser?"#7c3aed30":msg.isError?"#ef444435":"#151820"}`,
        boxShadow:hover?"0 4px 20px rgba(0,0,0,0.2)":"none",transition:"box-shadow 0.2s"}}>

        {/* AI meta row */}
        {!isUser && (
          <div style={{display:"flex",alignItems:"center",gap:5,marginBottom:8,flexWrap:"wrap",borderBottom:"1px solid #111520",paddingBottom:6}}>
            {agent && <span style={{color:agent.color,fontSize:10,fontWeight:700,display:"flex",alignItems:"center",gap:3}}>{agent.icon} {agent.name}</span>}
            {mode  && <span style={{color:mode.color,fontSize:9,background:mode.color+"12",padding:"1px 5px",borderRadius:3}}>{mode.icon} {mode.label}</span>}
            {msg.ragUsed  && <span style={{fontSize:9,color:"#7c3aed",background:"#7c3aed12",padding:"1px 5px",borderRadius:3}}>🧠 rag</span>}
            {msg.ctx7Used && <span style={{fontSize:9,color:"#00f5a0",background:"#00f5a012",padding:"1px 5px",borderRadius:3}}>📚 ctx7</span>}
            {msg.planUsed && <span style={{fontSize:9,color:"#06b6d4",background:"#06b6d412",padding:"1px 5px",borderRadius:3}}>🧭 plan</span>}
            {msg.keysInjected?.length>0 && <span style={{fontSize:9,color:"#f59e0b",background:"#f59e0b12",padding:"1px 5px",borderRadius:3}}>🔑 {msg.keysInjected.length}k</span>}
            <span style={{color:"#2a2d38",fontSize:9,marginLeft:"auto"}}>{msg.time}</span>
            <button onClick={copy} title="Copiar respuesta completa" style={{background:"none",border:"none",color:copied?"#00f5a0":"#333",cursor:"pointer",fontSize:11,padding:"0 2px",transition:"color 0.2s"}}>{copied?"✓":"⎘"}</button>
            {/* Fork button */}
            {hover && onFork && <button onClick={()=>onFork(msgIndex)} title="🌿 Bifurcar conversación desde aquí"
              style={{background:"#00f5a010",border:"1px solid #00f5a025",borderRadius:3,color:"#00f5a0",cursor:"pointer",fontSize:9,padding:"1px 6px",animation:"fadeUp 0.15s"}}>
              🌿 fork
            </button>}
          </div>
        )}

        {/* User action row */}
        {isUser && hover && onFork && (
          <div style={{display:"flex",justifyContent:"flex-end",marginBottom:4}}>
            <button onClick={()=>onFork(msgIndex)} title="🌿 Bifurcar desde aquí"
              style={{background:"#00f5a010",border:"1px solid #00f5a025",borderRadius:3,color:"#00f5a0",cursor:"pointer",fontSize:9,padding:"1px 6px"}}>
              🌿 fork
            </button>
          </div>
        )}

        <div style={{color:isUser?"#d4b8ff":"#c8cdd8"}}>{renderContent(msg.content)}</div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════
//  FS COMPONENTS
// ═══════════════════════════════════════════════════════════════════

function FsNode({ node, depth, onRead, onDelete, onSelect, selected }) {
  const [open, setOpen] = useState(depth < 1);
  const isDir = node.kind === "directory";
  const isSelected = selected === node.path;
  const indent = depth * 14;
  const extColors = { js:"#f0db4f",ts:"#3178c6",jsx:"#61dafb",tsx:"#61dafb",py:"#3776ab",html:"#e34c26",css:"#264de4",json:"#f59e0b",md:"#888",rs:"#ce422b",go:"#00acd7",sql:"#00758f",vue:"#42b883",svelte:"#ff3e00" };
  const ext = node.name.split(".").pop().toLowerCase();
  const fileColor = extColors[ext] || "#555";
  return (
    <div>
      <div onClick={()=>{ isDir?setOpen(p=>!p):onRead(node.handle,node.path); }}
        style={{display:"flex",alignItems:"center",gap:5,padding:"3px 8px",paddingLeft:8+indent,cursor:"pointer",
          borderRadius:4,background:isSelected?"#7c3aed12":"transparent",
          borderLeft:`2px solid ${isSelected?"#7c3aed":"transparent"}`,transition:"all 0.1s",position:"relative"}}
        onMouseEnter={e=>{e.currentTarget.querySelector(".del-fs")&&(e.currentTarget.querySelector(".del-fs").style.opacity="1");}}
        onMouseLeave={e=>{e.currentTarget.querySelector(".del-fs")&&(e.currentTarget.querySelector(".del-fs").style.opacity="0");}}>
        <span style={{fontSize:9,color:"#444",flexShrink:0}}>{isDir?(open?"▾":"▸"):"·"}</span>
        <span style={{fontSize:12,flexShrink:0}}>{isDir?(open?"📂":"📁"):<span style={{color:fileColor}}>◆</span>}</span>
        <span style={{fontSize:11,color:isSelected?"#c4b5fd":isDir?"#e2e8f0":"#94a3b8",flex:1,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{node.name}</span>
        <button className="del-fs" onClick={e=>{e.stopPropagation();onDelete(node);}}
          style={{background:"none",border:"none",color:"#ef4444",cursor:"pointer",fontSize:10,padding:"0 2px",opacity:0,transition:"opacity 0.15s"}}>✕</button>
      </div>
      {isDir && open && node.children?.map(c=>(
        <FsNode key={c.id} node={c} depth={depth+1} onRead={onRead} onDelete={onDelete} onSelect={onSelect} selected={selected}/>
      ))}
    </div>
  );
}

function FsQuickAction({ icon, label, onClick }) {
  return (
    <button onClick={onClick} title={label}
      style={{flex:1,background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:5,padding:"5px 2px",cursor:"pointer",
        display:"flex",flexDirection:"column",alignItems:"center",gap:2,transition:"border-color 0.15s"}}
      onMouseEnter={e=>e.currentTarget.style.borderColor="#f59e0b50"}
      onMouseLeave={e=>e.currentTarget.style.borderColor="#1a1d26"}>
      <span style={{fontSize:15}}>{icon}</span>
      <span style={{fontSize:8,color:"#555",letterSpacing:0.5,fontFamily:"'JetBrains Mono',monospace"}}>{label.slice(0,8).toUpperCase()}</span>
    </button>
  );
}

// ═══════════════════════════════════════════════════════════════════
//  STYLES
// ═══════════════════════════════════════════════════════════════════
const S = {
  root:{fontFamily:"'JetBrains Mono',monospace",background:"#060810",color:"#c8cdd8",height:"100vh",display:"flex",flexDirection:"column",overflow:"hidden",position:"relative"},
  scan:{position:"fixed",inset:0,background:"repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(0,0,0,0.03) 2px,rgba(0,0,0,0.03) 4px)",pointerEvents:"none",zIndex:200},

  // Header
  header:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"0 14px",height:50,background:"#09090f",borderBottom:"1px solid #111520",flexShrink:0},
  hLeft:{display:"flex",alignItems:"center",gap:16},
  hRight:{display:"flex",gap:6,alignItems:"center"},
  logo:{display:"flex",alignItems:"center",gap:6},
  logoMark:{fontSize:18,color:"#00f5a0",filter:"drop-shadow(0 0 10px #00f5a0)"},
  logoTxt:{fontFamily:"'Syne',sans-serif",fontWeight:900,fontSize:17,letterSpacing:3,color:"#e8ecf4"},
  logoAcc:{color:"#00f5a0"},
  logoVer:{fontSize:9,color:"#333",letterSpacing:1,marginTop:2},
  hStatus:{display:"flex",gap:14,alignItems:"center"},
  pipelineBadge:{background:"#06b6d415",border:"1px solid #06b6d430",borderRadius:4,padding:"2px 8px",fontSize:10,color:"#06b6d4"},
  dbgBadge:{background:"#ef444415",border:"1px solid #ef444440",borderRadius:4,padding:"2px 8px",fontSize:10,color:"#ef4444",animation:"blink 2s infinite"},
  tokenBadge:{fontSize:10,color:"#444",background:"#0c0e14",border:"1px solid #151820",borderRadius:4,padding:"2px 8px"},
  iconBtn:{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:15,padding:"4px 7px",borderRadius:4,fontFamily:"'JetBrains Mono',monospace"},

  // Layout
  body:{display:"flex",flex:1,overflow:"hidden"},

  // Sidebar
  sidebar:{width:290,background:"#07080e",borderRight:"1px solid #111520",display:"flex",flexDirection:"column",flexShrink:0,overflow:"hidden"},
  sTabs:{display:"flex",borderBottom:"1px solid #111520",flexShrink:0},
  sTab:{flex:1,padding:"8px 4px",background:"none",border:"none",color:"#444",cursor:"pointer",fontSize:9,transition:"all 0.2s",fontFamily:"'JetBrains Mono',monospace",letterSpacing:0.5,textAlign:"center"},
  sTabOn:{color:"#00f5a0",borderBottom:"2px solid #00f5a0",background:"#00f5a008"},
  sContent:{flex:1,overflow:"auto",padding:10},

  // MCP
  mcpRow:{border:"1px solid #151820",borderRadius:6,padding:"7px 9px",marginBottom:5,cursor:"pointer",transition:"all 0.12s",background:"#0c0e14",display:"flex",gap:8,alignItems:"center"},

  // Agent
  agentCard:{border:"1px solid #1a1d26",borderRadius:8,padding:"8px 10px",marginBottom:8,cursor:"default",transition:"all 0.2s",background:"#0c0e14"},

  // Toggle
  toggle:{display:"flex",alignItems:"center",gap:8,cursor:"pointer",fontSize:11,color:"#888",marginBottom:8},
  toggleTrack:{width:28,height:14,borderRadius:7,transition:"background 0.2s",flexShrink:0},

  // Filter chips
  filterChip:{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:4,padding:"2px 7px",fontSize:9,color:"#555",cursor:"pointer",letterSpacing:0.5},

  // Buttons
  btn:{width:"100%",padding:"7px 10px",background:"#00f5a010",border:"1px solid #00f5a025",borderRadius:6,color:"#00f5a0",cursor:"pointer",fontSize:11,fontFamily:"'JetBrains Mono',monospace",transition:"all 0.2s"},
  refreshBtn:{background:"none",border:"1px solid #1a1d26",borderRadius:4,color:"#444",cursor:"pointer",fontSize:10,padding:"1px 6px"},

  // Main
  main:{flex:1,display:"flex",flexDirection:"column",overflow:"hidden"},
  modeBar:{display:"flex",gap:6,padding:"7px 12px",background:"#07080e",borderBottom:"1px solid #111520",flexShrink:0,alignItems:"center"},
  modeBtn:{display:"flex",alignItems:"center",gap:5,padding:"4px 10px",background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:6,color:"#555",cursor:"pointer",fontSize:11,fontFamily:"'JetBrains Mono',monospace",transition:"all 0.2s",fontWeight:600},
  modeNum:{background:"#111520",borderRadius:3,padding:"0 4px",fontSize:9,color:"#333"},
  memPanel:{background:"#0c0e14",borderBottom:"1px solid #111520",padding:"8px 12px",flexShrink:0},
  outBar:{background:"#0c0e14",borderBottom:"1px solid #111520",padding:"6px 12px",flexShrink:0,display:"flex",justifyContent:"space-between",alignItems:"center"},
  outBtn:{background:"#00f5a010",border:"1px solid #00f5a025",color:"#00f5a0",borderRadius:4,padding:"2px 8px",cursor:"pointer",fontSize:10,fontFamily:"'JetBrains Mono',monospace"},
  chat:{flex:1,overflow:"auto",padding:"14px 16px 6px"},

  // Input
  inputWrap:{padding:"7px 12px 10px",background:"#07080e",borderTop:"1px solid #111520",flexShrink:0},
  inputMeta:{display:"flex",gap:5,alignItems:"center",marginBottom:6,flexWrap:"wrap"},
  chip:{background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:4,padding:"2px 7px",fontSize:10,color:"#888"},
  textarea:{flex:1,background:"#0c0e14",border:"1px solid #1a1d26",borderRadius:8,padding:"9px 13px",color:"#c8cdd8",fontFamily:"'JetBrains Mono',monospace",fontSize:12,resize:"none",outline:"none",lineHeight:1.6},
  sendBtn:{width:42,height:42,background:"#00f5a018",border:"1px solid #00f5a035",borderRadius:8,color:"#00f5a0",cursor:"pointer",fontSize:18,display:"flex",alignItems:"center",justifyContent:"center",transition:"all 0.2s",flexShrink:0,fontFamily:"monospace"},

  // Right panel
  rightPanel:{width:340,background:"#07080e",borderLeft:"1px solid #111520",display:"flex",flexDirection:"column",flexShrink:0,overflow:"hidden"},
  rpHeader:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"8px 10px",borderBottom:"1px solid #111520",flexShrink:0},
  rpTab:{background:"none",border:"none",color:"#555",cursor:"pointer",fontSize:11,padding:"4px 8px",borderRadius:4,fontFamily:"'JetBrains Mono',monospace"},
  rpTabOn:{color:"#06b6d4",background:"#06b6d412"},
  rpBody:{flex:1,overflow:"auto",padding:12,display:"flex",flexDirection:"column"},
  // API Key Manager
  keyInput:{width:"100%",background:"#080a0e",border:"1px solid #1a1d26",borderRadius:6,padding:"6px 10px",color:"#c8cdd8",fontFamily:"'JetBrains Mono',monospace",fontSize:11,outline:"none"},
  keyBtn:{background:"none",border:"1px solid #1a1d26",borderRadius:4,color:"#666",cursor:"pointer",fontSize:11,padding:"2px 5px",fontFamily:"monospace"},
  keyOverlay:{position:"fixed",inset:0,background:"rgba(0,0,0,0.88)",zIndex:1000,display:"flex",alignItems:"center",justifyContent:"center"},
  keyModal:{background:"#09090f",border:"1px solid #f59e0b35",borderRadius:12,width:"min(800px,96vw)",maxHeight:"88vh",display:"flex",flexDirection:"column",boxShadow:"0 0 80px #f59e0b12,0 0 1px #f59e0b60",overflow:"hidden"},
  keyModalHeader:{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 16px",borderBottom:"1px solid #151820",flexShrink:0,background:"#0a0c14"},
};
